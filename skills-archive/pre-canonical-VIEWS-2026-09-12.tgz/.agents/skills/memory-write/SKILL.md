---
name: memory-write
description: >
  Saves durable facts to the two-tier memory system at ~/.claude/global-memory/ and
  ~/.claude/projects/<slug>/memory/. Triggers on "remember this", "note that",
  "update memory", "save this", "forget about". Picks the correct tier (structured
  per-project vs global scratchpad), then handles add / replace / remove with dedup
  and character-cap enforcement.
---

# Memory Write

## Outcome
- Fact added to, updated in, or removed from the correct memory tier
- Tier-B caps enforced (2,500 chars for MEMORY.md, 1,375 for USER.md)
- Confirmation: "Saved — will be active from next session."

## Pick the tier first

Ask: "Will this fact still be true and useful in 3 months, across multiple projects?"

**Tier A — `~/.claude/projects/<slug>/memory/`** (one file per fact, indexed by MEMORY.md)
- Durable user facts → `user_*.md` (metadata.type: user)
- Stable project conventions / gotchas → `project_*.md` (metadata.type: project)
- Behavioral feedback rules → `feedback_*.md` (metadata.type: feedback)
- External-system pointers → `reference_*.md` (metadata.type: reference)

**Tier B — `~/.claude/global-memory/`** (single capped file)
- Active threads (in-progress work) → `MEMORY.md` `## Active Threads`
- Current env notes (URLs, tool versions, project structure in play) → `MEMORY.md` `## Environment Notes`
- Pending decisions → `MEMORY.md` `## Pending Decisions`
- Durable user profile updates → `USER.md`

## Steps

1. **Decide tier** using the rule above.
2. **Read** the target file in full.
3. **Dedup check** — substring scan; if the fact already exists, skip or update in place.
4. **Cap check** for Tier B — `wc -c < ~/.claude/global-memory/MEMORY.md` (or USER.md). If over cap, consolidate (merge similar entries, prune stale) before adding.
5. **Write** the change.
   - Tier A: create a new file with proper frontmatter (name, description, metadata.type) and add a one-line pointer to that slug's `MEMORY.md` index.
   - Tier B: append under the correct `##` section.
6. **Confirm** in one line: `Saved — will be active from next session.`

## Actions

- **add** — append (default)
- **replace** — substring match + swap. Preferred over add when updating an existing fact.
- **remove** — confirm with the user before deleting.

## Rules

- Never exceed Tier B caps. Consolidate first.
- Always dedup before adding.
- For Tier A, the slug for the active session is the current cwd-derived slug (e.g. `C--Users-eric-rash` for sessions under `~`).
- Never announce the write mid-session beyond the one-line confirmation. The injected snapshot is frozen — the new fact appears next session, not this one.
