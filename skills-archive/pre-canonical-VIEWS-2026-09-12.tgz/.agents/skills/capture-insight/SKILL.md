---
name: capture-insight
description: Capture a story, win, or lesson the user just shared as a permanent atomic note in the SecondBrain vault. Use when the user tells a story or lesson and says "capture this", "save this win/lesson", "that's worth a note", or "/capture-insight". For end-of-day structured capture use interview-me; for whole-project distillation use harvest; for plain facts use memory-write.
---

# Capture Insight

Write one atomic permanent note in `/Users/kristinarash/Desktop/SecondBrain/Notes/` from something the user just shared. Capturing is the point — write it, then confirm.

**Paths:** canonical vault locations live in `/Users/kristinarash/.claude/skills/_shared/config.json` (`vault_notes`) — load it if unsure; if a literal path here ever disagrees, the config wins.

## Format

Follow the vault's atomic-note format (see any existing `Notes/*.md`):

- Frontmatter: `type: permanent, created, source, domain, tags, status: seed`
- Kebab-case filename
- A `# Title` that states the insight **as a claim**
- A blockquote distillation, then a short body
- Wikilink related existing notes

## Rules

- One note per distinct insight; bias toward fewer, sharper notes.
- Confirm with the file path and the claim it captures.
- If what was shared is a plain fact or preference rather than an insight, route to memory-write instead.
