---
name: firecrawl-workflows
description: Run outcome-focused Firecrawl workflows that produce deliverables such as research reports, SEO audits, QA reports, lead lists, knowledge bases, website design systems, and other structured web-data artifacts. Use when the user wants Firecrawl to complete a business, marketing, product, or creative workflow rather than merely scrape a page or integrate API calls into code.
license: ISC
metadata:
  author: firecrawl
  version: "0.1.0"
  homepage: https://www.firecrawl.dev
  source: https://github.com/firecrawl/firecrawl-workflows
inputs:
  - name: FIRECRAWL_API_KEY
    description: Firecrawl API key for hosted Firecrawl requests when the workflow runs through the CLI or API.
    required: true
---

# Firecrawl Workflows

Use this when the user wants a finished deliverable powered by Firecrawl, not only raw web extraction and not product-code integration.

## Choose The Workflow

- Use [firecrawl-website-design-clone](../firecrawl-website-design-clone/SKILL.md) to extract a website's colors, fonts, spacing, components, and layout patterns into an agent-ready `DESIGN.md`.
- Use [firecrawl-deep-research](../firecrawl-deep-research/SKILL.md) for sourced multi-source research reports.
- Use [firecrawl-seo-audit](../firecrawl-seo-audit/SKILL.md) for site structure, on-page SEO, keyword, and SERP audits.
- Use [firecrawl-lead-research](../firecrawl-lead-research/SKILL.md) for pre-meeting company/person intelligence briefs.
- Use [firecrawl-qa](../firecrawl-qa/SKILL.md) for live-site QA testing and bug reports.
- Use [firecrawl-competitive-intel](../firecrawl-competitive-intel/SKILL.md) for recurring pricing, feature, and changelog monitoring.
- Use [firecrawl-company-directories](../firecrawl-company-directories/SKILL.md) for directory extraction into company lists.
- Use [firecrawl-dashboard-reporting](../firecrawl-dashboard-reporting/SKILL.md) for dashboard metrics extraction.
- Use [firecrawl-knowledge-base](../firecrawl-knowledge-base/SKILL.md) for LLM-ready docs, RAG chunks, training data, or docs mirrors.
- Use [firecrawl-knowledge-ingest](../firecrawl-knowledge-ingest/SKILL.md) for auth-gated or JS-heavy docs portal ingestion.
- Use [firecrawl-lead-gen](../firecrawl-lead-gen/SKILL.md) for prospect list generation.
- Use [firecrawl-market-research](../firecrawl-market-research/SKILL.md) for market, financial, and industry research.
- Use [firecrawl-research-papers](../firecrawl-research-papers/SKILL.md) for literature reviews from papers, PDFs, and whitepapers.
- Use [firecrawl-demo-walkthrough](../firecrawl-demo-walkthrough/SKILL.md) for product flow walkthroughs and UX teardown reports.
- Use [firecrawl-shop](../firecrawl-shop/SKILL.md) for product research and shopping recommendations.

If no existing workflow fits, use this generic process and produce a reusable pattern that could become a new skill.

## Required Intake

Infer the workflow, inputs, audience, and output format from the user's request and surrounding context. If enough is clear, start immediately.

Ask at most 1-3 concise clarifying questions only when a missing input would block the work, such as:

- the URL, company, topic, or source to analyze
- the desired deliverable or output format
- a constraint that would materially change the workflow

Use the host agent's normal way to ask clarifying questions. Do not depend on a harness-specific function name.

In Claude Code, run the onboarding interview via the AskUserQuestion tool (options + Other) instead of free-text questions.

## Default Process

1. Confirm the workflow and final artifact.
2. Collect web evidence with Firecrawl through the CLI or equivalent Firecrawl tool surface.
3. Save or cite source evidence so the final claims are traceable.
4. Run independent research units in parallel when available.
5. Synthesize findings into the requested deliverable.
6. Include a short "rerun inputs" block when the workflow could be automated.

## Parallel Work

If appropriate, use sub-agents or equivalent parallel task runners for independent units such as:

- one competitor per researcher
- one URL or page per researcher
- one source category per researcher
- one analysis dimension per reviewer

Keep the handoff generic: provide the unit of work, source URLs or search terms, expected extracted fields, and output format.

## Deliverable Standards

Every workflow should return:

- a concise executive summary
- the evidence base used
- the analysis or artifact requested by the user
- recommendations or next actions when useful
- automation inputs for reruns

## Failure Handling

Applies to every workflow in this family:

- Expired or missing auth: ask the user to re-authenticate rather than attempting to bypass access controls.
- Rate limits: back off and reduce concurrency; if the limit persists, report which sources were collected and which were skipped.
- Credit exhaustion mid-run: stop new Firecrawl requests, synthesize from what was already collected, and tell the user what remains uncollected.
- Partial scrape failures: retry a failed URL once or twice at most — never silently retry forever. Continue with the successful pages, and list failed URLs and their impact in the deliverable.

Always report what succeeded alongside what failed; a partial deliverable with explicit gaps beats a silent stall.
