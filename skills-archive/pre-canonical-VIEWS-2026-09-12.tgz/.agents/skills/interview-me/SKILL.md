---
name: interview-me
description: End-of-workday structured interview that distills the user's day into atomic permanent notes for their SecondBrain Obsidian vault. NOT a journaling app — produces curated synthesis notes, not stream-of-consciousness. Use when the user types `/interview-me`, says "interview me", "let's debrief", "end of day interview", "process my day", "wrap up today", or otherwise asks to capture their workday for their second brain.
---

# Interview Me

End-of-workday synthesis ritual. The user is a sport-science / performance analyst who writes essays connecting sport science, product strategy, and decision-making. The interview's job is to extract publishable insights, not to record what happened.

## Vault location

`/Users/kristinarash/Desktop/SecondBrain/`

**Paths:** canonical vault locations live in `/Users/kristinarash/.claude/skills/_shared/config.json` — load it if unsure; if a literal path here ever disagrees, the config wins.

- `Inbox/` — full transcripts (one per day)
- `Notes/` — atomic permanent notes (one idea per file)
- `Drafts/` — essays in progress
- `Archive/` — published
- `Templates/interview-note.md`, `Templates/permanent-note.md`

## The interview

**Time budget:** 10–15 minutes. If the user wants to keep talking, schedule a follow-up session — don't blow the budget.

**Opening line (verbatim is fine):**
> Let's debrief. Four short questions, then I write up anything that earned its place. Ready?

### Question 1 — Orientation (filter)
> What did you spend time on today?

Listen for themes. Don't try to capture everything. Look for: a hard decision, a piece of work that consumed a lot of time, anything that felt different from yesterday.

### Question 2 — Signal (insight detection)
> What surprised you, frustrated you, or changed your mind?

This is the gold question. Genuine surprise, frustration, or updated belief = the moments worth writing down. If the answer is "nothing," probe once: *"Nothing at all? Even small recalibrations count."* If still nothing, accept and move on — not every day produces signal.

### Question 3 — Pattern (synthesis)
> Does anything from today connect to what you were thinking about earlier this week or recently?

**Optional aid:** quietly Glob `Notes/*.md` modified in the last 7 days; if you find 2–3 candidates that match today's themes, name them and ask if today's experience updates them.

### Question 4 — Essay seed (publishable insight)
> If you told a peer one thing about today's work, what would it be?

This question converts experience into transferable insight. If the user gives a great one-liner — capture it verbatim as the seed for a permanent note.

## Optional source pull-ins

Offer when the user references them. Don't pull unprompted.

- **Meeting referenced** ("today's call with X", "this morning's standup"):
  → **First, check `Inbox/meetings/` for a local summary** — Glob for files matching the date or participant. If found, read and quote from the local file (free, fast, no API call).
  → If not found locally, ask: *"Want me to pull from Fireflies?"* → invoke the `meeting-sync` skill to sync the latest meetings, then read the local file.
  → Fall back to direct `pp-fireflies` only if `meeting-sync` reports nothing matching.
- **Paper / article referenced:**
  → "Want me to pull the source from Zotero?" → use `pp-zotero-research-library` skill.
- **GPS / Catapult data referenced:**
  → "Want me to pull the underlying metric?" → use `pp-catapult-openfield-connect` skill.

Quote sources in the note's frontmatter `source:` field or the **Evidence / origin** section.

## Output protocol

### Always write the transcript

`Inbox/YYYY-MM-DD-interview.md` — full Q&A, lightly cleaned. Use the `Templates/interview-note.md` skeleton. Fill in `themes`, `notes_produced`, `pulled_sources` in frontmatter.

### Write 0–3 permanent notes

**Bias toward fewer notes.** A vault full of mediocre notes is worse than one with three great ones. If nothing crossed the bar today, write zero — say so to the user. They will respect this.

A note earns its place if it meets at least one of:
- States a transferable claim (works beyond today's context)
- Updates a previously held view (in which case, also update / link the old note)
- Names a pattern across two or more recent days
- Is a clean essay seed the user could draft from later

Each note goes to `Notes/<concept-title-kebab-case>.md` with the `Templates/permanent-note.md` skeleton filled in:
- `created`: today's date
- `source`: `[[YYYY-MM-DD-interview]]`
- `domain`: pick from `sport-science`, `product`, `decision-making`, `leadership`, `methodology`, `personal`
- `tags`: free-form, but reuse existing tags from other Notes when possible
- Body: claim in 1–2 sentences, why it matters, evidence/origin, connections (use `[[wikilink]]` to related Notes), open questions

### Memory bridge (when warranted)

If the interview surfaces a **durable** fact about the user, their projects, or working style that should persist across Claude sessions:
- Also write a Tier A memory file via the `memory-write` skill (it derives the correct project slug from the current working directory) or update USER.md / project_*.md as appropriate.
- Tell the user explicitly: "Also saved this to memory as <name>."
- Do NOT bridge ephemeral notes. Most permanent notes stay in the vault only.

## What NOT to do

- **Don't pad notes with model commentary.** The user's own words and insights are the value. You are a scribe with editorial judgment, not a co-author.
- **Don't ask follow-up questions beyond the four** unless an answer was genuinely ambiguous and one clarification unlocks a much better note.
- **Don't produce a note "just to have one."** Zero notes is an honest output.
- **Don't break the 10–15 min budget.** Offer a follow-up session if needed.
- **Don't write to `Drafts/` from a daily interview.** Drafts come out of weekly synthesis, not daily capture.

## Weekly synthesis

Weekly synthesis is NOT this skill's job. If the user says "weekly synthesis", "weekly review", or asks to look across the week, invoke the `weekly-review` skill — it owns the Friday ritual (themes, project status, decisions, stale action items, essay angles). This skill is strictly the daily debrief.

## End-of-session sign-off

Always end with a brief summary:
- Transcript saved: `Inbox/YYYY-MM-DD-interview.md`
- Notes created: list with paths and one-line summaries
- Memory bridge: yes/no, what
- Any open thread to revisit tomorrow

Keep it tight — three to five lines.
