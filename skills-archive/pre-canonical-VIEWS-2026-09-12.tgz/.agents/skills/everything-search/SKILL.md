---
name: everything-search
description: Instant filename search across the whole Mac via mdfind (Spotlight index, near-zero latency). Use when the user asks to find a file or folder by name anywhere on disk ("where is X", "find all *.pptx modified last month", "locate the folder called Y"), or when Glob over a huge or unknown directory tree would be slow. Filename and metadata search only — for searching file contents use Grep.
---

# Everything Search (macOS: mdfind)

Query the Spotlight index via `mdfind`. Spotlight indexes filenames and metadata
on all local volumes in real time, so searches return in milliseconds where
Glob/find would crawl for minutes. (This skill was originally built on the
Windows Everything CLI; `mdfind` is the macOS equivalent.)

## Common queries

```bash
# Filename contains a word (fastest, most common)
mdfind -name "forceplate"

# Exact-ish filename with extension
mdfind -name "cadence.log"

# Limit to a directory tree
mdfind -onlyin ~/DEV -name "requirements"

# All files of a type modified in the last 30 days
mdfind 'kMDItemFSName == "*.pptx" && kMDItemFSContentChangeDate >= $time.today(-30)'

# Folders only, by name
mdfind 'kMDItemContentType == "public.folder" && kMDItemFSName == "*Victory*"'

# Count instead of listing
mdfind -count -name "SKILL.md"
```

## Notes and pitfalls

- **External drives**: exFAT/USB volumes are often NOT indexed. Check with
  `mdutil -s /Volumes/<name>`; enable with `sudo mdutil -i on /Volumes/<name>`,
  or fall back to `find /Volumes/<name> -iname '*pattern*'`.
- **Hidden/system paths** (`~/Library`, dotfiles) are largely excluded from
  Spotlight. Fall back to `find` or Glob for those.
- Metadata attribute names: `mdls <file>` shows every attribute a file carries;
  use those keys in query syntax.
- Results stream full absolute paths — pipe through `head` for broad terms.

## When NOT to use

- Content search inside files → Grep.
- Small known directory → Glob is fine.
- Freshly created files may lag the index by a few seconds.
