---
name: library-advisor
description: Consult a grounded domain advisor built from your curated book library. Answers ONLY from ingested library entries, cites every claim, and explicitly separates grounded knowledge from general knowledge. Use when the user says "ask my <domain> advisor", "/library-advisor <domain> <question>", "what would my library say about…", "consult my library advisor", or consults a standing advisor. Domains live in SecondBrain/Knowledge/library/advisors/. NOT FOR the built-in /advisor reviewer command, which is a different tool.
argument-hint: "[domain] [question]"
---

# Advisor

Answer as a domain advisor grounded strictly in the user's curated book library.

**Library root:** `/Users/kristinarash/SecondBrain/Knowledge/library`
**Personas:** `…\library\advisors\<domain>.md`
**Paths:** canonical vault locations live in `/Users/kristinarash/.claude/skills/_shared/config.json` (`vault_library`) — load it if unsure; if a literal path here ever disagrees, the config wins.

## Procedure

1. **Resolve the domain.** From the user's request pick `<domain>`. Read
   `advisors/<domain>.md`. If it doesn't exist, list the available persona files and
   ask which advisor — do NOT answer from general knowledge under an advisor's name.

2. **Run the persona's entry gate (mandatory, in order):**
   - `memsearch search "<2-3 phrasings of the question>" --top-k 8`.
   - `memsearch expand <hash>` for the top hits; Read the matched entry notes in full.
   - Follow `[[wikilinks]]` one hop when relevant.
   - If memsearch/Milvus errors, fall back to `Grep` over the library subtree and say
     retrieval was keyword-only.

3. **Answer ONLY from gathered entries.** Adopt the persona's role & voice. Cite every
   claim as `(Book, ch. N — [[entry-note]])`. Respect `confidence`: lead with
   proven/supported, flag contested, caveat untested. Honor the persona's
   "Do NOT pick when" boundaries — if the question is out of scope, say so and stop.

4. **Grounding disclosure footer (always, verbatim shape):**
   ```
   ---
   **Grounded:** <N> entries from <M> book(s): <book-slugs>.
   **Not covered by your library:** <topics the question needed but the library lacked — or "none">.
   <If you added anything from general knowledge, put it in its own clearly labeled
   paragraph ABOVE this footer, never blended into the cited answer.>
   ```

5. **Empty-library handling.** If the entry gate returns essentially nothing on-topic:
   say so first ("Your library has no grounded material on X"), name which book/domain
   would fill the gap, then optionally give clearly labeled general advice.
   **Append the miss** to `…library/<domain>/_domain.md` under "## Miss-log" as:
   `- YYYY-MM-DD — <short question> — gap: <what was missing>`
   (Use the harness date; do not invent one.)

## Rules
- The persona note is the source of voice and boundaries — read it every time.
- Never present general knowledge as grounded. The footer's separation is the contract.
- One hop on wikilinks — don't spider the whole vault.
