---
name: closeout
description: End-of-session sign-off ritual. Sweeps loose ends, commits and pushes what needs it, verifies memory capture, writes a cross-harness handoff, and reports "clear to sign off" or what's still open. Use when the user says "/closeout", "any loose ends?", "am I good to sign off?", "close out for the night", "closing out", "goodnight", "wrap up for the day", or asks for a system health check before leaving.
---

# Closeout

One command that replaces the manual end-of-day sequence: "any loose ends?" → "commit and push what needs to be" → "is this in memory?" → "write a handoff so Codex can pick this up."

Run all five checks, then give ONE verdict. Do not ask permission between steps — the invocation of this skill IS the authorization for the full sequence. Commit and push is standing-authorized for every DEV repo: each repo's `AGENTS.md` Session routine says "update STATUS, commit, push at end", and unpushed work on one machine is the top cause of conflicts on the other. The only exceptions are repos whose `CLAUDE.md` says their data must stay local (DexaProject is the precedent); commit those locally and list them as open.

## Step 1 — Loose-ends sweep

- `git status` in every repo touched this session (check cwd first, then any repo mentioned in the conversation; if session context is thin, check `KeystoneOS` and any `DEV/` repo with commits dated today).
- Unfinished todos/tasks from this session (TaskList if available).
- Background jobs or workflows still running.
- Anything the user was promised earlier in the session that wasn't delivered.

## Step 2 — Commit & push

- Every repo touched this session: stage, commit with a descriptive message, `git pull --no-rebase` (the other machine may have pushed), push. If the merge conflicts, keep this machine's version and save the remote copy beside it as `<file>.from-mac` / `<file>.from-windows`, then push and list the file under "Still open".
- Before staging, make sure any new file over 95 MB and any `.env` is in `.gitignore`.
- Local-only repos (CLAUDE.md says so): commit, do not push, list it.
- Also check the three config repos, `~/.claude` (dotclaude), `~/.claude/skills` (claude-skills) and `~/.claude/global-memory` (claude-global-memory). If any has changes, commit and push it the same way, so the other machine's `/dev-sync` picks it up.
- **Push `global-memory` even on a light session.** `daily-backup` pushes it nightly, which is too late for a same-day handoff: work the Mac in the afternoon, sit down at Windows that evening, and anything written to MEMORY.md or handoffs is still only on the Mac. Pushing it here is what makes memory available to the other machine tonight rather than tomorrow. It is the only repo that carries memory across, so treat an unpushed `global-memory` the same as an unpushed project repo: it blocks "clear to sign off".
- Nothing to commit → say so in one line, move on.

## Step 3 — Memory verification

- Check `~/.claude/global-memory/transcripts/.errors.log` — must be empty. If not, surface contents and fix the hook issue if obvious.
- Confirm today's transcript file exists at `~/.claude/global-memory/transcripts/<today>.md` and was modified within the last few hours.
- Run the dev-docs harvest so repo docs reach memsearch: `bash ~/.claude/scripts/harvest-dev-docs.sh` (Mac) or `powershell -ExecutionPolicy Bypass -File $HOME\.claude\scripts\harvest-dev-docs.ps1` (Windows). It copies every repo's `docs/*.md` into `~/.claude/global-memory/dev-docs/`, which is on the index list. One line of output; do this after Step 4 so today's STATUS is included.
- If this session produced a durable decision or new active thread, update `~/.claude/global-memory/MEMORY.md` (respect the 2,500-char cap; consolidate before adding) or write a Tier A memory file per the memory-system rules in CLAUDE.md.
- **Tier A does not cross machines — mirror it or lose it.** Project memory lives under a slug built from the project's absolute path, and that path differs on the Mac and the Windows laptop, so a Tier A file written today is not auto-injected tomorrow on the other machine. Global memory and the repo both cross; Tier A does not. So for every Tier A fact written this session, ask: is this durable and project-scoped? If yes, it must also land in the repo — `docs/STATUS.md` for current state, `docs/DECISIONS.md` for a decision and its reasoning, the dated handoff for the detail. Treat Tier A as a fast local cache and the repo as the record. If a fact only ever exists in Tier A, assume the other machine will never see it.

## Step 4 — Cross-harness handoff

This is the **canonical durable handoff** — the one future sessions and other harnesses read. (For a mid-session, chat-only summary before `/clear`, that's the `session-handoff` skill; the mattpocock `handoff` skill writes to the OS temp dir and is not durable — don't rely on it for cross-session state.)

If real work happened this session (not just Q&A), write a handoff to
`<repo>/docs/handoffs/<YYYY-MM-DD>-<slug>.md` (or `~/.claude/global-memory/handoffs/` if no repo fits):

- What was being worked on and why
- Decisions made (with the reasoning that would be lost)
- Exact file paths of everything created or modified this session
- Next actions, most important first
- Anything mid-flight (open questions, awaited inputs)

Plain markdown, no harness-specific syntax — Codex, Antigravity, or a fresh Claude session must be able to resume from it. Commit it with the Step 2 commit when in a repo.

**Always, in every repo touched (even for light sessions): update `docs/STATUS.md`.** It is the file the next session reads first, on either machine, in any harness. Rewrite the sections in place, keep it short:

- `## Current state` — two to five lines on where things stand today
- `## Next` — most important first
- `## Open questions` — decisions waiting on Eric
- `## Gotchas` — anything that will bite the next session

The dated handoff file is the detailed record; STATUS.md is the summary. Do Step 4 before the Step 2 commit so both land in the same push.

## Step 5 — Verdict

End with a single short report:

```
## Closeout — <date>

**Committed & pushed:** <repos + one-line summary, or "nothing to commit">
**STATUS.md:** updated in <repos>
**Memory:** captured ✓ / issue found: <what>
**Handoff:** <path, or "not needed — no substantive work">
**Still open:** <numbered list, or "none">

Clear to sign off. / Not clear: <the one thing blocking>.
```

"Clear to sign off" means: every touched repo is pushed (or is a declared local-only repo). If anything is unpushed, the verdict is "Not clear" and the unpushed repo is the one thing blocking.

Every file created or modified during the session must appear somewhere in the report with its full path — "where did this save?" should never need to be asked.

## Rules

- Push every touched DEV repo. Do not leave the laptop with unpushed work; the other machine pulls from GitHub, not from this disk.
- Never skip Step 3 — memory capture failing silently is the user's top recurring worry.
- If a check fails and the fix is quick and safe (restage a file, clear a stale lock), fix it and note it. If the fix is risky, list it under "Still open" instead.
- Total output should fit on one screen. The user is leaving; brevity is the deliverable.
