---
name: startup
description: "Start of day, or sitting down at either machine: sync this machine against GitHub, then report where the last session left off and wait. Use when Eric says '/startup', 'good morning', 'starting up', 'where did I leave off', 'what was I working on', 'picking this back up', or opens a session without naming a task."
---

# Startup

The front door for a work session on either machine. This skill owns no logic of its own — it runs `dev-sync`, whose Step 5 loads context back in.

## What to do

Invoke the `dev-sync` skill and run it end to end, Step 0 through Step 5.

Do not reimplement any of it here. If the sync behaviour or the context report needs to change, change `dev-sync/SKILL.md`. One home for the procedure, and this file is an alias so the command matches how Eric actually thinks about it: "sync" is what the machine does, "startup" is what he is doing.

## After the report

`dev-sync` Step 5 ends with a short "picking up" report and a stop. Hold there and wait for Eric to confirm or redirect. Do not begin the next task on your own — `docs/STATUS.md` records where the last session stopped, which is not the same as what he wants to do this morning.

If he names a repo when he invokes this, pass it through so Step 5 reports on that one instead of guessing from the most recent commit.

## Not this

- Not the morning brief. Calendar, email and the shape of the day belong to the `morning` / `morning-briefing` work. This skill answers "where was I", not "what's my day".
- Not a memory loader. Global memory arrives through the SessionStart hook before this runs; do not re-read `USER.md` or `MEMORY.md` by hand.
