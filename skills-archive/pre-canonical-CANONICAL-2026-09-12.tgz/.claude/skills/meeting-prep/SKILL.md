---
name: meeting-prep
description: Pre-meeting readiness brief for a project — what changed, what's open, every deliverable path. Use when the user says "/meeting-prep <project>", "I have a meeting with <person> — are we in a good spot on <project>?", "verify we're up to speed before the meeting", "get me ready for this afternoon's meeting", or names an upcoming coach/staff meeting.
argument-hint: "[project]"
---

# Meeting Prep

Answers one question before the user walks into a room: **"Is everything I said I'd do actually reflected in the artifacts, and what do I need to raise?"**

The argument (or conversation context) names the project — e.g. FaceComps, RTP presentation, AppPerformance brief. If no project is named and none is obvious from context, ask which meeting this is for; that is the only question to ask.

## Step 1 — Reconstruct the "last agreed state"

Pull the most recent decisions about this project, cheapest source first:

1. Project memory files (`~/.claude/projects/<slug>/memory/`) and global `MEMORY.md` active threads.
2. The most recent SecondBrain meeting note(s) mentioning the project (the meeting-sync output in the vault — **Paths:** canonical vault locations live in `/Users/kristinarash/.claude/skills/_shared/config.json`, e.g. `vault_inbox_meetings`; load it if unsure — if a literal path here ever disagrees, the config wins).
3. If still thin, `memsearch search "<project> decision" --top-k 5`.

Produce a short internal list: what was decided, what was promised, by when.

## Step 2 — Verify the artifacts match

For each decided/promised item, check the actual artifact — not the conversation:

- Open the current deliverable files (deck, PDF, calendar, spreadsheet, app) and confirm the agreed change is present.
- `git log --since="<last meeting date>"` in the project repo to see what actually shipped.
- Note any artifact that is stale, locked, or missing.

Mark each item ✅ implemented / ⚠️ partially / ❌ not reflected.

## Step 3 — The brief

Output one screen, in this order:

```
## Meeting Prep — <project> (<meeting date/person if known>)

**Bottom line:** ready / ready with caveats / gaps found

**Since last meeting:** <2-4 bullets of what changed/shipped>

**Decision check:**
✅ <decision> — in <file path>
❌ <decision> — NOT reflected; <where it should be>

**Bring up in the meeting:** <open questions, items awaiting their input>

**Deliverables & paths:** <every file they might present or reference, full paths>
```

## Rules

- Verify against files, never against memory of the conversation — the whole point is catching drift between "we decided" and "it's in the deck."
- If a gap is small and mechanical (a label, a date), offer to fix it now in one line — don't just report it.
- Do not restructure or "improve" deliverables uninvited; this is a readiness check, not an editing pass.
- Brevity is the deliverable: the user is reading this minutes before a meeting.
