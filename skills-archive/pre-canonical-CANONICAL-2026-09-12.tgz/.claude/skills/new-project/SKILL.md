---
name: new-project
description: Scaffold a new project in DEV the standard way: git repo, AGENTS.md with the session routine, CLAUDE.md pointer, docs/STATUS.md, .gitignore, private GitHub repo under erash11. Use when Eric starts a new project or says 'set this up as a repo'.
---

# New project scaffold

Every project Eric works on lives in one folder under DEV, is its own git repo, and has a private remote at `github.com/erash11/<name>`. This skill creates that shape in one pass so every project starts identical on either machine.

## DEV root

- Mac: `~/DEV`
- Windows: `C:\Users\eric_rash\Desktop\DEV`
- Football sub-projects live in `DEV/Football/<name>` and are still their own repos.
- `DEV/_DRIVE` is a link to the Google Drive primary storage drive (documents, data, deliverables). Never create a project inside it and never `git init` it.

If the cwd is already the intended project folder, use it. Otherwise ask for the project name only; everything else is fixed.

## Steps

1. Create `DEV/<name>` (or use the existing folder). Do not nest a repo inside another repo; check `git rev-parse --show-toplevel` from the parent first.
2. `git init -b main` if there is no `.git`.
3. Write these files if they do not exist. Never overwrite an existing one; append the Session routine section to an existing AGENTS.md if it is missing.

`AGENTS.md`:
```
# AGENTS.md

Project: <name>

## What this is
<one paragraph, ask Eric if unknown>

## Session routine
- Start: run `git pull`, then read docs/STATUS.md before doing anything else.
- End: update docs/STATUS.md (done, next, open questions), commit, and `git push`.
- Never leave uncommitted work at the end of a session.

## Conventions
- Durable notes and decisions go in docs/, committed. Not in chat, not in cloud project docs.
- Documents, data exports, and deliverables live on the primary storage drive (Google Drive 00_Primary_Storage_Drive), not in the repo. Files over 95 MB never go in git.
- Writing: plain, direct, no em dashes. Documents use the Baylor design system.
```

`CLAUDE.md`: exactly one line, `@AGENTS.md`.

`docs/STATUS.md`:
```
# STATUS

Read this first. Update it before ending every session.

## Current state
- <today>: project created.

## Next
-

## Open questions
-

## Gotchas
-
```

`.gitignore`: `.env`, `.env.*`, `node_modules/`, `.venv/`, `venv/`, `__pycache__/`, `.DS_Store`, `Thumbs.db`, plus any data folder Eric names.

4. `git add -A && git commit -m "Scaffold project"`.
5. `gh repo create erash11/<name> --private --source=. --push`. If the repo already exists, add it as origin and `git push -u origin main` instead.
6. Confirm in two lines: folder path and repo URL. Remind Eric that the other machine gets it with `gh repo clone erash11/<name>` into its DEV.

## Rules

- Repo name = folder name; replace spaces with underscores.
- Never create a repo for anything holding identifiable health or athlete medical data (DexaProject is the precedent). Ask if unsure.
- Do not add a `docs/context.md` unless there is cloud-project context to transfer.
