---
name: fireflies-intake
description: One-command Fireflies pipeline — sync new meeting transcripts into the SecondBrain vault, rename generically-titled meetings, then report exactly what was ingested. Use when the user says "/fireflies-intake", "ingest my recent fireflies meetings", "sync meetings that aren't in the second brain yet", "pull in the new meetings", "meeting ingestion", or asks whether all recent meetings have been ingested.
argument-hint: "[since-date]"
---

# Fireflies Intake

Replaces the recurring hand-typed sequence: "ingest my recent fireflies meetings" → "some have generic names, rename them" → "is everything from <date> in the second brain?" Runs the full chain in order, unattended, then reports.

This is an orchestrator — the actual work lives in existing skills. Invoke them, don't reimplement them.

## Step 1 — Rename first

Invoke the **name-meetings** skill in its **Unattended mode** (declare it explicitly when invoking) to find meetings with generic titles (empty, "Zoom Meeting", "Recording", date-only) and apply structured names. Renaming BEFORE sync means the vault notes are created under their proper names — no cleanup pass later.

- Unattended mode applies only HIGH-confidence renames without approval; anything with weak evidence (vague gist, missing summary) is written to the `review[]` array of the pending-renames file (`pending_renames_file` in `~/.claude/skills/_shared/config.json`) for later interactive review — never guessed and applied.

## Step 2 — Sync

Invoke the **meeting-sync** skill to pull all transcripts not yet in the SecondBrain vault. It is idempotent — run it over the full recent window rather than trying to compute the delta yourself.

## Step 3 — Verify completeness

Compare the Fireflies meeting list for the sync window against the vault's meeting notes (the pp-fireflies CLI's local database is the cheapest source for the meeting list; the vault folder is `vault_inbox_meetings` and the export ledger is `meeting_sync_state_file`, both in `~/.claude/skills/_shared/config.json`). Every meeting must be accounted for: ingested now, ingested previously, or intentionally skipped (with the reason).

## Step 4 — Report

```
## Fireflies Intake — <date>

**Renamed:** <n> meetings (<old → new>, one line each; or "none needed")
**Ingested:** <n> new meetings → <vault folder path>
   - <meeting name> (<date>)
**Already in vault:** <n>
**Skipped/failed:** <list with reasons, or "none">
**Queued for review:** <n> low-confidence rename proposals in .pending-renames.json (omit line if 0)
```

If the user also wants the new notes graphed into the knowledge graph, they'll say so — offer `/graphify` as a one-line follow-up only when new meetings were actually ingested.

## Rules

- Never duplicate a vault note; trust meeting-sync's idempotency and say "already in vault" rather than re-ingesting.
- If the Fireflies API or CLI auth fails, report which step failed and stop — don't half-ingest silently.
- An empty run is a valid result: "No new meetings since <date>" is the complete report.
