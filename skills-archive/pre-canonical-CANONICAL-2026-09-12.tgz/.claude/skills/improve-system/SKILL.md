---
name: improve-system
description: Audit the SecondBrain vault for rot — stale seed notes, conflicting claims, and duplicate notes — and propose merge/archive/update actions. Use when the user says "/improve-system", "audit my notes", "audit the vault", "find stale/duplicate notes", or "clean up my second brain". For mining sessions for missed learnings use session-miner; for capturing a win/lesson use capture-insight; for improving a skill use write-a-skill.
---

# Improve System — Vault Audit

Find rot in the vault and report it. Verification only: this skill proposes, the user disposes.

## Step 0 — read the pending ledger first

`~/.claude/claude-memory-compiler/reports/proposals-pending.md`

Do this **before** scanning. Apply anything marked `approved` (then mark it `applied`),
and re-list every `open` item in this run's report next to the new findings. Append new
findings there as `open`, deduplicating against what is already listed.

Without this step a proposal made in a session that ends is lost, and the next run pays
to rediscover it. The file's header carries the entry format.

**Vault:** `/Users/kristinarash/SecondBrain/`
**Paths:** canonical vault locations live in `/Users/kristinarash/.claude/skills/_shared/config.json` — load it if unsure; if a literal path here ever disagrees, the config wins.

Scan `Notes/`, `Knowledge/`, `Projects/` (skip `Archive/`, `Inbox/`, `morning-briefings/`).

1. **Stale**: `status: seed` notes older than 60 days; `Project_*.md` files untouched 30+ days that read as active.
2. **Conflicting**: notes asserting opposing claims on the same domain/tags — compare titles and opening claims, read bodies only for suspected pairs.
3. **Duplicates**: near-identical titles or same core concept under different slugs.

Output a short report grouped by issue type with a proposed action per item (merge / archive / update status / no action). **Apply nothing until the user picks.** Archive = move to `Archive/`, never delete.

## Related skills (formerly modes of this skill)

- Mine recent sessions for uncaptured learnings → `session-miner`
- Capture a story/win/lesson as a permanent note → `capture-insight`
- Improve a skill from recent back-and-forth → `write-a-skill`
- Fill missing brand/audience/voice foundations → `starter-voice-profile`, `starter-icp-positioning`, `starter-design-tokens`
