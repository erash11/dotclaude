---
name: claude-stack-doctor
description: Health-check Eric's automation/memory stack in one pass, and verify the Mac-to-Windows handoff actually works — launchd agents (com.keystone.morning, agysync, dailybackup, rituals, reconcile, adjudicate), Python venvs, memsearch, memory-compiler flush pipeline, backup freshness, and context budget — and diagnose what's silently broken. Use when the user says "/claude-stack-doctor", "stack doctor", "is my stack healthy", "did my scheduled jobs run", "check the memory pipeline", "why didn't the backup run", or when closeout/morning sessions should verify automation health.
---

# Claude Stack Doctor

One command surfaces every known silent-failure class in the automation/memory stack. Run it before debugging anything by hand.

## Quick start

```bash
/opt/homebrew/bin/pwsh -NoProfile -File ~/.claude/skills/claude-stack-doctor/scripts/stack-check.ps1
```

Exit 0 = all clear. Exit 1 = the VERDICT line lists issue codes. Report the findings to the user, then apply the matching fix below.

## Cross-machine handoff (runs on BOTH machines)

`scripts/handoff-check.ps1` is the one part of this skill that is not Mac-only, and it can be run on its own:

```
powershell -NoProfile -ExecutionPolicy Bypass -File $HOME\.claude\skills\claude-stack-doctor\scripts\handoff-check.ps1
```

It answers a question nothing else here asked: did state actually make the trip between the two machines? Every other check verifies a component. This verifies the path.

The failure it exists to catch: `daily-backup` pushes `global-memory` nightly and, until 2026-09-12, nothing on the receiving machine ever pulled it. The Windows laptop was found 4 commits behind with every other signal reading healthy, because the backup section measures `ahead` only — which catches a broken push and is blind to a missing pull.

Issue codes:

- `handoff-memory-stale` — `global-memory` is behind origin. This is the serious one: memory written on the other machine is on GitHub and not here, so this session is running on stale context. Fix with `/startup`, or `git -C ~/.claude/global-memory pull --no-rebase`.
- `handoff-behind:<repo>` — config, skills or notes behind origin. Same fix, lower stakes.
- `handoff-unpushed:<repo>` — this machine is more than 3 commits ahead. The other machine cannot see this work; run `/closeout`.
- `handoff-fetch:<repo>` — offline, or GitHub auth has rotted.
- `handoff-repo-gone:<repo>` — the folder is present but is not a git repo. Something replaced a synced repo with a plain folder and its contents are going nowhere.
- A repo absent from the machine entirely is skipped, not failed. `SecondBrain` is Mac-only and its absence on Windows is correct.

The "memory flow" line reports how long since `origin/main` on `global-memory` last advanced. Over 14 days it says so without failing: it cannot distinguish "quiet fortnight" from "the other machine's backup stopped pushing", and a check that cries wolf during the first gets ignored during the second.

**This machine is macOS** (migrated 2026-08-05). Jobs are **launchd user agents** in `~/Library/LaunchAgents/`, not Task Scheduler. The script is PowerShell only because `pwsh` runs it natively; it checks launchd. PowerShell on macOS normalises `\` inside a path string to `/`, so the script's mixed separators resolve correctly — verified 2026-08-29. Do not "fix" them.

Useful launchd commands:
```bash
launchctl list | grep keystone                                    # loaded jobs + last exit code
launchctl print gui/$(id -u)/com.keystone.<name>                  # live schedule and state
launchctl bootout  gui/$(id -u)/com.keystone.<name>               # unload
launchctl bootstrap gui/$(id -u) ~/Library/LaunchAgents/com.keystone.<name>.plist   # reload
```
Edit a schedule with `/usr/libexec/PlistBuddy -c "Set :StartCalendarInterval:Hour <n>" <plist>`, then bootout + bootstrap. **A plist edit alone does nothing until it is reloaded.**

## Weekly scheduled run

launchd agent `com.keystone.stackdoctor` (Mondays 10:30) runs `scripts/weekly-check.ps1`: the same read-only check, unattended. On failure it appends a one-line summary to `~/.claude/global-memory/transcripts/.errors.log` (surfaced at every session start per CLAUDE.md) and the full output is always in `scripts/last-weekly-run.log`. When a session surfaces such an entry, run this skill interactively to diagnose and fix, then clear the entry from `.errors.log`.

**Clearing `.errors.log`:** shell truncation (`: > file`) anywhere under `$HOME` is blocked by dcg rule `core.filesystem:redirect-truncate-root-home`. Use `cp /dev/null <file>`. There is no `truncate` binary on this machine. Archive first — the lines are often live issues, not stale history:
```bash
cp ~/.claude/global-memory/transcripts/.errors.log ~/.claude/global-memory/transcripts/.errors.log.archived-$(date +%Y-%m-%d)
cp /dev/null ~/.claude/global-memory/transcripts/.errors.log
```

## Known failure classes and fixes

These four classes have each bitten more than once (evidence: daily logs 2026-04 → 2026-07). Match the issue code to its fix:

### `task:*` / `task-stale:*` — launchd agent failed or didn't run
1. Read the `action:` line the script printed and run that exact command **manually in a foreground terminal** — launchd discards stdout unless the plist sets `StandardOutPath`; foreground shows the real error.
2. Known root causes: executable referenced without a full path (launchd agents get a minimal PATH — always use full paths like `/opt/homebrew/bin/pwsh`, and set `EnvironmentVariables:PATH` in the plist); a plist edited but never `bootout`+`bootstrap`ed, so the old schedule is still live; the job firing at an hour the required volume is unmounted (see `backup-*`).
3. `launchctl list | grep keystone` shows each job's **last exit code** in column 2. A non-zero there with no output means the script's own log is the only evidence — check `~/.claude/scripts/logs/` and for a `*.log` beside the script.

### `venv-missing` / `venv-broken` — Python venv rot
The script checks `~/.claude/claude-memory-compiler/.venv/bin/python`.
macOS root causes: a Homebrew `python3` major-version bump orphans venvs built against the old interpreter; a `uv` reinstall or relocation breaks tools that hardcode `/Users/kristinarash/.local/bin/uv` (CLAUDE.md forbids relocating it for this reason).
Fix: recreate the venv (`uv sync` in the project, or `python3 -m venv .venv` + reinstall from its pyproject), then run the dependent agent once by hand to confirm.
*History (Windows box, retired 2026-08-14): Python Install Manager migrations deleted `C:\Python31x` twice, silently killing morning-briefing for 6 days. The lesson transfers — an interpreter move breaks every venv built on it — the paths do not.*

### `memsearch-path` / `memsearch-run` — memsearch CLI broken
memsearch is a **uv tool** on this machine: binary at `/Users/kristinarash/.local/bin/memsearch`, environment at `/Users/kristinarash/.local/share/uv/tools/memsearch/`.
- Not on PATH or the binary errors → reinstall with `uv tool install --force memsearch`, not pip.
- Import failures inside the tool env (e.g. `onnxruntime`) are testable directly:
  `/Users/kristinarash/.local/share/uv/tools/memsearch/bin/python -c "import onnxruntime; print(onnxruntime.__version__)"`
- **After ANY reinstall/upgrade of memsearch the local flush patch is stripped.** Re-apply it (notes in `~/.claude/claude-memory-compiler/`), then confirm `.errors.log` stays empty for a session.
- `INDEX full set: Indexed 0 chunks` in the nightly log is **usually not an indexer fault** — it means nothing new arrived. Check `flush-stale` first; a dead flush pipeline starves the indexer and looks identical (confirmed 2026-08-29).

### `errors-log` / `flush-stale` / `flush-error` / `flush-missing` — memory pipeline
- `.errors.log` non-empty → read the entries **before clearing**; they are frequently live unresolved issues rather than stale history. Common causes: the stripped memsearch flush patch (above), or an Agent SDK timeout ("Control request timeout: initialize" — transient, but recurring daily means the hook environment is broken).
- `last-flush.json` stale >48h → check `~/.claude/claude-memory-compiler/scripts/flush.log` tail for the real error. `last-flush.json` is written by `flush.py` **only on success**, so a stale timestamp means flushes are dying, not that the hook never fired.
- **Stranded context files are the tell.** `session-end.py` writes `scripts/session-flush-<session>-<stamp>.md` then spawns `flush.py`, which **deletes that file on success**. So every leftover `session-flush-*.md` in `~/.claude/claude-memory-compiler/scripts/` is a flush that died, and its date maps to a missing `daily/<date>.md`.
  Recover one by re-running it by hand (~1 min, writes into the daily log):
  ```bash
  /Users/kristinarash/.local/bin/uv run --directory ~/.claude/claude-memory-compiler \
    python ~/.claude/claude-memory-compiler/scripts/flush.py <context-file> <session-id>
  ```
  Success looks like `Result: FLUSH_OK` + `Flush complete` in `flush.log`.
- No `SessionEnd fired` lines in `flush.log` for days, yet the hook works when run by hand → sessions are being closed rather than exited cleanly. Self-verifying: end one session normally and re-check the tail.
- FLUSH_ERROR in dailies → same investigation; `flush.log` is ground truth.

### `backup-*` — daily backup rot
launchd agent `com.keystone.dailybackup` (**09:00 daily** since 2026-08-29) runs `~/.claude/scripts/daily-backup.ps1`: auto-commits+pushes the memory repos (SecondBrain, dotclaude, claude-skills, claude-global-memory), **rsync**-snapshots `~/.claude/projects`, `~/.codex`, `~/.gemini` and non-repo DEV folders to Google Drive at `~/Library/CloudStorage/GoogleDrive-eric.rash11@gmail.com/My Drive/…`, captures the same set to the **CRASHBOX SSD** at `/Volumes/CRASHBOX/AssistantBackup/` when it is mounted, runs an uncapped full memsearch reindex, and resets the hook's timeout-streak counter. Restore procedure: `~/.claude/RESTORE.md`.

**The SSD layer's signature failure — a clean exit code is not evidence.** If CRASHBOX is unmounted the run logs `TARGET SSD … NOT MOUNTED … SKIPPED` and still ends `OK (0 errors)`. The schedule moved 00:30 → 09:00 on 2026-08-29 precisely because the drive was never attached at 00:30. **Verify an SSD capture only by a fresh receipt** at `/Volumes/CRASHBOX/AssistantBackup/_receipts/run-*.txt`. Never by directory mtimes (`rsync -a` preserves source mtimes, and a parent dir's mtime moves only when an entry is added or removed — top-level SSD dirs legitimately show weeks-old dates after a perfect capture) and never by `du`. `-DryRun` runs `rsync -n` and proves nothing about writes.
- `backup-missing` / `backup-stale` → job didn't run; re-run foreground (~6 min): `/opt/homebrew/bin/pwsh -File ~/.claude/scripts/daily-backup.ps1`. There is no SSD-only switch, and one should not be added.
- `backup-error` → read `~/.claude/scripts/logs/daily-backup.log`; a `repo-diverged:*` entry means a memory repo has both remote and local changes — reconcile manually (the script refuses to merge from automation).
- `backup-repo-drift:*` → pushes failing (>3 unpushed commits); usually gh/git auth rot — run `gh auth status`.
- `backup-cloud-*` → the Drive-API heartbeat (gws CLI queries RESTORE.md's cloud modifiedTime). `-check` = gws auth rot; re-auth needs explicit full scope URLs: `gws auth login --scopes "https://www.googleapis.com/auth/drive,https://www.googleapis.com/auth/calendar.readonly"` (the `-s drive` shorthand silently grants NO scopes, v0.22.5 bug). After re-auth delete `~/.config/gws/token_cache.json` or it serves the stale token. The login is interactive — Eric must run it himself via `!` while at the machine, then open the printed URL directly; terminal copy/paste truncates it at line-wrap. `-stale`/`-missing` = files reach the local CloudStorage cache but Google Drive for Desktop isn't syncing — check that Google Drive is running and signed in.
- Drive is a **FUSE CloudStorage mount**: it rounds mtimes it did not write, so `rsync -a` re-sends identical files forever. Use `--modify-window=5`; never `--size-only`.

## Not covered by the script (check manually if symptoms point there)

- **MCP/plugin auth rot** (9 manual fix-it sessions on record): run `claude doctor` / `claude mcp list` and re-auth any claude.ai connectors showing failures (Supabase, Vercel, Google Calendar have all rotted before).
- **Catapult OpenField token expiry**: see the auth section of `pp-catapult-openfield-connect`.

## Rules

- Read-only by default: the script never mutates state. Fixes are applied by you, deliberately, after reporting findings.
- Don't assume the obvious culprit — a signal that pattern-matches a known failure may have a different cause (lesson: 6/25 Milvus/ETIMEDOUT misdiagnosis). Confirm with the foreground re-run before fixing.
- When a fix is applied, re-run the script to verify the issue code clears, and note the incident in memory if it's a new failure class.
