# Read-only health check for Eric's automation/memory stack.
# Exit 0 = all clear, exit 1 = issues found (listed in VERDICT).
$ErrorActionPreference = 'Continue'
$fail = @()

function Section($t) { Write-Output "`n=== $t ===" }

Section "launchd agents"
# com.keystone.morningbriefing retired 2026-08-14 (no longer read; Outlook auth had
# lapsed and briefs were going out with 0 email threads). Job booted out and disabled,
# plist retained at ~/Library/LaunchAgents/. To bring it back: re-add it here, then
# `launchctl enable gui/$(id -u)/com.keystone.morningbriefing` and `launchctl bootstrap`.
foreach ($name in 'com.keystone.morning', 'com.keystone.agysync',
                  'com.keystone.dailybackup', 'com.keystone.rituals', 'com.keystone.reconcile', 'com.keystone.adjudicate') {
    $plist = "$HOME/Library/LaunchAgents/$name.plist"
    if (-not (Test-Path $plist)) { "$name : MISSING plist"; $fail += "task-missing:$name"; continue }
    $row = (& launchctl list) | Select-String -Pattern ("\b" + [regex]::Escape($name) + "$") | Select-Object -First 1
    if (-not $row) { "$name : NOT LOADED (launchctl load -w $plist)"; $fail += "task-unloaded:$name"; continue }
    $code = (($row.Line.Trim()) -split "\s+")[1]
    $status = if ($code -eq '0' -or $code -eq '-') { 'OK' } else { "FAIL(code=$code)" }
    if ($status -ne 'OK') { $fail += "task:$name" }
    "$name : $status"
}

Section "Python venvs"
$venvs = @(
    # morning-briefing venv dropped 2026-08-14 with the job above. Later that day the
    # retirement was completed: project removed from disk, secrets destroyed, and the
    # backup-manifest.json entry deleted. Code lives at github.com/erash11/morning-briefing;
    # its 56 briefings remain at ~/SecondBrain/morning-briefings/ and are now in the
    # memsearch index set. See KeystoneOS/projects/retired/morning_briefing.md.
    "$HOME/.claude/claude-memory-compiler/.venv/bin/python"
)
foreach ($py in $venvs) {
    if (-not (Test-Path $py)) { "$py : MISSING"; $fail += "venv-missing"; continue }
    $v = & $py -c "import sys; print(sys.version.split()[0])" 2>&1
    if ($LASTEXITCODE -eq 0) { "$py : OK ($v)" } else { "$py : BROKEN -> $v"; $fail += "venv-broken" }
}

Section "memsearch"
$ms = Get-Command memsearch -ErrorAction SilentlyContinue
if (-not $ms) { "memsearch: NOT ON PATH"; $fail += "memsearch-path" }
else {
    "exe: $($ms.Source)"
    $out = & memsearch search "healthcheck" --top-k 1 2>&1 | Select-Object -First 3
    if ($LASTEXITCODE -eq 0) { "search: OK" } else { "search: FAIL -> $out"; $fail += "memsearch-run" }
}

Section "Memory pipeline"
$errlog = "$HOME/.claude/global-memory/transcripts/.errors.log"
if ((Test-Path $errlog) -and ((Get-Item -Force $errlog).Length -gt 0)) {
    "errors.log: NON-EMPTY (hook failures below)"; Get-Content $errlog -Tail 5; $fail += "errors-log"
} else { "errors.log: clean" }

$lastFlush = "$HOME/.claude/claude-memory-compiler/scripts/last-flush.json"
if (Test-Path $lastFlush) {
    $ageH = (New-TimeSpan -Start (Get-Item $lastFlush).LastWriteTime -End (Get-Date)).TotalHours
    if ($ageH -gt 48) { "last-flush.json: STALE ($([math]::Round($ageH))h old)"; $fail += "flush-stale" }
    else { "last-flush.json: OK ($([math]::Round($ageH))h ago)" }
} else { "last-flush.json: MISSING"; $fail += "flush-missing" }

$daily = "$HOME/.claude/claude-memory-compiler\daily"
$recent = Get-ChildItem $daily -Filter '*.md' -ErrorAction SilentlyContinue | Sort-Object Name -Descending | Select-Object -First 3
$flushErr = $recent | Select-String -Pattern 'FLUSH_ERROR' | Select-Object -First 3
if ($flushErr) {
    "FLUSH_ERROR in recent dailies:"; $flushErr | ForEach-Object { "  $($_.Filename):$($_.LineNumber)" }
    $fail += "flush-error"
} else { "recent dailies (3): no FLUSH_ERROR" }

Section "Backup freshness"
$bkState = "$HOME/.claude/scripts/logs/backup-state.json"
if (-not (Test-Path $bkState)) { "backup-state.json: MISSING (daily-backup has never run?)"; $fail += "backup-missing" }
else {
    $bk = Get-Content $bkState -Raw | ConvertFrom-Json
    $ageH = (New-TimeSpan -Start ([datetime]$bk.lastRun) -End (Get-Date)).TotalHours
    # daily-backup.ps1 writes backup-state.json even under -DryRun. A dry run copies
    # nothing, so a dry-run "OK" must never be read as a healthy backup - doing so
    # masks the last REAL run's failure. Observed 2026-08-14: a diagnostic dry run at
    # 20:54 overwrote the 20:38 real-run ERROR and cleared backup-error from this
    # VERDICT while nothing had actually been backed up since the failure.
    # dryRun is a MODIFIER, not a branch: a dry run can also be stale or errored, and an
    # earlier version that returned early on dryRun would report a 40h-old dry run without
    # ever raising backup-stale. Keep the signals independent so every true condition fires.
    # ($bk.dryRun is $null on state files predating the field, which is falsy - correct.)
    $mode = if ($bk.dryRun) { ' [DRY RUN - nothing was copied]' } else { '' }
    if ($bk.dryRun) { $fail += "backup-dryrun-only" }
    $h = [math]::Round($ageH)
    if ($ageH -gt 30) { "last backup: STALE (${h}h ago)$mode"; $fail += "backup-stale" }
    elseif ($bk.status -ne 'OK') { "last backup: ERROR ($($bk.errors -join ', '))$mode"; $fail += "backup-error" }
    else { "last backup: OK (${h}h ago, $($bk.okCount) targets)$mode" }
}
$bkRepos = @(
    @{ p = "$HOME/SecondBrain"; b = 'main' },
    @{ p = "$HOME/.claude/global-memory"; b = 'main' },
    @{ p = "$HOME/.claude"; b = 'main' },
    @{ p = "$HOME/.claude/skills"; b = 'main' }
)
foreach ($r in $bkRepos) {
    if (-not (Test-Path (Join-Path $r.p '.git'))) { "$($r.p): NOT A REPO"; $fail += "backup-repo-gone"; continue }
    Push-Location $r.p
    $counts = git rev-list --left-right --count "origin/$($r.b)...HEAD" 2>$null
    $ahead = if ($counts) { [int](($counts -split '\s+')[1]) } else { 0 }
    $name = Split-Path $r.p -Leaf
    if ($ahead -gt 3) { "$name : $ahead unpushed commit(s) - pushes may be failing"; $fail += "backup-repo-drift:$name" }
    else { "$name : synced (ahead=$ahead)" }
    Pop-Location
}

# Cloud-side verification: rsync proves files reached the local DriveFS cache, not that
# Google's servers have them. The per-run receipts (_receipts/run-<id>.txt) are written
# with fresh content every run, so the newest one's Drive-side modifiedTime is a heartbeat
# for the whole DriveFS sync path.
#
# Was RESTORE.md until 2026-08-14. That was a false-positive generator: the job *copies*
# RESTORE.md (Copy-Item -Force, daily-backup.ps1:411) rather than rewriting it, so the
# copy carries the source's mtime. RESTORE.md hadn't changed since 2026-08-05, so this
# check reported "STALE (218h)" and "DriveFS sync may be broken" while sync was in fact
# healthy — the receipt written 07:23 CDT was on Google's servers at 12:23:54Z, matching
# the local mtime to the second.
$gwsCmd = Get-Command gws -ErrorAction SilentlyContinue
if ($gwsCmd) {
    $q = '{"q":"name contains ''run-2'' and trashed = false","orderBy":"modifiedTime desc","fields":"files(name,modifiedTime)","pageSize":3}'
    $out = & gws drive files list --params $q 2>&1
    if ($LASTEXITCODE -ne 0) {
        "cloud check: gws Drive query FAILED (auth rot? re-run: gws auth login --scopes drive.readonly,calendar.readonly full URLs)"
        $fail += "backup-cloud-check"
    } else {
        $j = (($out | Where-Object { $_ -notmatch '^Using keyring' }) -join "`n") | ConvertFrom-Json
        # ConvertFrom-Json may hand back a DateTime (kind varies) or a raw string;
        # normalize to UTC either way — naive local comparison produced "-4h" ages.
        $mt = $j.files | ForEach-Object {
            $v = $_.modifiedTime
            if ($v -is [datetime]) { $v.ToUniversalTime() } else { ([DateTimeOffset]::Parse($v)).UtcDateTime }
        } | Sort-Object -Descending | Select-Object -First 1
        if (-not $mt) { "cloud check: no backup receipt found in Drive"; $fail += "backup-cloud-missing" }
        else {
            $ageH = ((Get-Date).ToUniversalTime() - $mt).TotalHours
            if ($ageH -gt 48) { "cloud check: newest Drive-side receipt STALE ($([math]::Round($ageH))h old) - DriveFS sync may be broken"; $fail += "backup-cloud-stale" }
            else { "cloud check: Google's servers have the latest backup receipt ($([math]::Round($ageH))h old) - sync path verified" }
        }
    }
} else { "cloud check: gws CLI not installed (skipped)" }

Section "Context budget"
# Skill descriptions are preloaded into EVERY session, so this is a per-session
# tax paid whether or not a skill fires. It regrows silently: the 2026-07-13
# skill audit pruned the set, and by 2026-07-24 it was back to 105 skills /
# 42,885 chars (~10,700 tokens). Archiving 45 dead/dormant skills brought it to
# ~27,000. A number nobody watches is a number that drifts, so watch it.
$skillRoot = "$HOME/.claude/skills"
# A skill set to "off" in settings.json's skillOverrides is NOT loaded into the
# session listing, so it costs zero context and must not be counted. Before
# 2026-08-11 this loop counted every SKILL.md on disk, which reported 133 skills
# / 65,467 chars as OVER budget while 72 of them were already disabled — a false
# positive that fired every weekly run and spammed .errors.log. Read only the
# skillOverrides key; settings.json also holds env/secrets.
$off = @{}
$settingsPath = "$HOME/.claude/settings.json"
if (Test-Path $settingsPath) {
    try {
        $so = (Get-Content $settingsPath -Raw | ConvertFrom-Json).skillOverrides
        if ($so) {
            foreach ($p in $so.PSObject.Properties) {
                if ($p.Value -eq 'off') { $off[$p.Name] = $true }
            }
        }
    } catch { }
}
$descChars = 0; $skillCount = 0; $offCount = 0
foreach ($d in Get-ChildItem $skillRoot -Directory -ErrorAction SilentlyContinue) {
    $sk = Join-Path $d.FullName 'SKILL.md'
    if (-not (Test-Path $sk)) { continue }
    if ($off.ContainsKey($d.Name)) { $offCount++; continue }
    $raw = Get-Content $sk -Raw
    if ($raw -match '(?s)description:\s*(.*?)(\n[a-z-]+:|\n---)') {
        $descChars += (($Matches[1] -replace '\s+', ' ').Trim()).Length
        $skillCount++
    }
}
if ($offCount) { "skill overrides: $offCount skill(s) disabled in settings.json - excluded from tax" }
$budget = 32000
$pct = if ($budget) { [math]::Round(100 * $descChars / $budget) } else { 0 }
if ($descChars -gt $budget) {
    "skill tax: $skillCount skills, $descChars chars (~$([math]::Round($descChars/4)) tokens) - OVER budget $budget ($pct%)"
    "  -> archive unused skills to ~/.claude/skills-archive, or trim descriptions to trigger conditions only"
    $fail += "skill-tax"
} else {
    "skill tax: $skillCount skills, $descChars chars (~$([math]::Round($descChars/4)) tokens) - OK ($pct% of $budget)"
}

# Both files are loaded every session and both have caps declared in CLAUDE.md.
# At >95% the next write is a forced consolidation, and consolidations made
# under pressure drop facts quietly. Flag before it gets there, not after.
foreach ($m in @(
    @{ f = "$HOME/.claude/global-memory\USER.md";   cap = 1375 },
    @{ f = "$HOME/.claude/global-memory\MEMORY.md"; cap = 2500 })) {
    $n = Split-Path $m.f -Leaf
    if (-not (Test-Path $m.f)) { "$n : MISSING"; $fail += "memfile-missing:$n"; continue }
    $len = (Get-Item $m.f).Length
    $p = [math]::Round(100 * $len / $m.cap)
    if ($p -ge 95) { "$n : $len/$($m.cap) chars ($p%) - NO HEADROOM, consolidate deliberately before the next write forces it"; $fail += "memfile-full:$n" }
    else { "$n : $len/$($m.cap) chars ($p%) - OK" }
}

# Cross-machine handoff. Lives in its own script because it is the one check that
# must also run on the Windows laptop, where the launchd section above cannot. The
# backup section measures `ahead` and so catches a failing push; this catches the
# opposite and previously invisible failure, a push that succeeded and a pull that
# never happened.
$handoff = Join-Path $PSScriptRoot 'handoff-check.ps1'
if (Test-Path $handoff) {
    & $handoff
    if ($LASTEXITCODE -ne 0) { $fail += "handoff" }
} else {
    "`n=== Cross-machine handoff ===`nhandoff-check.ps1: MISSING"
    $fail += "handoff-check-missing"
}

Section "VERDICT"
if ($fail.Count -eq 0) { "ALL CLEAR" } else { "$($fail.Count) issue(s): $($fail -join ', ')" }
exit [int]($fail.Count -gt 0)
