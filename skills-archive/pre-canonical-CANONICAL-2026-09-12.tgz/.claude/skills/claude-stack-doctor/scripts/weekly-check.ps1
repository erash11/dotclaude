# Weekly unattended stack-doctor run (launchd: com.keystone.stackdoctor).
# Runs the read-only stack-check and, ONLY on failure, appends a one-line
# summary to global-memory .errors.log — which every Claude session surfaces
# at startup per CLAUDE.md. Silence in that file means the check passed.
# Full output of the most recent run is always kept in last-weekly-run.log.

$check = Join-Path $PSScriptRoot 'stack-check.ps1'
$out = & '/opt/homebrew/bin/pwsh' -NoProfile -File $check 2>&1 | Out-String
$failed = $LASTEXITCODE -ne 0

Set-Content -Path (Join-Path $PSScriptRoot 'last-weekly-run.log') -Value $out -Encoding utf8

if ($failed) {
    $verdict = (($out -split "`r?`n") | Where-Object { $_ -match '^\d+ issue' } | Select-Object -First 1)
    if (-not $verdict) { $verdict = 'check failed (no VERDICT line — see last-weekly-run.log)' }
    $stamp = Get-Date -Format o
    $entry = "[$stamp] stack-doctor weekly: $verdict — details in ~/.claude/skills/claude-stack-doctor/scripts/last-weekly-run.log; run /claude-stack-doctor to fix"
    Add-Content -Path "$HOME/.claude/global-memory/transcripts/.errors.log" -Value $entry -Encoding utf8
}
exit 0
