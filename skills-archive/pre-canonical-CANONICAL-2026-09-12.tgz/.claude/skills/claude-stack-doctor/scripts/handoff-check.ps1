# handoff-check.ps1 -- does the cross-machine handoff actually work?
#
# Every other check in this stack verifies a COMPONENT. None verified the PATH.
# That is how ~/.claude/global-memory sat 4 commits behind origin on the Windows
# laptop while every other signal read healthy: daily-backup pushed it nightly,
# nothing on the receiving machine ever pulled, and no check looked for "behind".
# stack-check.ps1's backup section measures `ahead` only, which catches a failing
# push and is blind to a missing pull.
#
# Runs on macOS and Windows. Deliberately separate from stack-check.ps1, whose
# launchd section is Mac-only -- the receiving machine needs this check most, and
# it must not be gated behind a section that cannot run there.
#
# Exit 0 = handoff healthy, exit 1 = issues (listed in HANDOFF VERDICT).
$ErrorActionPreference = 'Continue'
$fail = @()
$U = $HOME

# The four repos that carry state between the two machines. global-memory is the
# only one that carries MEMORY -- the others carry config, skills and notes.
$repos = @(
    @{ p = "$U/.claude/global-memory"; b = 'main'; memory = $true  },
    @{ p = "$U/.claude";               b = 'main'; memory = $false },
    @{ p = "$U/.claude/skills";        b = 'main'; memory = $false },
    @{ p = "$U/SecondBrain";           b = 'main'; memory = $false }
)

Write-Output "`n=== Cross-machine handoff ==="

foreach ($r in $repos) {
    $name = Split-Path $r.p -Leaf
    # Not every repo lives on both machines -- SecondBrain is Mac-only. An absent
    # folder is a fact about this machine, not a fault, so skip it. Present but not
    # a repo IS a fault: something replaced a synced repo with a plain folder, and
    # its contents are going nowhere.
    if (-not (Test-Path $r.p)) { "$name : not on this machine (skipped)"; continue }
    if (-not (Test-Path (Join-Path $r.p '.git'))) {
        "$name : PRESENT BUT NOT A REPO - nothing here is syncing"; $fail += "handoff-repo-gone:$name"; continue
    }

    # The one write this script makes: `git fetch` updates remote-tracking refs.
    # It is unavoidable -- "behind" cannot be computed without asking the remote,
    # and a cached answer is exactly the stale reading this check exists to catch.
    # It does not touch the working tree, the index, or any branch.
    git -C $r.p fetch -q origin 2>$null | Out-Null
    if ($LASTEXITCODE -ne 0) {
        "$name : FETCH FAILED (offline, or auth rot)"; $fail += "handoff-fetch:$name"; continue
    }

    $counts = git -C $r.p rev-list --left-right --count "origin/$($r.b)...HEAD" 2>$null
    if (-not $counts) { "$name : no upstream $($r.b)"; $fail += "handoff-upstream:$name"; continue }
    $parts  = $counts -split '\s+'
    $behind = [int]$parts[0]
    $ahead  = [int]$parts[1]

    if ($behind -gt 0) {
        $verb = if ($r.memory) { 'MEMORY IS STALE' } else { 'behind' }
        "$name : $verb - $behind commit(s) on GitHub not on this machine"
        "  -> git -C $($r.p) pull --no-rebase   (or run /startup, which does all four)"
        $fail += $(if ($r.memory) { "handoff-memory-stale" } else { "handoff-behind:$name" })
    }
    elseif ($ahead -gt 3) {
        "$name : $ahead unpushed commit(s) - the other machine cannot see this work"
        $fail += "handoff-unpushed:$name"
    }
    else {
        "$name : in sync (behind=$behind ahead=$ahead)"
    }
}

# Is the OTHER machine still contributing? If origin/main on global-memory has not
# advanced in a fortnight, either no work happened over there (fine, and common) or
# its daily-backup has quietly stopped pushing (not fine, and invisible until you
# need the memory). This cannot tell the two apart, so it informs rather than fails
# -- a check that cries wolf during a quiet fortnight gets ignored during a real one.
$gm = "$U/.claude/global-memory"
if (Test-Path (Join-Path $gm '.git')) {
    $originEpoch = git -C $gm log -1 --format=%ct origin/main 2>$null
    if ($originEpoch) {
        $age = ((Get-Date).ToUniversalTime() - [DateTimeOffset]::FromUnixTimeSeconds([int]$originEpoch).UtcDateTime).TotalDays
        $d = [math]::Round($age, 1)
        if ($age -gt 14) {
            "memory flow: origin/main has not advanced in $d days"
            "  -> if you have worked on the other machine since, its daily-backup push is broken"
        } else {
            "memory flow: origin/main last advanced $d days ago - both machines reaching GitHub"
        }
    }
}

Write-Output "`n=== HANDOFF VERDICT ==="
if ($fail.Count -eq 0) { "HANDOFF HEALTHY" } else { "$($fail.Count) issue(s): $($fail -join ', ')" }
exit [int]($fail.Count -gt 0)
