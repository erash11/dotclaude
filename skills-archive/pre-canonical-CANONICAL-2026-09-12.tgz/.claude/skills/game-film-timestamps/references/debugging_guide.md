# Debugging Guide: Count Mismatches

When the number of ESPN plays doesn't match the number of plays in the JSON file, you need to
investigate. This guide covers the most common causes and how to resolve them.

## Quick Diagnostic Steps

1. Run the script with `--verbose` to see every play
2. Compare the script's categorized play list against the JSON file's play count
3. Look at the difference: is ESPN short (missing plays) or long (extra plays)?

## Common Causes by File Type

### DEF File (Opponent Offensive Plays)

**ESPN has fewer plays than JSON (most common: off by 1-2)**

Cause: NO PLAY penalties. False starts, illegal formations, and similar penalties result in
"NO PLAY" in the ESPN data. Some game film software counts these as plays, some doesn't.

Fix: Use `--penalty-mode include-all` to include all NO PLAY penalties. If that overshoots,
the `auto` mode will include just enough to match.

**ESPN has more plays than JSON**

Cause: Rarely, ESPN includes duplicate entries (e.g., two identical "takes a knee" at Q4 0:00).
Or a penalty play that the film software didn't count.

Fix: Manually inspect the ESPN play list and identify the duplicate. You may need to modify
the script to exclude the specific duplicate.

### KICKS File (Special Teams)

**ESPN has fewer plays than JSON (most common: off by 1-3)**

Cause: PATs (Point After Touchdown attempts). ESPN doesn't list PATs as separate plays. They're
embedded in the touchdown play text (e.g., "...for a TD (Alex McPherson KICK)"). The script
generates synthetic PAT entries.

Things to check:
- Count the TDs in the game. Each TD should generate one PAT entry.
- Kickoff Return TDs count as both a kick play AND a TD source for PATs.
- Two-point conversion attempts may or may not be in the KICKS file.
- Failed PATs ("no good") still count as PAT attempts.

**The math should be: kick-type plays + PATs = KICKS count**

Typical kick-type plays: Kickoffs, Kickoff Returns, Punts, Punt Returns, Field Goals,
and penalty plays that happened during kicking situations (e.g., illegal formation on a punt).

### OFF File (Our Team's Offensive Plays)

**Off by 1 (either direction)**

Cause: Usually a declined penalty. ESPN shows declined penalties as separate entries. The
script excludes them by default (since "declined" means the play stood), but the film
software might handle this differently.

Fix: Check if any declined penalties exist in the game. Try `--penalty-mode include-all`
or manually review the ESPN play list for declined penalties on our team's drives.

## Manual Investigation

When auto mode can't resolve the mismatch, investigate manually:

```python
import json

with open('espn_data.json') as f:
    espn = json.load(f)

drives = espn['drives']['previous']
for drive in drives:
    team = drive['team']['abbreviation']
    for play in drive['plays']:
        ptype = play['type']['text']
        text = play['text']
        q = play['period']['number']
        clock = play['clock']['displayValue']
        print(f"Q{q} {clock} [{ptype}] {team} - {text[:80]}")
```

Look for:
- Plays that appear twice with the same clock time
- Penalty plays with "NO PLAY" that might be included/excluded differently
- Declined penalties
- Special situations (safety, two-point conversion, onside kick)

## ESPN Play Types Reference

Common types and where they should be categorized:

| ESPN Play Type | Category |
|---|---|
| Rush | OFF or DEF (by drive team) |
| Pass Reception | OFF or DEF |
| Pass Incompletion | OFF or DEF |
| Passing Touchdown | OFF or DEF |
| Rushing Touchdown | OFF or DEF |
| Sack | OFF or DEF |
| Fumble Recovery (Own) | OFF or DEF |
| Kickoff | KICKS |
| Kickoff Return (Offense) | KICKS |
| Kickoff Return Touchdown | KICKS (also generates PAT) |
| Punt | KICKS |
| Punt Return | KICKS |
| Punt Return Touchdown | KICKS (also generates PAT) |
| Field Goal Good | KICKS |
| Field Goal Missed | KICKS |
| Penalty | Context-dependent (see below) |
| Timeout | Skip |
| End Period | Skip |
| End of Half | Skip |
| End of Game | Skip |

### Penalty Categorization

- Punt-related penalties (text contains "punt"): KICKS
- Declined penalties: Skip
- NO PLAY penalties (false start, etc.): Depends on mode
- All other penalties: OFF or DEF by drive team
