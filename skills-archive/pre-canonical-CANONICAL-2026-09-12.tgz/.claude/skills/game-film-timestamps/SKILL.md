---
name: game-film-timestamps
description: >
  Fix wrong startTime/endTime values in football game film JSON exported from Hudl, DVSport, or
  similar. Fetches correct wall-clock timestamps from the ESPN API and writes corrected copies.
  Use whenever the user mentions fixing or correcting play-by-play timestamps in game film JSON,
  or has files with "OFF", "DEF", or "KICKS" in the filename and mentions timestamps or time issues.
argument-hint: "[game-files folder]"
---

# Game Film Timestamp Corrector

## What This Skill Does

Football video analysis platforms export JSON files containing play-by-play annotations. Each play
has a `startTime` and `endTime` that should represent the real-world wall clock moment the play
happened. In practice, these timestamps are frequently wrong by hours.

This skill corrects those timestamps by cross-referencing play data from ESPN's public API, which
includes accurate `wallclock` values for every play in a game.

## CRITICAL: Never Modify Original Files

The corrected output files go in the SAME directory as the originals, with a `_corrected` suffix
appended before the `.json` extension. For example:

- `2501 BU OFF vs AUB TRADE.json` -> `2501 BU OFF vs AUB TRADE_corrected.json`

The original files are the user's source-of-truth video references. Overwriting them would break
their video analysis workflow and lose data that cannot be recovered. The correction script's
`--suffix` flag handles this automatically. Never pass an output path that matches an input path.
Never write corrected data back to the original filename. If something goes wrong and the script
does not create `_corrected` files, stop and investigate rather than overwriting.

## How the Files Are Organized

A typical game produces three JSON files, usually with a naming pattern like:

- `XXXX TEAM OFF vs OPP TRADE.json` (team's offensive plays)
- `XXXX TEAM DEF vs OPP TRADE.json` (opponent's offensive plays, i.e., team's defense)
- `XXXX TEAM KICKS vs OPP TRADE.json` (special teams: kickoffs, punts, field goals, PATs)

Each file shares the same structure:
- `timePeriods` array containing `annotation` entries (individual plays) and one `period` entry (container)
- Each annotation has `startTime`, `endTime`, `displayName` (e.g., "Play 001"), `id`, `parentId`, `metaData`
- Timestamps use an ISO 8601 format with UTC offset, like `2025-08-29T09:50:44.5020000-05:00`

The `displayName` field follows a pattern: `"XXXX TEAM OFF vs OPP TRADE, Play 001"`. The plays
are numbered sequentially within each file.

## Pre-Check: Are the Timestamps Already Correct?

Before running any correction, the script validates whether the existing timestamps are already
reasonable. It samples plays from each file and checks three things:

1. **Game window**: Do the timestamps fall between 15 minutes before kickoff and 4.5 hours after?
2. **First play proximity**: Is the first play within 30 minutes of kickoff?
3. **Chronological order**: Are the plays ordered earliest-to-latest?

If all three checks pass for every file, the script reports "ALL TIMESTAMPS ALREADY CORRECT" and
exits without writing any output files. If some files pass and others fail, only the failing files
get corrected.

You can also run a check without writing any files by passing `--check-only`:

```bash
python3 SKILL_DIR/scripts/correct_timestamps.py \
  --espn-data /tmp/espn_game_data.json \
  --json-dir /path/to/game/files \
  --our-team BAY \
  --kickoff "2025-08-29T19:00:00-05:00" \
  --check-only
```

The `--tolerance` flag adjusts how close the first play must be to kickoff (default: 30 minutes).
For games with long delays or weather postponements, you might raise this to 60 or 90 minutes.

## Workflow

### Step 1: Auto-Detect Game Context

Most game information can be extracted automatically. Scan the folder for JSON files matching
the OFF/DEF/KICKS pattern and extract:

1. **Team abbreviations** from filenames. The pattern is `TEAM OFF vs OPP` where TEAM is "ours"
   and OPP is the opponent. Common abbreviations: BU = Baylor, AUB = Auburn, etc.

2. **Approximate game date** from the existing timestamps in the files. Even though the hours
   are wrong, the date portion is usually correct or within a day. Read the first annotation's
   `startTime` to get the date.

3. **Timezone offset** from the existing timestamps. The offset in the original files (e.g.,
   `-05:00` for CDT, `-06:00` for CST) tells you what timezone to use for the corrected output.

4. **"Our" team** is always the first abbreviation in the filename (before OFF/DEF/KICKS).

Then confirm with the user: "I found [TEAM] vs [OPP] files dated around [DATE]. I'll look up
this game on ESPN. Does that sound right?" If the user already told you the game details, skip
the confirmation and proceed.

The only piece you truly need the user to confirm is if the auto-detected date is ambiguous
(e.g., timestamps show a date that's off by a day due to the time error). The kickoff time
itself comes from ESPN's API, not from the user.

### Step 2: Find the ESPN Game and Fetch Data

Use the ESPN scoreboard API to find the game. The scoreboard endpoint lists all games for a date:

```
https://site.api.espn.com/apis/site/v2/sports/football/college-football/scoreboard?dates=YYYYMMDD
```

Search through the returned games to find the one matching both team abbreviations. Extract the
event ID, then fetch the full game summary:

```
https://site.api.espn.com/apis/site/v2/sports/football/college-football/summary?event={EVENT_ID}
```

Use the `apify-slash-rag-web-browser` tool or `WebFetch` to fetch these URLs. Save the summary
response to a temporary JSON file (e.g., `/tmp/espn_game_data.json`).

From the summary response, also extract the scheduled kickoff time from the `header.competitions`
data. This gives you the kickoff in UTC, which combined with the timezone offset from the original
files, provides everything needed for timezone conversion. No need to ask the user for kickoff time.

### Step 3: Run the Correction Script

Run the bundled correction script. Replace `SKILL_DIR` with the actual path to this skill's directory:

```bash
python3 SKILL_DIR/scripts/correct_timestamps.py \
  --espn-data /tmp/espn_game_data.json \
  --json-dir /path/to/folder/with/game/files \
  --our-team BAY \
  --kickoff "2025-08-29T19:00:00-05:00" \
  --suffix "_corrected"
```

**Arguments:**
- `--espn-data`: Path to the saved ESPN API JSON response
- `--json-dir`: Directory containing the OFF/DEF/KICKS JSON files
- `--our-team`: The abbreviation for "our" team (extracted from filenames in Step 1)
- `--kickoff`: ISO 8601 kickoff time with timezone offset. Construct this from the ESPN header's
  UTC kickoff time converted to the timezone offset found in the original files.
- `--suffix`: Suffix for output filenames. Always use `_corrected` (the default).

The script creates new files alongside the originals. It never modifies the originals. Verify
this by checking that the original files' modification timestamps haven't changed after the run.

The script handles:
- Extracting wallclock timestamps from every ESPN play
- Categorizing plays into OFF, DEF, and KICKS to match the JSON files
- Generating PAT entries for the KICKS file (PATs are embedded in TD play text in ESPN data,
  not separate plays, but the game film files track them as separate plays)
- Handling edge cases: declined penalties, false start NO PLAY penalties, punt-related penalties
- Detecting and fixing known ESPN wallclock bugs (duplicate timestamps, timestamps that jump backward)
- Writing corrected files with the `_corrected` suffix, preserving all other data

### Step 4: Verify the Results

After the script runs, verify:
1. **Play counts match**: The script reports how many plays it found for each category vs how
   many the JSON file contains. These must be equal.
2. **Timestamps are chronological**: All plays within each file should have increasing startTimes.
3. **Timestamps fall within the game window**: First play should be near kickoff, last play should
   be within a reasonable game duration (typically 3-4 hours for college football).
4. **Format is preserved**: The output timestamps should match the original format with 7-digit
   fractional seconds and the same UTC offset (e.g., `.0000000-05:00`).
5. **Originals are intact**: Confirm the original files were not modified.

If play counts don't match, the script will report the mismatch and you will need to debug.
Read the `references/debugging_guide.md` file for guidance on common count mismatches and how
to resolve them.

### Step 5: Handle Count Mismatches (If Needed)

Count mismatches are common and usually fall into a few patterns. The debugging guide covers these
in detail, but the most frequent causes are:

- **DEF count off by 1-2**: Usually caused by penalty handling. "NO PLAY" penalties (like false
  starts) may or may not be counted as plays in the game film software. The script's `auto` mode
  tries to include just enough NO PLAY penalties to match the target count. If that doesn't work,
  try `--penalty-mode include-all` or `--penalty-mode exclude-all`.

- **KICKS count off by 1-2**: Usually caused by PAT generation. The script generates PATs from
  all touchdowns (including kick/punt return TDs). If the game film excludes a PAT (e.g., after
  a 2-point conversion attempt) or includes extra entries, the count will be off.

- **OFF count off**: Less common. Usually caused by a declined penalty being included or excluded
  differently than expected.

When counts don't match, look at the script's diagnostic output to identify which plays are
missing or extra, then adjust the script parameters accordingly.

## Important Notes on ESPN Data Quality

ESPN's wallclock data is generally reliable but has known issues:
- **Duplicate wallclocks**: Occasionally two consecutive plays share the exact same wallclock
  timestamp. This is usually fine (the plays happened in quick succession).
- **Backward jumps**: Rarely, a play's wallclock will show a time earlier than the previous play.
  The script detects these and estimates a corrected time based on surrounding plays.
- **Halftime persistence**: Some plays right after halftime may still carry a pre-halftime
  wallclock. The script detects these by checking if the wallclock is more than 15 minutes
  behind the expected game progression.

These anomalies are rare (typically 0-2 per game) and the script handles them automatically.

## UTC Offset Handling

The original JSON files use a specific UTC offset format (e.g., `-05:00` for CDT). The script
preserves whatever offset is found in the original files. It converts ESPN's UTC wallclocks
(which always end in `Z`) to the local timezone offset found in the source files.

The `--kickoff` parameter's timezone offset is used to determine the target timezone for conversion.
For example, `--kickoff "2025-08-29T19:00:00-05:00"` means CDT (UTC-5).
