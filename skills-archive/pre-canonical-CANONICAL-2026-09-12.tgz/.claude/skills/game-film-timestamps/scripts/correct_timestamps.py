#!/usr/bin/env python3
"""
Game Film Timestamp Corrector

Corrects timestamps in football game film JSON files by cross-referencing
play-by-play wallclock data from ESPN's API.

Usage:
    python correct_timestamps.py \
        --espn-data espn_response.json \
        --json-dir /path/to/game/files \
        --our-team BAY \
        --kickoff "2025-08-29T19:00:00-05:00" \
        --suffix "_corrected"
"""

import argparse
import copy
import glob
import json
import os
import re
import sys
from datetime import datetime, timedelta, timezone


def parse_args():
    parser = argparse.ArgumentParser(description="Correct game film timestamps using ESPN data")
    parser.add_argument("--espn-data", required=True, help="Path to saved ESPN API JSON response")
    parser.add_argument("--json-dir", required=True, help="Directory containing OFF/DEF/KICKS JSON files")
    parser.add_argument("--our-team", required=True, help="Abbreviation for 'our' team (e.g., BAY)")
    parser.add_argument("--kickoff", required=True, help="Kickoff time in ISO 8601 (e.g., 2025-08-29T19:00:00-05:00)")
    parser.add_argument("--suffix", default="_corrected", help="Suffix for output filenames (default: _corrected)")
    parser.add_argument("--penalty-mode", default="auto", choices=["auto", "include-all", "exclude-all"],
                        help="How to handle NO PLAY penalties: auto (try to match counts), include-all, exclude-all")
    parser.add_argument("--verbose", action="store_true", help="Print detailed play-by-play info")
    parser.add_argument("--check-only", action="store_true",
                        help="Only check whether timestamps need correction; do not write any files")
    parser.add_argument("--tolerance", type=int, default=30,
                        help="Minutes of tolerance for timestamp validation (default: 30). "
                             "Timestamps within this window of the expected game time are considered correct.")
    return parser.parse_args()


def make_utc(s):
    """Parse a UTC timestamp string (ending in Z) to a datetime object."""
    return datetime.fromisoformat(s.replace('Z', '+00:00'))


def utc_to_local_str(utc_str, target_tz):
    """Convert UTC wallclock string to local time string in the original file format."""
    if not utc_str:
        return None
    dt = datetime.fromisoformat(utc_str.replace('Z', '+00:00'))
    dt_local = dt.astimezone(target_tz)
    # Format: 2025-08-29T19:07:46.0000000-05:00
    offset = dt_local.strftime('%z')
    offset_formatted = f"{offset[:3]}:{offset[3:]}"
    return dt_local.strftime('%Y-%m-%dT%H:%M:%S') + '.0000000' + offset_formatted


def detect_timezone(kickoff_str):
    """Extract timezone from the kickoff string."""
    dt = datetime.fromisoformat(kickoff_str)
    return dt.tzinfo


def find_game_files(json_dir, our_team):
    """Find OFF, DEF, and KICKS JSON files in the directory."""
    all_json = glob.glob(os.path.join(json_dir, '*.json'))

    off_file = None
    def_file = None
    kicks_file = None

    for f in all_json:
        basename = os.path.basename(f).upper()
        # Skip already-corrected files
        if '_CORRECTED' in basename:
            continue
        if f' {our_team.upper()} OFF ' in f' {basename} ' or f'{our_team.upper()} OFF' in basename:
            off_file = f
        elif f' {our_team.upper()} DEF ' in f' {basename} ' or f'{our_team.upper()} DEF' in basename:
            def_file = f
        elif f' {our_team.upper()} KICKS ' in f' {basename} ' or f'{our_team.upper()} KICKS' in basename:
            kicks_file = f

    # More flexible matching if strict didn't work
    if not all([off_file, def_file, kicks_file]):
        for f in all_json:
            basename = os.path.basename(f)
            if '_corrected' in basename.lower():
                continue
            bn_upper = basename.upper()
            if not off_file and 'OFF' in bn_upper and our_team.upper() in bn_upper:
                off_file = f
            elif not def_file and 'DEF' in bn_upper and our_team.upper() in bn_upper:
                def_file = f
            elif not kicks_file and 'KICK' in bn_upper and our_team.upper() in bn_upper:
                kicks_file = f

    return off_file, def_file, kicks_file


def count_annotations(filepath):
    """Count annotation entries in a JSON file."""
    with open(filepath) as f:
        data = json.load(f)
    return len([p for p in data['timePeriods'] if p['type'] == 'annotation'])


def extract_espn_plays(espn_data):
    """Extract all plays from ESPN data with their metadata."""
    drives = espn_data.get('drives', {}).get('previous', [])
    all_plays = []

    for drive in drives:
        team = drive.get('team', {}).get('abbreviation', '?')
        for play in drive.get('plays', []):
            all_plays.append({
                'type': play.get('type', {}).get('text', ''),
                'wallclock': play.get('wallclock', ''),
                'clock': play.get('clock', {}).get('displayValue', ''),
                'period': play.get('period', {}).get('number', 0),
                'text': play.get('text', ''),
                'drive_team': team,
                'scoring': play.get('scoringPlay', False),
            })

    return all_plays


def fix_bad_wallclocks(plays, kickoff_utc):
    """
    Detect and fix ESPN wallclock anomalies:
    - Wallclocks that jump backward (earlier than the previous play)
    - Wallclocks that appear stuck at a much earlier time
    """
    fixes = []

    for i, p in enumerate(plays):
        if not p['wallclock']:
            continue

        current_wc = make_utc(p['wallclock'])

        # Check if this wallclock is suspiciously early compared to neighbors
        # Look at the previous non-skipped play and next non-skipped play
        prev_wc = None
        next_wc = None

        for j in range(i - 1, max(i - 5, -1), -1):
            if plays[j].get('wallclock'):
                prev_wc = make_utc(plays[j]['wallclock'])
                break

        for j in range(i + 1, min(i + 5, len(plays))):
            if plays[j].get('wallclock'):
                next_wc = make_utc(plays[j]['wallclock'])
                break

        needs_fix = False

        # Case 1: Current wallclock is more than 10 minutes before the previous play
        if prev_wc and current_wc < prev_wc - timedelta(minutes=10):
            needs_fix = True

        # Case 2: Current wallclock matches the game start (stuck at kickoff time)
        game_start_wc = kickoff_utc
        if prev_wc and abs((current_wc - game_start_wc).total_seconds()) < 60 and \
           (prev_wc - game_start_wc).total_seconds() > 600:
            needs_fix = True

        if needs_fix:
            # Estimate based on surrounding plays
            if prev_wc and next_wc:
                estimated = prev_wc + (next_wc - prev_wc) / 2
            elif prev_wc:
                estimated = prev_wc + timedelta(seconds=90)
            elif next_wc:
                estimated = next_wc - timedelta(seconds=90)
            else:
                continue

            old_wc = p['wallclock']
            p['wallclock'] = estimated.strftime('%Y-%m-%dT%H:%M:%SZ')
            fixes.append({
                'play': f"Q{p['period']} {p['clock']} {p['text'][:50]}",
                'old': old_wc,
                'new': p['wallclock'],
            })

    return fixes


def categorize_plays(all_plays, our_team, off_count, def_count, kicks_count, penalty_mode='auto'):
    """
    Categorize ESPN plays into OFF, DEF, KICKS to match the game film JSON files.

    Returns: (off_plays, def_plays, kick_plays)
    """
    opp_team = None
    for p in all_plays:
        if p['drive_team'] != our_team and p['drive_team'] != '?':
            opp_team = p['drive_team']
            break

    kick_types = {
        'Kickoff', 'Kickoff Return (Offense)', 'Kickoff Return Touchdown',
        'Punt', 'Punt Return', 'Punt Return Touchdown',
        'Field Goal Good', 'Field Goal Missed', 'Blocked Field Goal',
        'Blocked Punt', 'Blocked Punt Touchdown',
    }

    skip_types = {'End Period', 'End of Half', 'End of Game', 'Timeout'}

    off_plays = []
    def_plays = []
    kick_plays = []
    td_for_pats = []

    # Track NO PLAY penalties for flexible inclusion
    noplay_penalties = {'our': [], 'opp': []}

    for p in all_plays:
        ptype = p['type']
        team = p['drive_team']

        if ptype in skip_types:
            continue

        # Declined penalties are always skipped
        if 'declined' in p['text'].lower():
            continue

        # Special teams plays
        if ptype in kick_types:
            kick_plays.append(p)
            if 'Touchdown' in ptype:
                td_for_pats.append(p)
            continue

        # Track TDs for PAT generation
        if 'Touchdown' in ptype:
            td_for_pats.append(p)

        # Penalties need special handling
        if ptype == 'Penalty':
            text = p['text']

            # Punt-related penalties go to KICKS
            if 'punt' in text.lower():
                kick_plays.append(p)
                continue

            # Declined penalties (double-check)
            if 'declined' in text.lower():
                continue

            # NO PLAY penalties (false starts, etc.) - defer based on mode
            if 'NO PLAY' in text:
                side = 'our' if team == our_team else 'opp'
                noplay_penalties[side].append(p)
                continue

            # Other penalties (holding, pass interference, etc.) - categorize normally
            if team == our_team:
                off_plays.append(p)
            else:
                def_plays.append(p)
            continue

        # Regular plays
        if team == our_team:
            off_plays.append(p)
        else:
            def_plays.append(p)

    # Generate PATs for KICKS
    pats = []
    for td in td_for_pats:
        td_wc = td.get('wallclock', '')
        if not td_wc:
            continue
        td_dt = make_utc(td_wc)
        pat_dt = td_dt + timedelta(seconds=40)
        pats.append({
            'type': 'Extra Point',
            'wallclock': pat_dt.strftime('%Y-%m-%dT%H:%M:%SZ'),
            'clock': td['clock'],
            'period': td['period'],
            'text': f"PAT after: {td['text'][:60]}",
            'drive_team': td['drive_team'],
        })

    # Merge kicks + PATs and sort chronologically
    all_kicks = kick_plays + pats
    all_kicks.sort(key=lambda k: make_utc(k['wallclock']) if k.get('wallclock') else datetime.min.replace(tzinfo=timezone.utc))

    # Now handle NO PLAY penalties based on mode and count matching
    if penalty_mode == 'auto':
        # Try to match target counts by selectively including NO PLAY penalties
        off_plays, def_plays, all_kicks = _auto_include_noplay(
            off_plays, def_plays, all_kicks,
            noplay_penalties, our_team,
            off_count, def_count, kicks_count
        )
    elif penalty_mode == 'include-all':
        for p in noplay_penalties['our']:
            off_plays.append(p)
        for p in noplay_penalties['opp']:
            def_plays.append(p)
        # Re-sort after adding
        off_plays.sort(key=lambda k: make_utc(k['wallclock']) if k.get('wallclock') else datetime.min.replace(tzinfo=timezone.utc))
        def_plays.sort(key=lambda k: make_utc(k['wallclock']) if k.get('wallclock') else datetime.min.replace(tzinfo=timezone.utc))
    # exclude-all: do nothing, penalties already excluded

    return off_plays, def_plays, all_kicks


def _auto_include_noplay(off_plays, def_plays, kicks, noplay_penalties, our_team,
                          off_target, def_target, kicks_target):
    """
    Automatically include the right number of NO PLAY penalties to match target counts.
    Includes penalties one at a time (chronologically) until the count matches or we run out.
    """
    # Sort NO PLAY penalties chronologically
    our_noplays = sorted(noplay_penalties['our'],
                         key=lambda p: make_utc(p['wallclock']) if p.get('wallclock') else datetime.min.replace(tzinfo=timezone.utc))
    opp_noplays = sorted(noplay_penalties['opp'],
                         key=lambda p: make_utc(p['wallclock']) if p.get('wallclock') else datetime.min.replace(tzinfo=timezone.utc))

    # Include our NO PLAYs if we need more OFF plays
    off_deficit = off_target - len(off_plays)
    if off_deficit > 0:
        to_add = our_noplays[:off_deficit]
        off_plays.extend(to_add)
        off_plays.sort(key=lambda k: make_utc(k['wallclock']) if k.get('wallclock') else datetime.min.replace(tzinfo=timezone.utc))

    # Include opponent NO PLAYs if we need more DEF plays
    def_deficit = def_target - len(def_plays)
    if def_deficit > 0:
        to_add = opp_noplays[:def_deficit]
        def_plays.extend(to_add)
        def_plays.sort(key=lambda k: make_utc(k['wallclock']) if k.get('wallclock') else datetime.min.replace(tzinfo=timezone.utc))

    return off_plays, def_plays, kicks


def compute_end_times(plays_list, game_end_wc):
    """Compute endTime for each play (= next play's startTime, or game end for last play)."""
    result = []
    for i, p in enumerate(plays_list):
        start_wc = p.get('wallclock', '')
        if i + 1 < len(plays_list):
            end_wc = plays_list[i + 1].get('wallclock', '')
        else:
            end_wc = game_end_wc
        result.append({
            'start_wc': start_wc,
            'end_wc': end_wc,
        })
    return result


def apply_corrections(input_path, output_path, corrected_times, target_tz, label, verbose=False):
    """Apply corrected timestamps to a JSON file and save the result."""
    with open(input_path) as f:
        data = json.load(f)

    new_data = copy.deepcopy(data)
    annotations = [p for p in new_data['timePeriods'] if p['type'] == 'annotation']
    annotations.sort(key=lambda p: p['displayName'])

    n_json = len(annotations)
    n_corrected = len(corrected_times)

    print(f"\n{label}: {n_json} JSON plays, {n_corrected} ESPN timestamps")

    if n_json != n_corrected:
        print(f"  *** COUNT MISMATCH: {n_json} JSON plays vs {n_corrected} ESPN plays ***")
        print(f"  The corrected file will NOT be generated for {label}.")
        print(f"  See debugging guide for resolution steps.")
        return False

    for i in range(n_json):
        ann = annotations[i]
        ct = corrected_times[i]

        old_start = ann['startTime']

        new_start = utc_to_local_str(ct['start_wc'], target_tz)
        new_end = utc_to_local_str(ct['end_wc'], target_tz)

        if new_start:
            ann['startTime'] = new_start
        if new_end:
            ann['endTime'] = new_end

        if verbose or i < 3 or i == n_json - 1:
            print(f"  {ann['displayName']}: {old_start[:19]} -> {ann['startTime'][:19]}")

    # Update the period container
    for p in new_data['timePeriods']:
        if p['type'] == 'period':
            if n_json > 0:
                first_start = utc_to_local_str(corrected_times[0]['start_wc'], target_tz)
                last_end = utc_to_local_str(corrected_times[-1]['end_wc'], target_tz)
                if first_start:
                    p['startTime'] = first_start
                if last_end:
                    p['endTime'] = last_end

    with open(output_path, 'w') as f:
        json.dump(new_data, f, indent='\t')

    print(f"  Saved: {output_path}")
    return True


def verify_results(output_path, kickoff_dt, label):
    """Verify that corrected timestamps are chronological and within game window."""
    with open(output_path) as f:
        data = json.load(f)

    annotations = [p for p in data['timePeriods'] if p['type'] == 'annotation']
    annotations.sort(key=lambda p: p['displayName'])

    issues = []
    prev_dt = None
    game_end = kickoff_dt + timedelta(hours=4, minutes=30)

    for ann in annotations:
        st = ann['startTime']
        # Parse the timestamp (handle 7-digit fractional seconds)
        parts = st.split('.')
        base = parts[0]
        offset = parts[1][-6:]  # e.g., -05:00
        dt = datetime.fromisoformat(base + offset)

        if dt < kickoff_dt - timedelta(minutes=5):
            issues.append(f"{ann['displayName']}: {st[:19]} is before kickoff")
        if dt > game_end:
            issues.append(f"{ann['displayName']}: {st[:19]} is after expected game end")
        if prev_dt and dt < prev_dt:
            issues.append(f"{ann['displayName']}: {st[:19]} is out of chronological order")
        prev_dt = dt

    first = annotations[0]['startTime'][:19] if annotations else 'N/A'
    last = annotations[-1]['startTime'][:19] if annotations else 'N/A'

    print(f"\n  Verification ({label}):")
    print(f"    Range: {first} to {last}")
    print(f"    Plays: {len(annotations)}")

    if issues:
        print(f"    ISSUES FOUND ({len(issues)}):")
        for issue in issues[:5]:
            print(f"      - {issue}")
        if len(issues) > 5:
            print(f"      ... and {len(issues) - 5} more")
        return False
    else:
        print(f"    All timestamps chronological and within game window")
        return True


def check_timestamps_already_correct(filepath, kickoff_dt, tolerance_minutes=30, label=""):
    """
    Check whether the timestamps in a JSON file are already correct (i.e., fall
    within a reasonable window around the expected game time).

    Returns a dict with:
      - 'correct': True if timestamps appear correct, False if they need fixing
      - 'reason': Human-readable explanation
      - 'first_play_offset_min': How many minutes the first play is from kickoff
      - 'avg_offset_min': Average offset of sampled plays from kickoff
      - 'chronological': Whether plays are in chronological order
      - 'within_game_window': Whether all plays fall within kickoff to kickoff+4.5h
    """
    with open(filepath) as f:
        data = json.load(f)

    annotations = [p for p in data['timePeriods'] if p['type'] == 'annotation']
    annotations.sort(key=lambda p: p['displayName'])

    if not annotations:
        return {'correct': False, 'reason': f'{label}: No annotation plays found'}

    def parse_ts(s):
        parts = s.split('.')
        base = parts[0]
        offset = parts[1][-6:] if len(parts) > 1 else '+00:00'
        return datetime.fromisoformat(base + offset)

    game_window_start = kickoff_dt - timedelta(minutes=15)
    game_window_end = kickoff_dt + timedelta(hours=4, minutes=30)

    # Sample plays: first, last, and a few in between
    sample_indices = [0, len(annotations) - 1]
    if len(annotations) > 10:
        sample_indices.extend([len(annotations) // 4, len(annotations) // 2, 3 * len(annotations) // 4])
    sample_indices = sorted(set(i for i in sample_indices if 0 <= i < len(annotations)))

    offsets_from_kickoff = []
    in_window_count = 0
    out_of_window = []

    for idx in sample_indices:
        ts = parse_ts(annotations[idx]['startTime'])
        offset_min = (ts - kickoff_dt).total_seconds() / 60.0
        offsets_from_kickoff.append(offset_min)
        if game_window_start <= ts <= game_window_end:
            in_window_count += 1
        else:
            out_of_window.append((annotations[idx]['displayName'], offset_min))

    # Check chronological order (sample first 20 and last 20)
    check_range = list(range(min(20, len(annotations)))) + list(range(max(0, len(annotations) - 20), len(annotations)))
    check_range = sorted(set(check_range))
    chronological = True
    prev_dt = None
    for idx in check_range:
        ts = parse_ts(annotations[idx]['startTime'])
        if prev_dt is not None and ts < prev_dt:
            chronological = False
            break
        prev_dt = ts

    first_offset = offsets_from_kickoff[0]
    avg_offset = sum(offsets_from_kickoff) / len(offsets_from_kickoff)

    result = {
        'first_play_offset_min': round(first_offset, 1),
        'avg_offset_min': round(avg_offset, 1),
        'chronological': chronological,
        'within_game_window': len(out_of_window) == 0,
        'samples_checked': len(sample_indices),
        'samples_in_window': in_window_count,
    }

    # Decision logic:
    # Timestamps are "correct" if:
    #   1. All sampled plays fall within the game window (kickoff-15min to kickoff+4.5h)
    #   2. First play is within tolerance_minutes of kickoff
    #   3. Plays are in chronological order
    if len(out_of_window) > 0:
        worst = out_of_window[0]
        result['correct'] = False
        result['reason'] = (
            f'{label}: {len(out_of_window)}/{len(sample_indices)} sampled plays fall outside the game window. '
            f'Example: {worst[0]} is {worst[1]:+.0f} min from kickoff.'
        )
    elif abs(first_offset) > tolerance_minutes:
        result['correct'] = False
        result['reason'] = (
            f'{label}: First play is {first_offset:+.0f} min from kickoff '
            f'(tolerance: {tolerance_minutes} min). Timestamps may need correction.'
        )
    elif not chronological:
        result['correct'] = False
        result['reason'] = f'{label}: Plays are not in chronological order.'
    else:
        result['correct'] = True
        result['reason'] = (
            f'{label}: Timestamps look correct. First play is {first_offset:+.1f} min from kickoff, '
            f'all {in_window_count}/{len(sample_indices)} sampled plays within game window, '
            f'chronological order confirmed.'
        )

    return result


def main():
    args = parse_args()

    # Parse kickoff time and extract timezone
    kickoff_dt = datetime.fromisoformat(args.kickoff)
    target_tz = kickoff_dt.tzinfo
    kickoff_utc = kickoff_dt.astimezone(timezone.utc)

    print(f"Game: {args.our_team} | Kickoff: {args.kickoff}")
    print(f"Target timezone offset: {target_tz}")

    # Find game files
    off_file, def_file, kicks_file = find_game_files(args.json_dir, args.our_team)

    files_found = []
    if off_file:
        files_found.append(('OFF', off_file))
    if def_file:
        files_found.append(('DEF', def_file))
    if kicks_file:
        files_found.append(('KICKS', kicks_file))

    if not files_found:
        print(f"\nERROR: No matching JSON files found in {args.json_dir}")
        print(f"Looking for files containing '{args.our_team}' and 'OFF'/'DEF'/'KICKS'")
        sys.exit(1)

    print(f"\nFiles found:")
    for label, path in files_found:
        count = count_annotations(path)
        print(f"  {label}: {os.path.basename(path)} ({count} plays)")

    # Pre-check: are timestamps already correct?
    print(f"\n{'=' * 60}")
    print("PRE-CHECK: Validating existing timestamps")
    print(f"{'=' * 60}")

    all_already_correct = True
    check_results = {}
    for label, path in files_found:
        result = check_timestamps_already_correct(
            path, kickoff_dt, tolerance_minutes=args.tolerance, label=label
        )
        check_results[label] = result
        status = "CORRECT" if result['correct'] else "NEEDS CORRECTION"
        print(f"\n  {label}: {status}")
        print(f"    {result['reason']}")
        if not result['correct']:
            all_already_correct = False

    if all_already_correct:
        print(f"\n{'=' * 60}")
        print("ALL TIMESTAMPS ALREADY CORRECT")
        print(f"{'=' * 60}")
        print("No correction needed. All files have timestamps within the")
        print(f"expected game window (kickoff +/- {args.tolerance} min to kickoff + 4.5 hours).")
        print("Exiting without modifying any files.")
        return 0

    if args.check_only:
        print(f"\n{'=' * 60}")
        print("CHECK-ONLY MODE: Results Summary")
        print(f"{'=' * 60}")
        needs_fix = [l for l, r in check_results.items() if not r['correct']]
        already_ok = [l for l, r in check_results.items() if r['correct']]
        if needs_fix:
            print(f"  Files needing correction: {', '.join(needs_fix)}")
        if already_ok:
            print(f"  Files already correct:    {', '.join(already_ok)}")
        print("\nRe-run without --check-only to apply corrections.")
        return 1 if needs_fix else 0

    # Report which files will be corrected
    needs_correction = [(l, p) for l, p in files_found if not check_results[l]['correct']]
    already_correct = [(l, p) for l, p in files_found if check_results[l]['correct']]
    if already_correct:
        print(f"\n  Skipping already-correct files: {', '.join(l for l, _ in already_correct)}")
    print(f"  Will correct: {', '.join(l for l, _ in needs_correction)}")

    # Get target counts
    off_count = count_annotations(off_file) if off_file else 0
    def_count = count_annotations(def_file) if def_file else 0
    kicks_count = count_annotations(kicks_file) if kicks_file else 0

    # Load ESPN data
    with open(args.espn_data) as f:
        espn_data = json.load(f)

    # Extract all plays
    all_plays = extract_espn_plays(espn_data)
    print(f"\nESPN plays extracted: {len(all_plays)}")

    # Fix wallclock anomalies
    fixes = fix_bad_wallclocks(all_plays, kickoff_utc)
    if fixes:
        print(f"\nFixed {len(fixes)} wallclock anomalies:")
        for fix in fixes:
            print(f"  {fix['play']}: {fix['old']} -> {fix['new']}")

    # Find game end wallclock (last play's wallclock)
    game_end_wc = None
    for p in reversed(all_plays):
        if p.get('wallclock'):
            game_end_wc = p['wallclock']
            break

    if not game_end_wc:
        print("ERROR: Could not determine game end time from ESPN data")
        sys.exit(1)

    # Categorize plays
    off_plays, def_plays, kick_plays = categorize_plays(
        all_plays, args.our_team,
        off_count, def_count, kicks_count,
        args.penalty_mode
    )

    print(f"\nCategorized plays:")
    print(f"  OFF: {len(off_plays)} (target: {off_count})")
    print(f"  DEF: {len(def_plays)} (target: {def_count})")
    print(f"  KICKS: {len(kick_plays)} (target: {kicks_count})")

    # Compute end times
    off_times = compute_end_times(off_plays, game_end_wc) if off_file else []
    def_times = compute_end_times(def_plays, game_end_wc) if def_file else []
    kick_times = compute_end_times(kick_plays, game_end_wc) if kicks_file else []

    # Apply corrections (skip files that are already correct)
    results = {}
    for label, filepath, times in [('OFF', off_file, off_times), ('DEF', def_file, def_times), ('KICKS', kicks_file, kick_times)]:
        if not filepath:
            continue

        # Skip files with already-correct timestamps
        if label in check_results and check_results[label]['correct']:
            print(f"\n{label}: SKIPPED (timestamps already correct)")
            results[label] = {'success': True, 'output': filepath, 'skipped': True}
            continue

        base, ext = os.path.splitext(filepath)
        output_path = f"{base}{args.suffix}{ext}"

        success = apply_corrections(filepath, output_path, times, target_tz, label, args.verbose)
        results[label] = {'success': success, 'output': output_path, 'skipped': False}

    # Verify
    print("\n" + "=" * 60)
    print("VERIFICATION")
    print("=" * 60)

    all_ok = True
    for label, info in results.items():
        if info.get('skipped'):
            print(f"\n  Verification ({label}): SKIPPED (already correct)")
            continue
        if info['success']:
            ok = verify_results(info['output'], kickoff_dt, label)
            if not ok:
                all_ok = False
        else:
            all_ok = False

    # Final summary
    print("\n" + "=" * 60)
    print("RESULTS")
    print("=" * 60)
    for label, info in results.items():
        if info.get('skipped'):
            print(f"  {label}: SKIPPED (already correct)")
        else:
            status = 'OK' if info['success'] else 'FAILED'
            print(f"  {label}: {status}")
            if info['success']:
                print(f"    -> {info['output']}")

    skipped = [l for l, i in results.items() if i.get('skipped')]
    corrected = [l for l, i in results.items() if not i.get('skipped') and i['success']]
    failed = [l for l, i in results.items() if not i.get('skipped') and not i['success']]

    if skipped:
        print(f"\n  Already correct (no changes): {', '.join(skipped)}")
    if corrected:
        print(f"  Successfully corrected: {', '.join(corrected)}")
    if failed:
        print(f"  Failed: {', '.join(failed)}")

    if all_ok:
        print("\nAll files processed successfully.")
        print("Original files have been preserved unchanged.")
    else:
        print("\nSome files had issues. See details above.")

    return 0 if all_ok else 1


if __name__ == '__main__':
    sys.exit(main())
