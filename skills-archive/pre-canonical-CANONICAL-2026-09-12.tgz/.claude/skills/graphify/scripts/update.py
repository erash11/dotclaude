"""--update (incremental re-extraction) helpers.

Actions:
    detect <input_path> - detect new/changed files since the last run (writes .graphify_incremental.json).
                          Exits 0 with 'No files changed' message if nothing changed.
    check-code-only     - print 'code_only: True/False' for the changed files
                          (code extensions come from config.json).
    merge               - merge the new extraction (.graphify_extract.json) into
                          the existing graphify-out/graph.json graph.
    diff                - show the graph diff vs. the pre-update backup (.graphify_old.json).
"""
import argparse
import json
from pathlib import Path

CONFIG = json.loads((Path(__file__).resolve().parent.parent / 'config.json').read_text())


def cmd_detect(input_path):
    from graphify.detect import detect_incremental

    result = detect_incremental(Path(input_path))
    new_total = result.get('new_total', 0)
    print(json.dumps(result, indent=2))
    Path('.graphify_incremental.json').write_text(json.dumps(result))
    if new_total == 0:
        print('No files changed since last run. Nothing to update.')
        raise SystemExit(0)
    print(f'{new_total} new/changed file(s) to re-extract.')


def cmd_check_code_only():
    result = json.loads(open('.graphify_incremental.json').read()) if Path('.graphify_incremental.json').exists() else {}
    code_exts = set(CONFIG['code_extensions'])
    new_files = result.get('new_files', {})
    all_changed = [f for files in new_files.values() for f in files]
    code_only = all(Path(f).suffix.lower() in code_exts for f in all_changed)
    print('code_only:', code_only)


def cmd_merge():
    from graphify.build import build_from_json
    from networkx.readwrite import json_graph

    # Load existing graph
    existing_data = json.loads(Path('graphify-out/graph.json').read_text())
    G_existing = json_graph.node_link_graph(existing_data, edges='links')

    # Load new extraction
    new_extraction = json.loads(Path('.graphify_extract.json').read_text())
    G_new = build_from_json(new_extraction)

    # Merge: new nodes/edges into existing graph
    G_existing.update(G_new)
    print(f'Merged: {G_existing.number_of_nodes()} nodes, {G_existing.number_of_edges()} edges')


def cmd_diff():
    from graphify.analyze import graph_diff
    from graphify.build import build_from_json
    from networkx.readwrite import json_graph

    # Load old graph (before update) from backup written before merge
    old_data = json.loads(Path('.graphify_old.json').read_text()) if Path('.graphify_old.json').exists() else None
    new_extract = json.loads(Path('.graphify_extract.json').read_text())
    G_new = build_from_json(new_extract)

    if old_data:
        G_old = json_graph.node_link_graph(old_data, edges='links')
        diff = graph_diff(G_old, G_new)
        print(diff['summary'])
        if diff['new_nodes']:
            print('New nodes:', ', '.join(n['label'] for n in diff['new_nodes'][:5]))
        if diff['new_edges']:
            print('New edges:', len(diff['new_edges']))


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('action', choices=['detect', 'check-code-only', 'merge', 'diff'])
    p.add_argument('input_path', nargs='?', help='Required for the detect action')
    args = p.parse_args()

    if args.action == 'detect':
        if not args.input_path:
            p.error('detect requires an input_path')
        cmd_detect(args.input_path)
    elif args.action == 'check-code-only':
        cmd_check_code_only()
    elif args.action == 'merge':
        cmd_merge()
    elif args.action == 'diff':
        cmd_diff()


if __name__ == '__main__':
    main()
