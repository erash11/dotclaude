"""--cluster-only - Re-run clustering on the existing graphify-out/graph.json.

Skips extraction entirely. Writes GRAPH_REPORT.md, graph.json, .graphify_analysis.json.
"""
import json
from pathlib import Path

from graphify.cluster import cluster, score_all
from graphify.analyze import god_nodes, surprising_connections
from graphify.report import generate
from graphify.export import to_json
from networkx.readwrite import json_graph


def main():
    data = json.loads(Path('graphify-out/graph.json').read_text())
    G = json_graph.node_link_graph(data, edges='links')

    detection = {'total_files': 0, 'total_words': 99999, 'needs_graph': True, 'warning': None,
                 'files': {'code': [], 'document': [], 'paper': []}}
    tokens = {'input': 0, 'output': 0}

    communities = cluster(G)
    cohesion = score_all(G, communities)
    gods = god_nodes(G)
    surprises = surprising_connections(G, communities)
    labels = {cid: 'Community ' + str(cid) for cid in communities}

    report = generate(G, communities, cohesion, labels, gods, surprises, detection, tokens, '.')
    Path('graphify-out/GRAPH_REPORT.md').write_text(report)
    to_json(G, communities, 'graphify-out/graph.json')

    analysis = {
        'communities': {str(k): v for k, v in communities.items()},
        'cohesion': {str(k): v for k, v in cohesion.items()},
        'gods': gods,
        'surprises': surprises,
    }
    Path('.graphify_analysis.json').write_text(json.dumps(analysis, indent=2))
    print(f'Re-clustered: {len(communities)} communities')


if __name__ == '__main__':
    main()
