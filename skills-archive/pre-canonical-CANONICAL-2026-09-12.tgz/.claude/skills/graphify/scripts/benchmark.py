"""Step 8 - Token reduction benchmark (run only if total_words > benchmark_min_words in config.json)."""
import json
from pathlib import Path

from graphify.benchmark import run_benchmark, print_benchmark


def main():
    detection = json.loads(Path('.graphify_detect.json').read_text())
    result = run_benchmark('graphify-out/graph.json', corpus_words=detection['total_words'])
    print_benchmark(result)


if __name__ == '__main__':
    main()
