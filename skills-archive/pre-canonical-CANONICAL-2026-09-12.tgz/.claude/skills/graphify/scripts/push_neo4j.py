"""Step 7 (--neo4j-push) - Push the graph directly to a running Neo4j instance.

Uses MERGE - safe to re-run without creating duplicates.
"""
import argparse
import json
from pathlib import Path

from graphify.build import build_from_json
from graphify.cluster import cluster
from graphify.export import push_to_neo4j


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--uri', default='bolt://localhost:7687')
    p.add_argument('--user', default='neo4j')
    p.add_argument('--password', required=True)
    args = p.parse_args()

    extraction = json.loads(Path('.graphify_extract.json').read_text())
    analysis = json.loads(Path('.graphify_analysis.json').read_text())
    G = build_from_json(extraction)
    communities = {int(k): v for k, v in analysis['communities'].items()}

    result = push_to_neo4j(G, uri=args.uri, user=args.user, password=args.password, communities=communities)
    print(f'Pushed to Neo4j: {result["nodes"]} nodes, {result["edges"]} edges')


if __name__ == '__main__':
    main()
