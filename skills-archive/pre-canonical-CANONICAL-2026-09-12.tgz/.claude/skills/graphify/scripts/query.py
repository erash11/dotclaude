"""/graphify query - Token-budgeted BFS/DFS traversal of the graph for a question.

BFS (default): broad context, nearest neighbors first ("What is X connected to?").
DFS (--mode dfs): trace a specific chain or dependency path ("How does X reach Y?").

Defaults (budget, traversal depths) come from config.json.
"""
import argparse
import json
import sys
from pathlib import Path

CONFIG = json.loads((Path(__file__).resolve().parent.parent / 'config.json').read_text())


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('question')
    p.add_argument('--mode', choices=['bfs', 'dfs'], default='bfs')
    p.add_argument('--budget', type=int, default=CONFIG['query_budget_default'], help='Token budget for output (default from config.json)')
    args = p.parse_args()

    if not Path('graphify-out/graph.json').exists():
        print('ERROR: No graph found. Run /graphify <path> first to build the graph.')
        raise SystemExit(1)

    from networkx.readwrite import json_graph
    import networkx as nx  # noqa: F401

    data = json.loads(Path('graphify-out/graph.json').read_text())
    G = json_graph.node_link_graph(data, edges='links')

    question = args.question
    mode = args.mode
    terms = [t.lower() for t in question.split() if len(t) > 3]

    # Find best-matching start nodes
    scored = []
    for nid, ndata in G.nodes(data=True):
        label = ndata.get('label', '').lower()
        score = sum(1 for t in terms if t in label)
        if score > 0:
            scored.append((score, nid))
    scored.sort(reverse=True)
    start_nodes = [nid for _, nid in scored[:3]]

    if not start_nodes:
        print('No matching nodes found for query terms:', terms)
        sys.exit(0)

    subgraph_nodes = set()
    subgraph_edges = []

    if mode == 'dfs':
        # DFS: follow one path as deep as possible before backtracking.
        # Depth-limited (config: dfs_max_depth) to avoid traversing the whole graph.
        max_depth = CONFIG['dfs_max_depth']
        visited = set()
        stack = [(n, 0) for n in reversed(start_nodes)]
        while stack:
            node, depth = stack.pop()
            if node in visited or depth > max_depth:
                continue
            visited.add(node)
            subgraph_nodes.add(node)
            for neighbor in G.neighbors(node):
                if neighbor not in visited:
                    stack.append((neighbor, depth + 1))
                    subgraph_edges.append((node, neighbor))
    else:
        # BFS: explore all neighbors layer by layer (config: bfs_max_depth).
        frontier = set(start_nodes)
        subgraph_nodes = set(start_nodes)
        for _ in range(CONFIG['bfs_max_depth']):
            next_frontier = set()
            for n in frontier:
                for neighbor in G.neighbors(n):
                    if neighbor not in subgraph_nodes:
                        next_frontier.add(neighbor)
                        subgraph_edges.append((n, neighbor))
            subgraph_nodes.update(next_frontier)
            frontier = next_frontier

    # Token-budget aware output: rank by relevance, cut at budget (~4 chars/token)
    token_budget = args.budget
    char_budget = token_budget * 4

    # Score each node by term overlap for ranked output
    def relevance(nid):
        label = G.nodes[nid].get('label', '').lower()
        return sum(1 for t in terms if t in label)

    ranked_nodes = sorted(subgraph_nodes, key=relevance, reverse=True)

    lines = [f'Traversal: {mode.upper()} | Start: {[G.nodes[n].get("label", n) for n in start_nodes]} | {len(subgraph_nodes)} nodes']
    for nid in ranked_nodes:
        d = G.nodes[nid]
        lines.append(f'  NODE {d.get("label", nid)} [src={d.get("source_file", "")} loc={d.get("source_location", "")}]')
    for u, v in subgraph_edges:
        if u in subgraph_nodes and v in subgraph_nodes:
            d = G.edges[u, v]
            lines.append(f'  EDGE {G.nodes[u].get("label", u)} --{d.get("relation", "")} [{d.get("confidence", "")}]--> {G.nodes[v].get("label", v)}')

    output = '\n'.join(lines)
    if len(output) > char_budget:
        output = output[:char_budget] + f'\n... (truncated at ~{token_budget} token budget - use --budget N for more)'
    print(output)


if __name__ == '__main__':
    main()
