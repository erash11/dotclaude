"""Step 3 Part B cache operations.

check (Step B0): find which files already have cached extraction results.
    Reads .graphify_detect.json; writes .graphify_cached.json (if any hits)
    and .graphify_uncached.txt.
save (Step B3): save new subagent results to the extraction cache.
    Reads .graphify_semantic_new.json.
"""
import argparse
import json
from pathlib import Path


def cmd_check():
    from graphify.cache import check_semantic_cache

    detect = json.loads(Path('.graphify_detect.json').read_text())
    all_files = [f for files in detect['files'].values() for f in files]

    cached_nodes, cached_edges, cached_hyperedges, uncached = check_semantic_cache(all_files)

    if cached_nodes or cached_edges or cached_hyperedges:
        Path('.graphify_cached.json').write_text(json.dumps({'nodes': cached_nodes, 'edges': cached_edges, 'hyperedges': cached_hyperedges}))
    Path('.graphify_uncached.txt').write_text('\n'.join(uncached))
    print(f'Cache: {len(all_files) - len(uncached)} files hit, {len(uncached)} files need extraction')


def cmd_save():
    from graphify.cache import save_semantic_cache

    new = json.loads(Path('.graphify_semantic_new.json').read_text()) if Path('.graphify_semantic_new.json').exists() else {'nodes': [], 'edges': [], 'hyperedges': []}
    saved = save_semantic_cache(new.get('nodes', []), new.get('edges', []), new.get('hyperedges', []))
    print(f'Cached {saved} files')


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('action', choices=['check', 'save'])
    args = p.parse_args()
    if args.action == 'check':
        cmd_check()
    else:
        cmd_save()


if __name__ == '__main__':
    main()
