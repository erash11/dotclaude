"""Step 4 - Build graph, cluster, analyze, generate report + JSON outputs.

Reads .graphify_extract.json and .graphify_detect.json.
Writes graphify-out/GRAPH_REPORT.md, graphify-out/graph.json, .graphify_analysis.json.
Exits 1 with 'ERROR: Graph is empty' if extraction produced no nodes.
"""
import argparse
import json
from pathlib import Path

from graphify.build import build_from_json
from graphify.cluster import cluster, score_all
from graphify.analyze import god_nodes, surprising_connections, suggest_questions
from graphify.report import generate
from graphify.export import to_json


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('input_path', help='Path that was processed (recorded in the report)')
    args = p.parse_args()

    extraction = json.loads(Path('.graphify_extract.json').read_text())
    detection = json.loads(Path('.graphify_detect.json').read_text())

    G = build_from_json(extraction)
    communities = cluster(G)
    cohesion = score_all(G, communities)
    tokens = {'input': extraction.get('input_tokens', 0), 'output': extraction.get('output_tokens', 0)}
    gods = god_nodes(G)
    surprises = surprising_connections(G, communities)
    labels = {cid: 'Community ' + str(cid) for cid in communities}
    # Placeholder questions - regenerated with real labels in Step 5
    questions = suggest_questions(G, communities, labels)

    report = generate(G, communities, cohesion, labels, gods, surprises, detection, tokens, args.input_path, suggested_questions=questions)
    Path('graphify-out/GRAPH_REPORT.md').write_text(report)
    to_json(G, communities, 'graphify-out/graph.json')

    analysis = {
        'communities': {str(k): v for k, v in communities.items()},
        'cohesion': {str(k): v for k, v in cohesion.items()},
        'gods': gods,
        'surprises': surprises,
        'questions': questions,
    }
    Path('.graphify_analysis.json').write_text(json.dumps(analysis, indent=2))
    if G.number_of_nodes() == 0:
        print('ERROR: Graph is empty - extraction produced no nodes.')
        print('Possible causes: all files were skipped, binary-only corpus, or extraction failed.')
        raise SystemExit(1)
    print(f'Graph: {G.number_of_nodes()} nodes, {G.number_of_edges()} edges, {len(communities)} communities')


if __name__ == '__main__':
    main()
