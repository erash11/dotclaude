"""Steps 6, 7, 7b, 7c - Export the graph in a chosen format.

Formats:
    obsidian - Obsidian vault + graph.canvas (Step 6, only if --obsidian was given)
    html     - interactive graph.html (Step 6, always unless --no-viz)
    svg      - graph.svg (only if --svg flag)
    graphml  - graph.graphml (only if --graphml flag)
    cypher   - graphify-out/cypher.txt for Neo4j (only if --neo4j flag)

Reads .graphify_extract.json, .graphify_analysis.json, .graphify_labels.json (optional).
The HTML node cap comes from config.json (html_node_cap).
"""
import argparse
import json
from pathlib import Path

from graphify.build import build_from_json

CONFIG = json.loads((Path(__file__).resolve().parent.parent / 'config.json').read_text())


def load_state(need_analysis=True, need_labels=True):
    extraction = json.loads(Path('.graphify_extract.json').read_text())
    G = build_from_json(extraction)
    communities = {}
    labels = {}
    cohesion = {}
    if need_analysis:
        analysis = json.loads(Path('.graphify_analysis.json').read_text())
        communities = {int(k): v for k, v in analysis['communities'].items()}
        cohesion = {int(k): v for k, v in analysis['cohesion'].items()}
    if need_labels:
        labels_raw = json.loads(Path('.graphify_labels.json').read_text()) if Path('.graphify_labels.json').exists() else {}
        labels = {int(k): v for k, v in labels_raw.items()}
    return G, communities, labels, cohesion


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--format', required=True, choices=['obsidian', 'html', 'svg', 'graphml', 'cypher'])
    p.add_argument('--obsidian-dir', default='graphify-out/obsidian', help='Vault directory (--obsidian-dir value, defaults to graphify-out/obsidian)')
    args = p.parse_args()

    if args.format == 'obsidian':
        from graphify.export import to_obsidian, to_canvas

        G, communities, labels, cohesion = load_state()
        obsidian_dir = args.obsidian_dir

        n = to_obsidian(G, communities, obsidian_dir, community_labels=labels or None, cohesion=cohesion)
        print(f'Obsidian vault: {n} notes in {obsidian_dir}/')

        to_canvas(G, communities, f'{obsidian_dir}/graph.canvas', community_labels=labels or None)
        print(f'Canvas: {obsidian_dir}/graph.canvas - open in Obsidian for structured community layout')
        print()
        print(f'Open {obsidian_dir}/ as a vault in Obsidian.')
        print('  Graph view   - nodes colored by community (set automatically)')
        print('  graph.canvas - structured layout with communities as groups')
        print('  _COMMUNITY_* - overview notes with cohesion scores and dataview queries')

    elif args.format == 'html':
        from graphify.export import to_html

        G, communities, labels, _ = load_state()
        node_cap = CONFIG['html_node_cap']
        if G.number_of_nodes() > node_cap:
            print(f'Graph has {G.number_of_nodes()} nodes - too large for HTML viz. Use Obsidian vault instead.')
        else:
            to_html(G, communities, 'graphify-out/graph.html', community_labels=labels or None)
            print('graph.html written - open in any browser, no server needed')

    elif args.format == 'svg':
        from graphify.export import to_svg

        G, communities, labels, _ = load_state()
        to_svg(G, communities, 'graphify-out/graph.svg', community_labels=labels or None)
        print('graph.svg written - embeds in Obsidian, Notion, GitHub READMEs')

    elif args.format == 'graphml':
        from graphify.export import to_graphml

        G, communities, _, _ = load_state(need_labels=False)
        to_graphml(G, communities, 'graphify-out/graph.graphml')
        print('graph.graphml written - open in Gephi, yEd, or any GraphML tool')

    elif args.format == 'cypher':
        from graphify.export import to_cypher

        G, _, _, _ = load_state(need_analysis=False, need_labels=False)
        to_cypher(G, 'graphify-out/cypher.txt')
        print('cypher.txt written - import with: cypher-shell < graphify-out/cypher.txt')


if __name__ == '__main__':
    main()
