"""Step 2 - Detect files in the input path.

Writes .graphify_detect.json to the current working directory.
"""
import argparse
import json
from pathlib import Path

from graphify.detect import detect


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('input_path', help='Path to the corpus to analyze')
    args = p.parse_args()
    result = detect(Path(args.input_path))
    Path('.graphify_detect.json').write_text(json.dumps(result))


if __name__ == '__main__':
    main()
