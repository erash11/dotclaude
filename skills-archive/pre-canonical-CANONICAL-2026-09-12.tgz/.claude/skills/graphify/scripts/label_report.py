"""Step 5 - Regenerate the report with human-written community labels.

Pass labels as a JSON object mapping community id to label, e.g.:
    python label_report.py <input_path> --labels "{\"0\": \"Attention Mechanism\", \"1\": \"Training Pipeline\"}"

Writes graphify-out/GRAPH_REPORT.md and .graphify_labels.json (for the visualizer).
"""
import argparse
import json
from pathlib import Path

from graphify.build import build_from_json
from graphify.cluster import score_all
from graphify.analyze import god_nodes, surprising_connections, suggest_questions
from graphify.report import generate


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('input_path', help='Path that was processed (recorded in the report)')
    p.add_argument('--labels', required=True, help='JSON dict of community id -> 2-5 word label')
    args = p.parse_args()

    extraction = json.loads(Path('.graphify_extract.json').read_text())
    detection = json.loads(Path('.graphify_detect.json').read_text())
    analysis = json.loads(Path('.graphify_analysis.json').read_text())

    G = build_from_json(extraction)
    communities = {int(k): v for k, v in analysis['communities'].items()}
    cohesion = {int(k): v for k, v in analysis['cohesion'].items()}
    tokens = {'input': extraction.get('input_tokens', 0), 'output': extraction.get('output_tokens', 0)}

    labels = {int(k): v for k, v in json.loads(args.labels).items()}

    # Regenerate questions with real community labels (labels affect question phrasing)
    questions = suggest_questions(G, communities, labels)

    report = generate(G, communities, cohesion, labels, analysis['gods'], analysis['surprises'], detection, tokens, args.input_path, suggested_questions=questions)
    Path('graphify-out/GRAPH_REPORT.md').write_text(report)
    Path('.graphify_labels.json').write_text(json.dumps({str(k): v for k, v in labels.items()}))
    print('Report updated with community labels')


if __name__ == '__main__':
    main()
