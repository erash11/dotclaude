"""/graphify add - Fetch a URL and save it into ./raw for the next graph update."""
import argparse
import sys
from pathlib import Path

from graphify.ingest import ingest


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('url')
    p.add_argument('--author', default=None, help='Who wrote it')
    p.add_argument('--contributor', default=None, help='Who added it to the corpus')
    args = p.parse_args()

    try:
        out = ingest(args.url, Path('./raw'), author=args.author, contributor=args.contributor)
        print(f'Saved to {out}')
    except ValueError as e:
        print(f'error: {e}', file=sys.stderr)
        sys.exit(1)
    except RuntimeError as e:
        print(f'error: {e}', file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()
