"""/graphify explain - Dump a node and everything connected to it."""
import argparse
import json
import sys
from pathlib import Path


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('node_name', help='Concept the user asked about')
    args = p.parse_args()

    if not Path('graphify-out/graph.json').exists():
        print('ERROR: No graph found. Run /graphify <path> first to build the graph.')
        raise SystemExit(1)

    import networkx as nx  # noqa: F401
    from networkx.readwrite import json_graph

    data = json.loads(Path('graphify-out/graph.json').read_text())
    G = json_graph.node_link_graph(data, edges='links')

    term = args.node_name
    term_lower = term.lower()

    # Find best matching node
    scored = sorted(
        [(sum(1 for w in term_lower.split() if w in G.nodes[n].get('label', '').lower()), n)
         for n in G.nodes()],
        reverse=True
    )
    if not scored or scored[0][0] == 0:
        print(f'No node matching {term!r}')
        sys.exit(0)

    nid = scored[0][1]
    data_n = G.nodes[nid]
    print(f'NODE: {data_n.get("label", nid)}')
    print(f'  source: {data_n.get("source_file", "unknown")}')
    print(f'  type: {data_n.get("file_type", "unknown")}')
    print(f'  degree: {G.degree(nid)}')
    print()
    print('CONNECTIONS:')
    for neighbor in G.neighbors(nid):
        edge = G.edges[nid, neighbor]
        nlabel = G.nodes[neighbor].get('label', neighbor)
        rel = edge.get('relation', '')
        conf = edge.get('confidence', '')
        src_file = G.nodes[neighbor].get('source_file', '')
        print(f'  --{rel}--> {nlabel} [{conf}] ({src_file})')


if __name__ == '__main__':
    main()
