---
name: forecast-capture
description: Capture and freeze the CFB Victory Model's pre-game forecasts before kickoff, then report what moved since last week. Run every Wednesday during the season. Use when the user says "/forecast-capture", "capture the forecast", "freeze this week's predictions", "run the CFB capture", "did we capture this week", or asks whether the weekly model snapshot has been taken.
---

# Forecast Capture

Freezes cfbvictorymodel.com's forecasts for the coming weekend, then reports
what changed. Takes no arguments and asks nothing — all 16 Big 12 teams and
2026 are the defaults and rarely change.

## Why this exists

The report's "Chance of Victory" column is **overwritten with the realised
result** once a game is played. Across 2019–2025 that destroyed every pre-game
probability the model ever produced. Miss a week and that week's forecast is
gone permanently — it cannot be recovered later. This makes 2026 the first
gradable season.

## Run it

One command does everything — capture all 16 Big 12 teams, compare, and copy
both into the archive:

```bash
/Users/kristinarash/DEV/CFB_Victory_Model/scripts/weekly_run.sh
```

That wrapper is the only route to run. It hardcodes the absolute `uv` path
(`/Users/kristinarash/.local/bin/uv`) so it works from any shell, and it calls:

```bash
uv run --with playwright python weekly_capture.py            # default = all Big 12
uv run python compare_snapshots.py --all --archive
```

Pass through to narrow it — `scripts/weekly_run.sh --team Baylor` for one team,
`--year 2027` for another season.

Snapshots are written to `data/weekly_snapshots/` (canonical) and copied to
`~/DEV/CFB_Forecast_Archive/<season>/` together with each team's comparison
text. The archive is a read-only mirror; never treat it as the source.

Then read the comparison output back to the user in plain language (see below).

**Budget ~10 minutes.** Sixteen teams share one report session. This is a
hobby server run by one person — do not run it more often than weekly, and do
not add teams beyond the conference without a reason.

**Must run headed.** A Chrome window will open — that is expected, not a bug.
In headless mode Power BI's virtualised slicer list never renders past the
first ~8 alphabetical teams and most teams are unreachable. Do not add
`--headless`.

`Team attempt 1 failed, retrying...` in the output is **normal** — the first
slicer interaction races the app's own start-up. It retries 3×, and any team
still failing gets one whole extra pass at the end. Only treat it as a failure
if a team appears in the final `FAILED for:` line.

## What to report back

Lead with how many of the 16 teams captured, then give the rollup table
`compare_snapshots.py --all` prints (team, expected wins, change, played,
moved). Then:

1. **Games played since last capture** — the forecast is now gradable for
   those. Report side correct/wrong and margin miss. This is the accumulating
   track record; it is the whole point.
2. **Forecasts that moved** — which games and by how much. A big win-probability
   swing usually means the model re-rated an opponent after their weekend.
3. **Season outlook drift** — expected wins now vs last week.
4. **Anything anomalous** — a new game appearing, a game vanishing, fewer than
   12 rows, or a wild swing worth a second look.

Keep it short. If nothing moved, say so in one line.

## Timing

Run **Wednesday** of a game week. Wednesday sits after the model has ingested
the previous weekend and safely before Thursday-night kickoffs. Monday risks
catching the model mid-update; Friday risks missing a Thursday game.

If the comparison output warns the newest capture is several days old, tell the
user which week was missed — that forecast is unrecoverable and the gap should
be recorded rather than quietly ignored.

## Which teams

The default is the whole Big 12 — all 16, every week. The list lives in one
place, `BIG12` in `weekly_capture.py`. Edit that constant if the conference
changes; do not scatter team lists into the wrapper or this file.

Outside the Big 12, only if asked. Each extra team is another slow slicer set
against one person's hobby server:

```bash
scripts/weekly_run.sh --teams Baylor TCU "Texas Tech"
```

Team names must match the report's Team slicer exactly — "Iowa State", not
"Iowa St."; "UCF", not "Central Florida". A wrong name fails loudly with
`never appeared (saw [...])` and that message lists what the slicer really
offers, so read it rather than guessing again.

## Gotchas

- **`playwright` is not installed on any Python on this machine.** `weekly_capture.py`
  imports it, so the bare `python3 weekly_capture.py` form this skill documented until
  2026-09-02 dies with `ModuleNotFoundError` before opening a browser. `uv run --with
  playwright` fetches it per-run (~12ms, cached). Never remove `--with playwright` from
  the run block. `compare_snapshots.py` is stdlib-only and does not need it.
- **The browser cache is separate from the Python package and is already correct.**
  `~/Library/Caches/ms-playwright/chromium-1234` holds Chrome for Testing 151.0.7922.34,
  the exact build playwright v1234 wants, marked `INSTALLATION_COMPLETE`. A
  `ModuleNotFoundError` is never a reason to re-download browsers. If the binary ever does
  go missing: `uv run --with playwright python -m playwright install chromium`.
- **Check what already exists before capturing.** `ls data/weekly_snapshots/` first. On
  2026-09-02 the newest file was `2026-07-31_baylor.csv` — pre-season. Report a gap like
  that explicitly instead of just capturing today and reporting success. **But check the
  schedule before calling it a loss.** An old newest-file does not prove a missed week: on
  2026-09-02 Baylor's opener was still 5 days away (2026-09-05), so no forecast had been
  overwritten. A week is only lost if a game was actually played inside the gap. Confirm
  with the ESPN schedule API (Baylor team id 239):
  `curl -s "https://site.api.espn.com/apis/site/v2/sports/football/college-football/teams/239/schedule?season=2026"`
  and check each event's `status.type.name`.
- **This skill cannot run unattended.** The headed-Chrome requirement means
  `skill-button.sh forecast-capture` still opens a window and needs a logged-in session.
  It is not safe to wire to launchd as a silent job.

## Files

| Path | What |
|---|---|
| `scripts/weekly_run.sh` | The one command — capture, compare, archive |
| `weekly_capture.py` | Drives the report, writes the snapshot. Holds `BIG12` |
| `compare_snapshots.py` | Diffs the two most recent captures (`--all`, `--archive`) |
| `data/weekly_snapshots/<date>_<team>.csv` | One file per run — canonical |
| `data/weekly_forecast_log.csv` | Append-only, every capture |
| `frozen_predictions_2026.csv` | Hand-transcribed pre-season baseline |
| `~/DEV/CFB_Forecast_Archive/<season>/` | Read-only copies: snapshot + compare text |

Captures are idempotent per team per day — re-running after a failure is safe.
