---
name: weekly-review
description: Friday close-of-week synthesis ritual. Pulls the last 7 days of meetings, interview notes, and permanent notes from the SecondBrain vault and produces a single weekly review note covering themes, project status, decisions, stale action items, essay angles, and next-week priorities. Use when user says "/weekly-review", "weekly review", "Friday review", "let's do this week's review", "weekly synthesis", or "what should I work on next week?".
---

# Weekly Review

End-of-week synthesis. This is the user's **project prioritization surface** — the artifact that names what's progressing, what's drifting, and what earns priority next week.

## Vault location

`/Users/kristinarash/SecondBrain/`

**Paths:** canonical vault locations live in `/Users/kristinarash/.claude/skills/_shared/config.json` — load it if unsure; if a literal path here ever disagrees, the config wins.

- Inputs: `Inbox/meetings/*.md` (last 7d), `Inbox/*-interview.md` (last 7d), `Notes/*.md` (modified last 7d)
- Output: `Inbox/weekly-review/YYYY-MM-DD-review.md`
- Template: `Templates/weekly-review.md`

## Step 1 — Refresh meeting summaries

Invoke the `meeting-sync` skill first. If it reports auth failure, stop and surface the same auth message to the user. The review can't run without current meeting data.

Then run the filename drift audit — this is its weekly home, since it's too slow for every sync:

```bash
python ~/.claude/skills/meeting-sync/scripts/audit_filenames.py --since <90 days ago>
```

Report only the `regression_count` and `semantic_count` in the review note, as a one-line health check (e.g. *"Meeting filenames: 4 regressions, 39 semantic diffs — see meeting-sync drift audit"*). Do **not** rename anything as part of the review; regressions get fixed upstream in Fireflies and semantic diffs need a human call. See the Drift audit section of `meeting-sync` for what each class means.

## Step 2 — Gather inputs

Use Glob + filesystem mtime to collect:
1. `Inbox/meetings/*.md` created in the last 7 days
2. `Inbox/*-interview.md` from the last 7 days
3. `Notes/*.md` modified in the last 7 days

Also pull this week's aggregate view from Fireflies for cross-meeting signal:
```bash
fireflies-pp-cli digest --since 7d --processed-only --json --agent
fireflies-pp-cli action-items list --from 30 --json --agent
fireflies-pp-cli topics list --from 7 --json --agent
```

(`action-items list --from 30` gives you stale-item detection — anything older than 14 days that's still open is "stale".)

## Step 3 — Read and synthesize

Read each input file. As you go, build up:
- **Theme map:** what topics/concepts appear in 2+ sources?
- **Project map:** which named projects/clients show up? For each: did they progress (decision made, work shipped), drift (mentioned but no movement), or stick (blocked, awaiting input)?
- **Decision log:** any decision sentences across all sources
- **Stale action items:** anything > 14d old still open
- **Essay clusters:** linked Notes that form a 2–4 note thread on a single idea
- **Threads worth carrying forward**
- **Unlabeled-speaker meetings:** while reading `Inbox/meetings/*.md`, grep for `Speaker 1`, `Speaker 2`, `Speaker 3` (etc.) patterns. Track which meeting files still have unnamed speakers. The user labels speakers manually in the Fireflies web UI — no API for it — so the review's job is just to flag them.

**Curation rule:** if you can't name a theme/project/decision in one sentence with a source citation, drop it. The review is for the user's working memory, not for completeness.

## Step 4 — Write the review note

File: `Inbox/weekly-review/YYYY-MM-DD-review.md` (use today's date — Friday or whenever invoked).

Start from `Templates/weekly-review.md` and fill it in. Sections:

1. **Themes recurring this week** — bulleted, each with source citation `[[file]]` or `(meeting: X, date)`.
2. **Active projects — status snapshot** — markdown table with columns: Project | Status (progressing / drifting / stuck / decided / new) | Last touched | Note. Be ruthless about marking "drifting" — that's the value of this whole exercise.
3. **Decisions made this week** — bulleted, quote the decision in the user's words if available, with source citation.
4. **Open action items (stale > 14d flagged)** — from `action-items list`. Each line: owner — task — age — source meeting. Flag stale items with `⚠`.
5. **Essay angles emerging** — each angle: working title, 1-sentence thesis, list of 2–4 `[[Note]]` links that support it. These are candidates for moving into `Drafts/`.
6. **Next week — priorities and why** — three items, ranked. One sentence per item on why this beats the alternatives. **This is the most important section.** Push back on the user if their answer here is generic ("keep working on X").
7. **Open threads to revisit** — anything noticed but not actioned.
8. **Pipeline hygiene** (only include if there's something to flag):
   - Unlabeled speakers in this week's meetings — list the affected meeting files with a single-line action: *"Open in Fireflies UI and assign names to Speaker N entries."*
   - Generic-titled meetings still in the local DB — suggest running `/name-meetings` if any appeared this week.
   - Skip this section entirely if both are clean.

Update frontmatter counts: `meetings_reviewed`, `interviews_reviewed`, `notes_touched`.

## Step 5 — Sign off

Brief summary to user (3–5 lines):
- File written: path
- Headline number: N meetings, M interviews, K notes synthesized
- The three priorities you proposed for next week
- One open question worth them thinking about before next Monday

## Step 6 — Offer (don't take) the next move

After delivering the review, offer:
> "Want me to start a `Drafts/<essay-slug>.md` from one of the essay angles? Or carry any of the stale action items into a tomorrow-morning agenda?"

Do not auto-create drafts. The user picks.

## What NOT to do

- **Don't generate a review without meeting-sync running first.** Stale data = wrong priorities.
- **Don't pad sections to fill the template.** A short, honest review beats a long, padded one. If "decisions made" is empty, write "None this week." and move on.
- **Don't include items you can't cite.** Every claim → source.
- **Don't write to `Drafts/` automatically.** Drafts are a deliberate user choice.
- **Don't run weekly-review more than once per week** unless the user explicitly asks (e.g., "redo the review with X added"). Repeated runs erode the ritual.
