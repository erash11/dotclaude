---
name: html-to-pdf
description: Render any local HTML report, deck, or dashboard to a print-ready PDF via headless Chrome — replaces the manual Ctrl+P → Save as PDF ritual. Use when the user says "export this to PDF", "print version", "PDF for the coaches", "make this printable", or a coach-facing HTML deliverable needs a shareable/printable copy.
argument-hint: "[html-path] [out-pdf]"
---

# HTML to PDF

Headless-Chrome render of a local HTML file to PDF. No manual browser printing.

## Quick start

```powershell
pwsh -NoProfile -File "$HOME\.claude\skills\html-to-pdf\scripts\html2pdf.ps1" -HtmlPath "report.html"
# optional explicit output:
#   ... -HtmlPath "report.html" -OutPdf "C:\path\coach-report.pdf"
```

Defaults: same folder, same name, `.pdf` extension. Report the output path and size to the user when done.

## Page setup lives in the HTML, not in flags

Headless Chrome takes page size/orientation from CSS `@page`. If the source lacks one, inject a style block before rendering (edit the file or a temp copy):

```html
<style>
  @page { size: Letter portrait; margin: 12mm; }        /* or: Letter landscape */
  body { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
</style>
```

- `print-color-adjust: exact` keeps background colors/graphics — the equivalent of ticking "Background graphics" in the print dialog. Coach-facing reports almost always need it.
- Landscape decks: `size: Letter landscape`. Slide decks sized in `vh/vw` may need a fixed pixel size instead, e.g. `@page { size: 1280px 720px; margin: 0; }`.

## Edge cases

- **Animated/reveal-on-scroll pages** (frontend-slides output): elements hidden until an IntersectionObserver fires will print blank. Add a print override: `@media print { .slide, [data-reveal] { opacity: 1 !important; transform: none !important; } }`.
- **Multi-slide decks**: force one slide per page with `.slide { page-break-after: always; height: auto; }` inside `@media print`.
- **External images that fail to load**: headless Chrome won't wait forever; if images are missing in the PDF, ensure they're local paths or add `--virtual-time-budget=5000` to the Chrome args in the script call.
- **Fonts**: Google Fonts load fine (network is available); if a font is missing, the PDF silently falls back — spot-check the output.

## Verify

Always open/inspect the produced PDF (Read the file or check page count/size) before telling the user it's done — a 2 KB PDF is a blank render.
