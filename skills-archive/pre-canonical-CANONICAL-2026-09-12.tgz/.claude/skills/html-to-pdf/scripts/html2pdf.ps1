param(
    [Parameter(Mandatory)][string]$HtmlPath,
    [string]$OutPdf
)
$chrome = @(
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    "/Applications/Chromium.app/Contents/MacOS/Chromium",
    "$HOME/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
) | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $chrome) { Write-Error "Chrome not found in standard locations"; exit 1 }

$html = (Resolve-Path $HtmlPath -ErrorAction Stop).Path
if (-not $OutPdf) { $OutPdf = [IO.Path]::ChangeExtension($html, '.pdf') }
$uri = "file:///" + ($html -replace '\\', '/')

& $chrome --headless=new --disable-gpu --no-pdf-header-footer --print-to-pdf="$OutPdf" $uri 2>$null | Out-Null

if ((Test-Path $OutPdf) -and ((Get-Item $OutPdf).Length -gt 0)) {
    "OK: $OutPdf ($([math]::Round((Get-Item $OutPdf).Length / 1kb)) KB)"
} else {
    Write-Error "PDF not produced — check the HTML renders in a normal Chrome window first"
    exit 1
}
