---
name: pbir-report-builder
description: "Generates Power BI report pages, visuals, and IBCS-compliant variance charts by writing PBIR JSON into PBIP project folders. Use whenever the user wants to create a Power BI page, add visuals, generate KPI cards, build charts, tables or dashboard layouts, or mentions 'PBIR', 'IBCS', 'variance chart', 'variance table', 'actual vs plan'."
---

# PBIR Report Builder

Add pages and visuals to existing Power BI PBIP projects by writing PBIR (Enhanced Report Format) JSON files directly into the project folder structure.

## Critical: Hybrid Approach (Do NOT Create PBIP From Scratch)

**NEVER create an entire PBIP project from scratch.** Power BI Desktop generates boilerplate files (`report.json`, `.platform`, `version.json`, theme packages, settings) with version-specific schema references, real GUIDs, and internal settings that are impractical to replicate manually.

**The correct workflow:**
1. **User creates a blank PBIP** — open Power BI Desktop, connect to the data source, save as PBIP format. This generates all boilerplate correctly.
2. **User creates measures and columns** — build your semantic model in Power BI Desktop as usual.
3. **This skill adds pages and visuals** — write PBIR JSON files into the existing `.Report/definition/` folder to create report pages with visuals.

**Why not from scratch?** The `report.json` file contains Desktop-version-specific theme references (e.g., `CY26SU02` with nested version objects), resource packages, 6+ report settings, and the `.platform` files need real UUIDs. These change between Desktop versions and cannot be reliably generated.

### PBIP File Structure (for reference — user creates this by saving)
```
ProjectName.pbip                           ← entry point (Desktop creates)
ProjectName.Report/
  .platform                                ← Desktop creates (Report type, UUID)
  definition.pbir                          ← Desktop creates (links to semantic model)
  definition/
    report.json                            ← Desktop creates (theme, settings)
    version.json                           ← Desktop creates
    pages/
      pages.json                           ← WE MODIFY (add page to pageOrder)
      pg01Overview/                        ← WE CREATE
        page.json                          ← WE CREATE
        visuals/
          v01KpiSales/visual.json          ← WE CREATE
ProjectName.SemanticModel/
  .platform                                ← Desktop creates (SemanticModel type, UUID)
  definition.pbism                         ← Desktop creates (NOT definition.tmdl!)
  definition/
    database.tmdl                          ← Desktop creates (compatibilityLevel: 1600)
    model.tmdl                             ← Desktop creates
    tables/*.tmdl                          ← Desktop creates
```

**Key learning:** The semantic model entry point is `definition.pbism` (a JSON file), NOT `definition.tmdl`. TMDL files go inside the `definition/` subfolder.

## Reference material

**No files are bundled with this skill** — work from the inline patterns in this SKILL.md (page.json and visual.json templates in the "JSON Structure Reference" section below, IBCS palette/workflow in "IBCS Visuals"). For anything beyond the inline patterns:

- Official PBIR JSON schemas (authoritative, versioned): https://developer.microsoft.com/json-schemas/fabric/item/report/definition/ — fetch the schema matching the `$schema` URL in the file you're writing.
- PBIR format docs: search Microsoft Learn for "Power BI enhanced report format (PBIR)".
- Always read the project's existing `report.json` and an existing page/visual first and match its schema versions — that beats any external reference.

## How It Works

### Step 0: Prerequisites

Before using this skill, verify:
1. **A PBIP project already exists** — user must have saved a `.pbip` from Power BI Desktop
2. **The semantic model is connected** — the `.SemanticModel/` folder has data tables with columns
3. **Measures exist** — created in Power BI Desktop
4. **Power BI Desktop is CLOSED** — files cannot be written while Desktop has the project open

If the user doesn't have a PBIP yet, instruct them to:
1. Open Power BI Desktop
2. Connect to their data source
3. File → Save As → select "Power BI Project (.pbip)" format
4. This creates the full boilerplate structure that this skill needs

### Step 1: Gather Requirements

Ask the user:
1. **Target PBIP project path** — where to write the files (must already exist as a saved PBIP)
2. **Page name and purpose** — e.g., "Sales Overview", "Product Drillthrough"
3. **Canvas size** — read from existing `page.json` files when pages exist. If none exist and the user hasn't specified, ask with the **AskUserQuestion tool**: options "Standard 1280x720 (Recommended)", "Report 1300x900", "Wide 1600x900", "Full HD 1920x1080" — the user can always pick Other for custom dimensions
4. **Visuals needed** — what charts/cards/tables, and what data they show
5. **Measures and columns** — table.field references for each visual (case-sensitive, must match model exactly)
6. **Layout** — natural language ("4 KPIs at top, bar chart left, line chart right") or pixel positions

If the user has a background SVG, use those exact grid positions.

### Step 2: Generate the PBIR Files

Write files directly into the project's `.Report/definition/` folder.

#### File Generation Order:
1. Create page folder: `definition/pages/pg##Name/`
2. Create `page.json` in that folder
3. Create `visuals/` subfolder
4. For each visual, create `visuals/v##Name/visual.json`
5. Update `definition/pages/pages.json` — add the new page to `pageOrder`

### Step 3: Naming Convention

**ALWAYS use readable names:**
- Pages: `pg01Overview`, `pg02SalesDetail`, `pg03Drillthrough`
- Visuals: `v01KpiTotalSales`, `v02BarByRegion`, `v03LineTrend`
- The `name` field inside the JSON MUST match the folder name exactly

Zero-padded index + PascalCase purpose; the JSON `name` field and folder name must always match.

### Step 4: Deliver

Tell the user:
1. Files have been written to `[path]`
2. Close Power BI Desktop if open, then reopen the `.pbip` file
3. The new page should appear with all visuals

---

## JSON Structure Reference

### page.json Template
```json
{
  "$schema": "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/page/2.0.0/schema.json",
  "name": "pg01Overview",
  "displayName": "Overview",
  "displayOption": "FitToPage",
  "width": 1280,
  "height": 720
}
```

Canvas sizes:
- Standard: `1280` x `720`
- Report: `1300` x `900`
- Wide: `1600` x `900`
- Full HD: `1920` x `1080`

Page types:
- Standard: omit `type` field
- Drillthrough: add `"type": "Drillthrough"`
- Tooltip: add `"type": "Tooltip"`, use smaller dimensions (320x240)
- Hidden: add `"visibility": "HiddenInViewMode"`

### visual.json — Visual Container Structure
```json
{
  "$schema": "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/visualContainer/2.0.0/schema.json",
  "name": "v01Kpi",
  "position": {
    "x": 30, "y": 80, "z": 1000,
    "width": 280, "height": 150, "tabOrder": 0
  },
  "visual": {
    "visualType": "cardVisual",
    "query": {
      "queryState": {
        "ROLE_NAME": {
          "projections": [
            {
              "field": { "...": "..." },
              "queryRef": "Table.Field",
              "nativeQueryRef": "Field"
            }
          ]
        }
      }
    },
    "objects": {},
    "drillFilterOtherVisuals": true
  }
}
```

## Field Reference Patterns

**Column (axes, categories, slicers):**
```json
{ "Column": { "Expression": { "SourceRef": { "Entity": "TABLE_NAME" } }, "Property": "COLUMN_NAME" } }
```

**Measure (values, KPIs):**
```json
{ "Measure": { "Expression": { "SourceRef": { "Entity": "TABLE_NAME" } }, "Property": "MEASURE_NAME" } }
```

Rules:
- `Entity` = exact table name from semantic model (case-sensitive)
- `Property` = exact column or measure name (case-sensitive)
- `queryRef` = `"Table.Field"` (dot-separated)
- `nativeQueryRef` = just the field name

## Visual Types — Quick Reference

- `cardVisual` — KPI card (roles: Data, ReferenceLabels, AdditionalMeasure)
- `clusteredColumnChart` / `clusteredBarChart` (roles: Category, Y, Series, Tooltips)
- `columnChart` / `barChart` — stacked variants
- `lineChart` (roles: Category, Y, Y2, Series)
- `lineClusteredColumnComboChart` / `lineStackedColumnComboChart` (roles: Category, ColumnY, LineY, Series)
- `tableEx` — table (role: Values)
- `pivotTable` — matrix (roles: Rows, Columns, Values)
- `slicer` (role: Values)
- `donutChart` / `pieChart` (roles: Category, Y)

## Layout Grids

### Standard Canvas (1280x720) — No Sidebar

**4 KPI Cards at Top:** y=80, height=130, width=280, x=30/330/630/930
**Header Bar:** x=0, y=0, width=1280, height=60
**2x2 Visual Grid:** width=600, height=230, positions (30,230)(650,230)(30,480)(650,480)
**Single Large Visual:** x=30, y=230, width=1220, height=480

### Wide Canvas (1600x900) — With Sidebar

**Header + Sidebar:** Header (0,0,1600,60), Sidebar (0,60,220,840)
**4 KPI Cards:** y=80, height=130, width=310, x=240/570/900/1230
**2x2 Visual Grid:** width=650, height=310, positions (240,230)(910,230)(240,560)(910,560)

### Z-Order
- Slicers/header: 500-999
- KPI cards: 1000-1099
- Main visuals: 2000-2099
- Decorative: 100-499

## Implementation Method

Use Node.js (.mjs) scripts to write files. Avoid the Write tool on paths with spaces (EEXIST errors).

```javascript
import { writeFileSync, mkdirSync, readFileSync } from 'fs';
import { join } from 'path';

const projectBase = 'PATH_TO_PBIP_PROJECT';
const reportDef = join(projectBase, 'ProjectName.Report', 'definition');

const pageDir = join(reportDef, 'pages', 'pg01Overview');
const visualsDir = join(pageDir, 'visuals');
mkdirSync(visualsDir, { recursive: true });

writeFileSync(join(pageDir, 'page.json'), JSON.stringify(pageJson, null, 2), 'utf8');

for (const visual of visuals) {
  const vDir = join(visualsDir, visual.name);
  mkdirSync(vDir, { recursive: true });
  writeFileSync(join(vDir, 'visual.json'), JSON.stringify(visual, null, 2), 'utf8');
}

const pagesJsonPath = join(reportDef, 'pages', 'pages.json');
const pagesJson = JSON.parse(readFileSync(pagesJsonPath, 'utf8'));
if (!pagesJson.pageOrder.includes('pg01Overview')) {
  pagesJson.pageOrder.push('pg01Overview');
}
writeFileSync(pagesJsonPath, JSON.stringify(pagesJson, null, 2), 'utf8');
```

## Important Caveats

1. **Power BI Desktop must be closed** before writing files
2. **Invalid JSON causes blocking errors** — validate structure before writing
3. **Entity and Property names are case-sensitive** — must match semantic model exactly
4. **The `name` field must match the folder name** — for both pages and visuals
5. **Max 50 characters** for page/visual names
6. **Always include $schema** — Desktop validates against these schemas
7. **NEVER create a PBIP from scratch** — always work with an existing Desktop-saved project
8. **Semantic model entry point is `definition.pbism`** (JSON), NOT `definition.tmdl`
9. **`.platform` files need real UUIDs** — only Desktop generates these correctly
10. **Schema versions matter** — use v2.0.0 for visualContainer/page, v1.3.0+ for report
11. **Read existing `report.json` first** — match its schema version and theme name

## IBCS Visuals (Integrated)

Full support for IBCS (International Business Communication Standards) variance charts and tables using only native Power BI visuals.

**Trigger on:** "IBCS", "variance chart", "variance table", "actual vs plan", "actual vs comparison", "AC vs PY"

### IBCS Templates

| # | Template | Visual Type | Best For |
|---|----------|-------------|----------|
| 1 | Column Variance Chart | `lineClusteredColumnComboChart` | Time series comparison |
| 2 | Bar Variance Chart | `barChart` | Ranked category comparison |
| 3 | Variance Table (Simple) | `pivotTable` | Table with numeric AC + SVG variance |
| 4 | Variance Table (Full) | `pivotTable` | Full SVG table (AC, PY bars + variance) |

### IBCS Color Palette
- Actual: `#0C3549` (dark blue)
- Comparison: `#CCCCCC` (gray)
- Positive variance: `#44C088` (green)
- Negative variance: `#ED7373` (red)

### IBCS Workflow

1. Collect 3 inputs: actual measure, comparison measure, category column
2. Select template with the **AskUserQuestion tool** — offer all 4 IBCS templates as options, your recommendation first with "(Recommended)" appended (time series → 1 Column Variance Chart, ranked categories → 2 Bar Variance Chart, detail → 3 Variance Table Simple or 4 Variance Table Full); the user can always pick Other
3. Generate helper DAX measures (skill is 100% measure-agnostic)
4. Write `visual.json` to PBIP project's report folder
5. User reloads in Power BI Desktop
