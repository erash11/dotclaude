#!/bin/bash
# brain-audit measurement pass. Facts only, no judgement.
# Emits `key: value` lines. The skill scores from these; it must not guess them.
# Deliberately never fails the whole run: a missing path prints "MISSING", not an error.

VAULT="/Users/kristinarash/SecondBrain"
CLAUDE_DIR="/Users/kristinarash/.claude"
TIER_A="$CLAUDE_DIR/projects/-Users-kristinarash-DEV/memory"
TODAY=$(date +%Y-%m-%d)

# newest mtime (YYYY-MM-DD) of *.md under a dir; "none" if empty/missing
newest() {
  [ -d "$1" ] || { echo "none"; return; }
  # `{} +` batches the stat calls. `{} \;` spawns one process per file and made
  # a full run take minutes once the vault passed ~800 notes.
  find "$1" -name '*.md' -exec stat -f '%Sm' -t '%Y-%m-%d' {} + 2>/dev/null | sort -r | head -1 | grep . || echo "none"
}
count() {
  [ -d "$1" ] || { echo 0; return; }
  find "$1" -name '*.md' 2>/dev/null | wc -l | tr -d ' '
}
# whole days between YYYY-MM-DD and today.
# Both timestamps are pinned to 12:00:00. BSD `date -j -f '%Y-%m-%d'` fills the
# unspecified time fields from the clock at call time, so two calls in the same
# run drifted and the same date reported 34 days in one line and 35 in the next.
days_since() {
  [ "$1" = "none" ] && { echo "-"; return; }
  local t s
  t=$(date -j -f '%Y-%m-%d %H:%M:%S' "$TODAY 12:00:00" +%s 2>/dev/null) || { echo "-"; return; }
  s=$(date -j -f '%Y-%m-%d %H:%M:%S' "$1 12:00:00" +%s 2>/dev/null) || { echo "-"; return; }
  echo $(( (t - s) / 86400 ))
}

echo "run_date: $TODAY"
echo ""

echo "## vault folders (count | newest | days_stale)"
for d in Notes Drafts Archive Knowledge Projects Inbox; do
  n=$(newest "$VAULT/$d")
  echo "$d: $(count "$VAULT/$d") | $n | $(days_since "$n")"
done
echo ""

echo "## capture vs synthesis"
# Inbox is cron-fed, so its freshness proves nothing. Notes/Drafts are the real signal.
LAST_INTERVIEW=$(ls -1 "$VAULT/Inbox" 2>/dev/null | grep -E '^[0-9]{4}-[0-9]{2}-[0-9]{2}-interview\.md$' | sort -r | head -1 | cut -c1-10)
[ -z "$LAST_INTERVIEW" ] && LAST_INTERVIEW=none
echo "last_interview: $LAST_INTERVIEW | $(days_since "$LAST_INTERVIEW")"
GRILLS=$(count "$VAULT/Inbox/grills")
echo "grill_sessions: $GRILLS"
MEET=$(newest "$VAULT/Inbox/meetings")
echo "last_meeting_sync: $MEET | $(days_since "$MEET")"
LEDGER="$VAULT/output/_ledger.md"
if [ -f "$LEDGER" ]; then
  echo "ledger_newest: $(stat -f '%Sm' -t '%Y-%m-%d' "$LEDGER")"
else
  echo "ledger_newest: MISSING"
fi
echo ""

echo "## audit history"
PREV=$(ls -1 "$VAULT/audits" 2>/dev/null | grep -E '[0-9]{4}-[0-9]{2}-[0-9]{2}' | sort -r | head -1)
if [ -n "$PREV" ]; then
  PD=$(echo "$PREV" | grep -oE '[0-9]{4}-[0-9]{2}-[0-9]{2}' | head -1)
  echo "last_audit: $PREV | $(days_since "$PD") days ago"
else
  echo "last_audit: none"
fi
echo "audit_count: $(ls -1 "$VAULT/audits" 2>/dev/null | grep -c '\.md$')"
echo ""

echo "## context layer (memory)"
for f in "$CLAUDE_DIR/global-memory/USER.md:1375" "$CLAUDE_DIR/global-memory/MEMORY.md:2500"; do
  p="${f%:*}"; cap="${f##*:}"
  if [ -f "$p" ]; then
    c=$(wc -c < "$p" | tr -d ' ')
    echo "$(basename "$p"): $c / $cap chars ($(( c * 100 / cap ))%)"
  else
    echo "$(basename "$p"): MISSING"
  fi
done
echo "tier_a_memories: $(ls -1 "$TIER_A"/*.md 2>/dev/null | grep -vc 'MEMORY.md$')"
echo "compiled_articles: $(find "$CLAUDE_DIR/claude-memory-compiler/knowledge" -name '*.md' 2>/dev/null | wc -l | tr -d ' ')"
echo ""

echo "## connections"
# Connections are scored on whether synced data is FRESH, not on how many
# integrations are configured. A configured-but-silent connector scores zero.
# (Counting MCP entries in ~/.claude.json was tried and dropped: claude.ai
# connectors and plugin MCPs do not appear there, so the number reads ~1.)
PORT="/Users/kristinarash/DEV/project-triage/portfolio.json"
if [ -f "$PORT" ]; then
  echo "portfolio_json: $(stat -f '%Sm' -t '%Y-%m-%d' "$PORT")"
else
  echo "portfolio_json: MISSING"
fi
echo ""

echo "## cadence (scheduled jobs)"
launchctl list 2>/dev/null | grep -i keystone | awk '{print "job: "$3" exit="$2}' || echo "job: none found"
echo ""

echo "## capabilities"
echo "skills_installed: $(ls -1d "$CLAUDE_DIR/skills"/*/ 2>/dev/null | wc -l | tr -d ' ')"
echo ""

echo "## errors"
ERR="$CLAUDE_DIR/global-memory/transcripts/.errors.log"
if [ -s "$ERR" ]; then
  echo "errors_log_lines: $(wc -l < "$ERR" | tr -d ' ')"
else
  echo "errors_log_lines: 0"
fi
