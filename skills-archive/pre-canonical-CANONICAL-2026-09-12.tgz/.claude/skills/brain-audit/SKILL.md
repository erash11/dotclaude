---
name: brain-audit
description: Score the second brain as a system — the four C's (context, connections, capabilities, cadence) — write a dated report to ~/SecondBrain/audits/, append the score to a trend table, and end by proposing exactly two next builds. Use when the user says "/brain-audit", "audit my second brain", "score my brain", "is my second brain working", "how healthy is my system", "level up my brain", "what should I build next for my brain", or when a monthly ritual is due. NOT FOR automation plumbing — launchd jobs, venvs, backup freshness (use claude-stack-doctor). NOT FOR note-level rot — stale seeds, duplicates, conflicting claims (use improve-system).
---

# Brain Audit

Score the second brain, store the score, propose two builds. Then stop.

The point is the **trend**, not any single run. A score that only exists once is
the failure this skill was built to fix: `~/SecondBrain/audits/` held exactly one
report for 45 days before this skill existed.

## Step 1 — measure

```bash
bash ~/.claude/skills/brain-audit/measure.sh
```

Facts only, ~7 seconds. **Never estimate a number this script reports.** If a
value reads `MISSING` or `none`, that is a finding, not an error to work around.

## Step 2 — score the four C's, 25 points each

Anchor every score to a measured number so two runs a month apart are comparable.

| C | What it measures | 25 pts | 13 pts | 0 pts |
|---|---|---|---|---|
| **Context** | Evergreen facts on disk | `USER.md` + `MEMORY.md` under cap, 35+ Tier A memories, `Knowledge/` touched <14d | one file over cap, or `Knowledge/` 14–45d stale | a memory file MISSING, or `Knowledge/` >45d stale |
| **Connections** | Live data arriving | `meeting_sync` <7d, `portfolio_json` <14d, `ledger` <30d | one source 2× its window | two or more sources silent |
| **Capabilities** | Skills that get used | audit-driven builds shipped since last run | skills exist, none exercised | skills installed and never run |
| **Cadence** | What keeps it alive | all launchd jobs `exit=0` **and** `Notes/` <21d | jobs green, `Notes/` 21–45d | `Notes/` >45d, or any job non-zero |

Cadence is scored hardest on `Notes/`, not on the jobs. Every job being green while
synthesis is frozen is the exact failure this system keeps repeating.

## Step 3 — run the three tests

Answer each with evidence from Step 1, and mark pass / warn / fail.

1. **Teammate test.** A teammate asks a question. Would the system answer it faster
   than Eric from memory, with sources? Evidence: is the answer actually filed, or
   still only in his head?
2. **Context-switch test.** Can the work be done from one surface? Evidence: command
   centre and dashboard freshness.
3. **Head-emptying test.** Has a decision been captured, or is it being re-litigated?
   Evidence: open items in `MEMORY.md` "Pending Decisions" with no note behind them.

These shape the narrative. They do not move the number.

## Step 4 — write the report

`~/SecondBrain/audits/brain-audit-YYYY-MM-DD.md`, frontmatter `type: resource`.

Sections: score table (four C's + total) → the three tests → what would make the
agent wrong-answer him today → the two proposed builds.

Then append one row to `~/SecondBrain/audits/_trend.md` (create with a header if
absent):

```
| Date | Context | Connections | Capabilities | Cadence | Total | Headline |
```

## Step 5 — level up: propose exactly two builds

Two. Not twelve. A list of twelve is how the last audit's findings died.

Pick against the lowest-scoring C, and check the proposal against
`user_working-conditions-bottleneck.md` — a build that does not touch the stated
bottleneck is the wrong build.

**Prefer automating an existing manual step over adding a new capability.** Measured
history says anything on a timer survives and anything manual stops within six weeks.

Propose, then stop. Do not build them in the same run.

## Gotchas

- **`Inbox/` freshness proves nothing.** It is cron-fed by `meeting-sync` and grows
  daily whether or not the brain is working. Scoring it green hides the real state.
  `Notes/` and `Drafts/` are the honest signal.
- **The recurring disease: everything with a cron is alive, everything manual is
  frozen.** Found 2026-07-24, still true 2026-09-07 — synthesis restarted after that
  audit (11 → 23 notes) and stopped again five weeks later. Expect this pattern; a
  fix that depends on remembering to run something is not a fix.
- **This skill overlaps two others and must not duplicate them.** `claude-stack-doctor`
  owns plumbing; `improve-system` owns note rot. If a finding is "launchd job failed"
  or "these two notes conflict", hand it off by name instead of re-reporting it.
- **Do not run `ingest-resource` on the report.** It is already in the vault.
- **`days_since` pins both timestamps to 12:00:00.** BSD `date -j -f '%Y-%m-%d'` fills
  unspecified time fields from the clock, so an unpinned version reported the same
  date as 34 days on one line and 35 on the next. Keep the pin.
- **Scoring drift breaks the trend.** If a rubric anchor in Step 2 is changed, note the
  change in `_trend.md` on that row, or the column stops meaning one thing.
