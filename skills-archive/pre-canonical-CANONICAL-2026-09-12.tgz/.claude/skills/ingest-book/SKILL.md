---
name: ingest-book
description: Ingest a book (PDF/EPUB full-text, Kindle highlights, or framework-only from a physical book) into the SecondBrain library as atomized, citable advisor entries. Use when the user wants to "ingest a book", "add a book to my library/advisors", "/ingest-book", or points at a book file for the advisor system. For articles/transcripts/general resources use ingest-resource instead.
argument-hint: "[book file or title] [domain]"
---

# Ingest Book

Turn a book into atomized, citable entries under the library subtree, grouped by domain and book, ready for the `advisor` skill.

**Library root:** `/Users/kristinarash/SecondBrain/Knowledge/library`
**Paths:** canonical vault locations live in `/Users/kristinarash/.claude/skills/_shared/config.json` (`vault_library`, `vault_root`) — load it if unsure; if a literal path here ever disagrees, the config wins.
**Extractors:** `~/.claude/skills/ingest-book/lib/extract_epub.py`, `extract_pdf.py`
Run extractors inside the context-mode sandbox (`ctx_execute`, language python) so raw book text never enters the conversation — only the atomized entries you write do.

## Model split (cost vs quality)

This skill mixes three kinds of work with very different model needs:
- **Extraction & structure mapping** (probe, chapter map, text cleanup) — deterministic
  Python in the sandbox. **Zero model tokens; model choice irrelevant.**
- **Orchestration** (searches, `_book.md` updates, dedup checks) — mechanical.
  **Haiku-tier is fine.**
- **Atomization** (Phase 2/3: distilling prose into accurate entries with correct
  mechanism-vs-claim, honest confidence, and a real "when NOT to apply") — this is where
  the advisor's entire value is created. **Run on Sonnet or stronger. Do NOT use Haiku
  for atomization** — a weak distillation becomes a permanent low-quality entry, and the
  generated output is only ~3K tokens/chapter, so quality-per-token matters far more than
  price-per-token. Cost levers that DON'T hurt quality: atomize only chapters you'll
  consult, and checkpoint + `/clear` between chapter batches (see Rules) so context
  doesn't compound across the book.

## Schema for every entry note

Filename: `<kind>--<kebab-slug>.md`, `kind ∈ {principle, framework, case-study, heuristic, claim}`.

```yaml
---
type: library-entry
kind: principle
domain: <domain-slug>
book: <book-slug>
chapter: "N"            # or section label; "" if highlights with no location
topic: <2-5 word topic>
category: [tag, tag]
confidence: proven      # proven | supported | untested | contested
ingest-tier: full-text  # full-text | highlights | framework-only
created: <YYYY-MM-DD>
---

# <Human title of the idea>

**What it is** — one tight paragraph.
**Why it works** — mechanism, not restatement.
**When to apply** — concrete triggers.
**When NOT to apply** — scope limits. (MANDATORY — never omit.)
**Example** — one concrete instance.
```

**Confidence is bounded by tier:** full-text ≤ proven; highlights ≤ supported;
framework-only ≤ untested. Set `contested` by hand when sources conflict.

## Phase 1 — Intake

1. Identify: book title, author, source type (PDF/EPUB | Kindle highlights | physical), target domain.
2. Compute `<book-slug>` = `kebab(title)--kebab(lastname)` (e.g. `supertraining--verkhoshansky`).
3. If the domain folder/`_domain.md` doesn't exist, create them (mirror the S&C `_domain.md` format).
4. Build `_book.md` chapter map:
   - EPUB/PDF: run the extractor with `--list` / `--probe` to get the chapter or page structure.
   - Physical: ask the user for the chapter list, or assemble from a verified public listing.
   Write `_book.md` (template below) with every chapter `status: pending`.

`_book.md` template:
```markdown
---
type: book-index
book: <book-slug>
title: <full title>
author: <author>
domain: <domain-slug>
ingest-tier: full-text | highlights | framework-only
source: "<file path or 'physical' or 'kindle-highlights'>"
created: <YYYY-MM-DD>
---

# <title> — ingest map

| # | Chapter | Status | Entries |
|---|---------|--------|---------|
| 0 | <title> | pending | 0 |
```

## Phase 2 — Extract (by tier)

**Full-text (PDF/EPUB):**
- First run `extract_pdf.py --probe`. If `scanned: true`, STOP the full-text path:
  tell the user the PDF is image-only, and fall back to framework-only tier (set
  `ingest-tier: framework-only`, cap confidence at untested). Never emit full-text-
  confidence entries from a scanned file.
- Work **one chapter at a time** (EPUB `--chapter N`; PDF `--pages A-B`). For each:
  extract candidate ideas → atomize per the schema → write entry notes.
- **After each chapter**, update that row in `_book.md` to `status: done` with the
  entry count. This is the resume checkpoint — never batch this update.

**Kindle highlights:**
- Parse `My Clippings.txt` or the highlights export in the sandbox. Cluster highlights
  by theme; write one entry per theme. `ingest-tier: highlights`, confidence ≤ supported.
- Attribute `chapter` from the highlight's location metadata when present, else "".

**Framework-only (physical / scanned):**
- Briefly interview the user for their takeaways. Supplement with *verified* public
  chapter summaries. Write 5–15 framework-level entries. `ingest-tier: framework-only`,
  confidence ≤ untested.

## Phase 3 — Quality gate (run before writing each batch)

- One idea per note. If an extracted point is compound, split it.
- "When NOT to apply" present and non-trivial.
- **Dedup + converge:** before writing, `memsearch search` the library for the same
  concept. If an existing entry (any book) covers it, DON'T duplicate — instead add a
  `[[wikilink]]` + one line to both notes recording the agreement, and only add a new
  note if it contributes a genuinely new angle.
- Never overwrite an existing file; on slug collision append `-2`.

## Phase 4 — Close-out

1. Set all done rows in `_book.md`; if partial, leave pending rows for next session.
2. Add the book to `_domain.md`'s `books:` list and the "Books in this domain" section.
3. Add the book-slug to the advisor persona's `books:` list (`advisors/<domain>.md`)
   if an advisor exists.
4. Run `memsearch index "/Users/kristinarash/SecondBrain/Knowledge/library"`
   so entries are searchable immediately (don't wait for the SessionEnd hook).
5. Commit the vault: `git -C "/Users/kristinarash/SecondBrain" add Knowledge/library && git commit -m "ingest(<book-slug>): <N> entries, ch X-Y"`.
6. Report: entries by kind and confidence, links created, chapters remaining.

## Rules
- Raw book text stays in the sandbox; only atomized entries enter context/the vault.
- Resumable by design: `_book.md` is the source of truth for "where am I".
- A 300-page book is a multi-session job — stop at a chapter boundary, never mid-chapter.
