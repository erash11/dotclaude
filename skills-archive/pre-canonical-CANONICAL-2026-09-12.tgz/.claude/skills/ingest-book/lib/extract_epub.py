"""Extract an EPUB into ordered (title, text) chapters as JSON.
Usage: python extract_epub.py <book.epub> [--chapter N] [--list]
Stdlib only (zipfile + html parsing) so it runs anywhere.
"""
import sys, zipfile, re, json, html
from html.parser import HTMLParser

class _Text(HTMLParser):
    def __init__(self):
        super().__init__()
        self.skip = 0
        self.parts = []
    def handle_starttag(self, tag, attrs):
        if tag in ("script", "style"): self.skip += 1
        if tag in ("p", "br", "div", "h1", "h2", "h3", "li"): self.parts.append("\n")
    def handle_endtag(self, tag):
        if tag in ("script", "style") and self.skip: self.skip -= 1
    def handle_data(self, data):
        if not self.skip: self.parts.append(data)
    def text(self):
        t = html.unescape("".join(self.parts))
        return re.sub(r"\n{3,}", "\n\n", re.sub(r"[ \t]+", " ", t)).strip()

def _spine_docs(z):
    # Find the OPF, read spine order -> list of html hrefs.
    container = z.read("META-INF/container.xml").decode("utf-8", "replace")
    opf_path = re.search(r'full-path="([^"]+)"', container).group(1)
    opf = z.read(opf_path).decode("utf-8", "replace")
    base = opf_path.rsplit("/", 1)[0] + "/" if "/" in opf_path else ""
    ids = dict(re.findall(r'<item[^>]*id="([^"]+)"[^>]*href="([^"]+)"', opf))
    ids.update(dict((m[1], m[0]) for m in re.findall(r'<item[^>]*href="([^"]+)"[^>]*id="([^"]+)"', opf)))
    order = re.findall(r'<itemref[^>]*idref="([^"]+)"', opf)
    docs = []
    for ref in order:
        href = ids.get(ref)
        if href and href.lower().endswith((".html", ".xhtml", ".htm")):
            docs.append(base + href)
    return docs

def chapters(path):
    out = []
    with zipfile.ZipFile(path) as z:
        names = set(z.namelist())
        for href in _spine_docs(z):
            if href not in names:  # tolerate path normalization
                href = href.replace("../", "")
                if href not in names: continue
            raw = z.read(href).decode("utf-8", "replace")
            p = _Text(); p.feed(raw)
            txt = p.text()
            if len(txt) < 200:  # skip nav/title slivers
                continue
            title = ""
            m = re.search(r"<h[1-3][^>]*>(.*?)</h[1-3]>", raw, re.S | re.I)
            if m:
                title = re.sub(r"<[^>]+>", "", m.group(1)).strip()
            out.append({"title": title or href.rsplit("/",1)[-1], "chars": len(txt), "text": txt})
    return out

def main():
    args = sys.argv[1:]
    if not args:
        print("usage: extract_epub.py <book.epub> [--chapter N] [--list]", file=sys.stderr); sys.exit(2)
    path = args[0]
    chs = chapters(path)
    if "--list" in args:
        print(json.dumps([{"i": i, "title": c["title"], "chars": c["chars"]} for i, c in enumerate(chs)], ensure_ascii=False))
        return
    if "--chapter" in args:
        n = int(args[args.index("--chapter") + 1])
        print(json.dumps(chs[n], ensure_ascii=False))
        return
    print(json.dumps([{"i": i, "title": c["title"], "chars": c["chars"]} for i, c in enumerate(chs)], ensure_ascii=False))

if __name__ == "__main__":
    main()
