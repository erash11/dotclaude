"""Extract a PDF into per-page text as JSON, and detect scanned/image PDFs.
Usage: python extract_pdf.py <book.pdf> [--pages A-B] [--probe]
Prefers pypdf; if absent, attempts pip install into user site at runtime.
--probe prints {"pages": N, "text_pages": K, "scanned": bool} and exits.
"""
import sys, json, subprocess

def _ensure_pypdf():
    try:
        import pypdf  # noqa
        return
    except ImportError:
        subprocess.run([sys.executable, "-m", "pip", "install", "--quiet", "--user", "pypdf"], check=False)

def load(path):
    _ensure_pypdf()
    from pypdf import PdfReader
    return PdfReader(path)

def page_texts(reader):
    out = []
    for pg in reader.pages:
        try: out.append(pg.extract_text() or "")
        except Exception: out.append("")
    return out

def main():
    args = sys.argv[1:]
    if not args:
        print("usage: extract_pdf.py <book.pdf> [--pages A-B] [--probe]", file=sys.stderr); sys.exit(2)
    path = args[0]
    reader = load(path)
    texts = page_texts(reader)
    if "--probe" in args:
        text_pages = sum(1 for t in texts if len(t.strip()) > 40)
        n = len(texts)
        scanned = n > 0 and (text_pages / n) < 0.2
        print(json.dumps({"pages": n, "text_pages": text_pages, "scanned": scanned}))
        return
    lo, hi = 0, len(texts)
    if "--pages" in args:
        rng = args[args.index("--pages") + 1]
        a, b = rng.split("-")
        lo, hi = int(a), int(b)
    print(json.dumps([{"page": i, "text": texts[i]} for i in range(lo, min(hi, len(texts)))], ensure_ascii=False))

if __name__ == "__main__":
    main()
