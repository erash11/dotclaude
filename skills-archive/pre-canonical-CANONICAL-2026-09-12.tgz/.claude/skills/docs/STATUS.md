# STATUS

## Current state
- The global skill audit is complete.
- The old global skill set was moved out of this repo.
- The active skill set is smaller and uses plugin copies where possible.

## Next
- Use the smaller skill set in normal work.
- Restore a skill from the archive only when it is needed.

## Open questions
- None.

## Gotchas
- Use `CreateSkill` for skill structure work.
- Pull before work because this repo changes on two machines.
