---
name: ingest-resource
description: Ingest any article, YouTube link, transcript, PDF, or note into the SecondBrain vault — routes it to Knowledge/ (stable info) or Projects/ (active work), adds a summary block, and cross-links related notes with [[wikilinks]]. Use when the user shares a URL, file, or pasted content and says "ingest", "save this", "add to my vault/second brain", "/ingest-resource", or drops a resource with intent to keep it.
argument-hint: "[URL or file path]"
---

# Ingest Resource

Turn any incoming resource into a well-placed, summarized, cross-linked vault note.

**Vault:** `/Users/kristinarash/SecondBrain/`
**Paths:** canonical vault locations live in `/Users/kristinarash/.claude/skills/_shared/config.json` — load it if unsure; if a literal path here ever disagrees, the config wins.

## Process

### 1. Acquire the content

| Input | How to get content |
|-------|-------------------|
| Article URL | WebFetch first; if empty/JS-shell, use web-scraping skill's `firecrawl_scrape.py -o tmp.md` |
| YouTube link | WebFetch the page for title/channel/description; ask user to paste transcript if the content itself is needed |
| PDF | Read tool (use `pages` for long PDFs) |
| Pasted transcript / note | Already in hand |
| Local file path | Read it |

### 2. Route it

Decide by **shelf life**, not topic:

- **`Knowledge/`** — stable reference that will still be true in a year: frameworks, mental models, voice/style guides, people profiles, processes, how-tos. Subfolder by kind: `Knowledge/frameworks/`, `Knowledge/people/`, `Knowledge/processes/`, `Knowledge/voice/` (add others as needed).
- **`Projects/`** — fuel for active work: video research, newsletter material, launch assets, anything tied to a current effort. If it belongs to an existing project file/folder (`Project_*.md`, `Graphify/`, etc.), place it alongside; otherwise drop it in `Projects/` root with a clear name.

Create any folder that doesn't exist yet (`New-Item -ItemType Directory -Force`). If routing is genuinely ambiguous, ask one question; otherwise decide and say why.

### 3. Write the note

Filename: kebab-case slug of the title (vault convention). Format:

```markdown
---
type: resource
created: YYYY-MM-DD
source: <URL, "PDF: filename", or "conversation">
domain: [one, two]
tags: [three, four]
status: ingested
---

# Title

> **Summary**
> **Source:** <link or origin> · **Date:** <published or ingested date>
> **Key people:** [[Person One]], Person Two
> **Key concepts:** concept one, concept two, concept three
>
> 2–4 sentence digest of what this is and why it was kept.

<full content or distilled body>
```

### 4. Cross-link

- List existing note names: filenames (sans `.md`) across `Notes/`, `Knowledge/`, `Projects/`.
- In the new note's body, wikilink the **first mention** of any concept/person/project that matches an existing note: `[[adoption-is-the-bottleneck]]` or `[[Project_AI-Integration|AI Integration]]`.
- Link related-but-not-mentioned notes in a `## Related` section at the bottom (2–5 links max, only genuinely related).
- A `[[wikilink]]` to a note that doesn't exist yet is fine for key people/concepts worth a future note — use sparingly.

### 5. Confirm

Report: file path, route chosen (and why), links added. One short paragraph.

## Rules

- **Never overwrite** an existing note — if the slug collides, append `-2` or merge after asking.
- Long sources (>2,000 words): keep the full text in the body but make the summary block self-sufficient.
- Don't route to `Notes/` — that folder is for synthesized permanent notes (interview-me's territory), not raw resources.
- Don't route to `Inbox/` — ingestion IS the processing step; the note lands in its final home.
