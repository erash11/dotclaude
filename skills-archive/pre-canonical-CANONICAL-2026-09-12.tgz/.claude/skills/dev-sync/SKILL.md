---
name: dev-sync
description: "Bring this machine into line with GitHub and load back the context that came with it: locate DEV automatically, pull config and skills, inventory every project, commit and push local work, pull the other machine's work, clone what is missing, report conflicts, then read the repo's STATUS and latest handoff and report where the last session left off. Use when Eric switches machines, sits down to start work, says 'sync DEV', asks whether everything is pushed, or asks where he left off."
---

# DEV sync

Eric works on a Mac and a Windows laptop. GitHub (`erash11`, all private) is the transport. This skill makes the current machine match GitHub without losing anything on either side. It is the first thing to run when sitting down at a machine.

## Step 0: find DEV (never depend on cwd)

Eric may run this from anywhere. Detect the machine and go to its DEV root:

- macOS (`uname` = Darwin): `~/DEV`
- Windows (PowerShell, or `$OS` = Windows_NT): `C:\Users\eric_rash\Desktop\DEV`

If that folder does not exist, stop and say so. Do not guess another location. Print the root you chose on the first line of output.

## Step 1: config and skills

These are separate repos and the other machine may have changed them:

1. `~/.claude` (repo `dotclaude`): `git pull`. If `~/.claude/machine.md` is missing, copy `machine.macos.md` or `machine.windows.md` to `machine.md` for this OS.
2. `~/.claude/skills` (repo `claude-skills`): `git pull`, then run `sync-to-codex.sh` (Mac) or `sync-to-codex.ps1` (Windows) so Codex sees the shared skills.
3. `~/.claude/global-memory` (repo `claude-global-memory`): `git pull`. **This is the only thing that carries memory between the two machines.** USER.md, MEMORY.md and the handoffs live here. `daily-backup` pushes this repo nightly, but nothing pulled it at the start of a session until this step existed, so a same-day handoff (worked on the Mac after lunch, picked up on Windows that evening) arrived with stale memory. Pull it before anything else reads it. If the pull brings in commits, say how many and name the newest, so it is visible that memory moved.

If any of the three has local uncommitted changes, commit them first with `<machine> snapshot before sync`, then pull, then push.

Merge note for `global-memory`: `transcripts/.errors.log` and `MEMORY.md` are both append-heavy and both machines write them. On conflict, keep both sides' content rather than choosing one — these are logs, not settings, and a dropped line is a lost memory.

## Step 2: inventory (always show before changing anything)

Walk `DEV/*`, `DEV/Football/*`, and `DEV/SpecialRequests/*`. Skip `.claude`, `_tools`, `_DRIVE` (a link to the Google Drive primary storage drive, not a project; never init it, never walk into it), `token-dashboard` (someone else's remote), and any folder ending in `_OLD_merged*`. For each folder report one of:

- **repo + erash11 remote**: uncommitted count, unpushed count
- **repo, no remote**: needs `gh repo create`
- **not a repo**: needs init + create (use the `new-project` skill's file set)

Then `gh repo list erash11 --limit 300 --json name` and list repos with no local folder. Skip: `dotclaude` (that is `~/.claude`), `SecondBrain`, `claude-skills`, `claude-memory-compiler`, `DEV`, `DexaProject`.

Eric pre-approves these operations; the inventory is for visibility, not a pause for approval, unless something looks wrong (a repo with hundreds of uncommitted files, a large file about to be added).

**Group the report by activity, not alphabetically.** Run `~/.claude/scripts/dev-activity.sh` (Mac) or `dev-activity.ps1` (Windows), which ranks repos by distinct commit days over 90 days. List the active ones individually and collapse the rest to a count: "118 dormant repos: all clean" is the useful line, not 118 names. About 14 repos are genuinely worked at any time; the rest are archives that happen to live in the same folder.

Rank by **commit days, not recency**. On 2026-09-09 a bulk migration gave 43 repos one commit each, after which every one of them looked active by any recency measure. Days-worked is not fooled by that, because a migration touches a repo once.

Nothing is archived or moved on the strength of this. Sorting is a reporting concern. Moving a dormant repo into an archive folder would break three things at once: `harvest-dev-docs` reads `<dir>/docs/*.md` without recursing, so archived repos would silently drop out of the memsearch index; KeystoneOS `projects.json`, `memory-sources.json`, `memory-index-paths.json` and `discovery-roots.json` hold DEV paths; and Tier A project memory is keyed by a slug derived from the absolute path, so moving a repo orphans its memory. Checked 2026-09-12. Do not revive the archive idea without fixing all three first.

## Step 3: apply, per repo

1. If uncommitted: put any untracked file over 95 MB and any `.env` into `.gitignore`, then `git add -A && git commit -m "<machine> snapshot before sync"`.
2. `git fetch origin` then `git merge --no-edit origin/<branch>`.
3. On conflict: keep this machine's version, save the remote version beside it as `<file>.from-mac` or `<file>.from-windows` (whichever the other machine is), stage both, commit. Never discard either side. `.DS_Store` conflicts: just delete the file.

   Save the remote side by **moving the file, never by redirecting stdout**. A
   redirect re-encodes the bytes; on Windows that silently mangles every
   non-ASCII character (an em-dash becomes `ΓÇö`) and adds a UTF-8 BOM, so the
   saved copy is corrupt and every later diff shows a phantom first-line change.

   - PowerShell: `git checkout --theirs -- <f>; Move-Item <f> <f>.from-mac; git checkout --ours -- <f>`
   - bash: `git checkout --theirs -- <f> && mv <f> <f>.from-mac && git checkout --ours -- <f>`

   Never run `git add -A` while `.git/MERGE_HEAD` exists — it stages the
   conflict markers themselves and commits a broken file. Stage only the named
   paths you just resolved.
4. `git push`.
5. Missing locally: `gh repo clone erash11/<name> DEV/<name>`.
6. No remote: `gh repo create erash11/<name> --private --source=. --push`.

Windows note: line-ending noise (`LF will be replaced by CRLF`) is normal. If a merge refuses to start because of phantom modifications, run `git add --renormalize .` and commit before merging.

Stale-lock note: if a commit or push fails with `cannot lock ref 'HEAD'`, check
`pgrep -fl git` (or `Get-Process git`) first. If no git is running and the
`.git/*.lock` file is zero bytes and older than the session, it is stale from an
interrupted run. Move it aside — do not delete it — then retry.

## Step 4: verify and report

Re-walk every repo. Report: DEV root used, config and skills pulled (yes/no), repos checked, pulled, cloned, created, and any folder still dirty or unpushed. List every `.from-*` file created so Eric can reconcile them. Finish with one line: clean or not.

## Step 5: pick up where the other machine left off

Syncing git state is only half the job. The other half is loading the context that came with it, and nothing else does this — the SessionStart hook injects global memory, but project state lives in the repo, and Tier A project memory does not cross machines because its slug is built from a path that differs per machine. This step is the only place that context gets read back in.

Do this for the repo Eric names, or the one he is in. If he has not named one, pick from the ACTIVE list in Step 2, not from all 132: take the active repo with the most recent commit and say which you chose. A dormant repo receiving one migration commit must never win this, which is exactly what picking by recency across everything would do.

1. Read `<repo>/AGENTS.md` (or `CLAUDE.md` if there is no AGENTS.md).
2. Read `<repo>/docs/STATUS.md`.
3. Read the newest file in `<repo>/docs/handoffs/`, if the folder exists and its newest file is within about two weeks.
4. If `docs/STATUS.md` does not exist in a repo that has real work in it, say so — that repo is invisible to the other machine and closeout should have created it.

Then report, in six lines or fewer, before doing any work:

```
Picking up: <repo>
Last session: <date>, <mac|windows>
Where things stand: <two lines from STATUS.md Current state>
Blocked on: <open questions, or "nothing">
Next: <top one or two from STATUS.md Next>
```

Stop there and wait for Eric to confirm or redirect. Do not start the next task off the back of STATUS.md on your own — it records where work stopped, not what he wants to do this morning.

## Do not

- Do not `rm` anything. Move to a `_to_delete` or `_OLD_*` folder if something must get out of the way.
- Do not rebase or force-push.
- Do not push DexaProject or any repo whose CLAUDE.md says its data must stay local.
