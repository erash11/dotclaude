---
name: project
description: Manage the portfolio project registry (ideas, updates, ranking, promotion, dev stages) and render/publish the dashboard. Triggers on "/project", "new idea:", "log progress on", "project update", "add to my project inbox", "show my projects", "re-rank my projects", "set the stage on", "mark <project> as spec'd/planned/shipped".
---

# /project — portfolio registry skill

Drives the shipped `project-triage` CLI to capture ideas, log progress, and
keep the front-burner dashboard current. The registry (`portfolio.json`) is
the single source of truth — never hand-edit `dashboard.html`.

## Paths

- Repo: `/Users/kristinarash/DEV/project-triage`
- Interpreter: `python3`
- Registry: `/Users/kristinarash/DEV/project-triage/portfolio.json`
- CLI entry points: `portfolio.py` (mutations), `render.py` (render)
- Generated: `dashboard.html`, `pulse.md` (both written next to the scripts;
  do not edit by hand, they are regenerated every render)

## CLI contract (verbatim — do not alter flags)

```
& "python3" "/Users/kristinarash/DEV/project-triage/portfolio.py" add-idea "<pitch>" --source "<source>"
& "python3" "/Users/kristinarash/DEV/project-triage/portfolio.py" add-update "<name>" "<note>" --next-action "<optional>"
& "python3" "/Users/kristinarash/DEV/project-triage/portfolio.py" set-stage "<name>" "<stage>"
& "python3" "/Users/kristinarash/DEV/project-triage/render.py"
& "python3" "/Users/kristinarash/DEV/project-triage/render.py" --no-scan
```

- `add-idea` prints `idea captured (<N> in inbox)`.
- `add-update` prints `updated <name>` (name match is case-insensitive).
- `set-stage` prints `stage set: <name> → <stage>`. Valid stages, in ladder
  order: `idea grilled spec planned building shipped`.
- `render.py` (full scan) prints `wrote dashboard.html · wrote pulse.md · ...`.
- `render.py --no-scan` does the same but skips the DEV/ activity heuristics
  (fast; use it after any registry mutation, and to validate hand-edits).
- Any error path prints `[error] <msg>` to stderr and exits 2, with no
  mutation to `portfolio.json`. Stop and surface the message verbatim.

## Verbs

### `idea <pitch>`
Run `add-idea "<pitch>" --source "<conversation context, ≤8 words>"`. The
source should summarize where the idea came from (e.g. "chat about GPS
vendor gaps"), not just "chat". Then do the render + republish ritual.

### `update <name> <note>`
Fuzzy-match `<name>` against the project names currently in the registry
(read `portfolio.json` first). If exactly one match, run `add-update "<name>"
"<note>"` (add `--next-action "<...>"` if the user gave one). If the match is
ambiguous or there's no close match, ask the user which project they mean
before running anything. Then do the render + republish ritual.

### `rank`
Read `portfolio.json`, show both lanes' active projects with their current
`rank` values, and ask for the new order. Never reorder ranks yourself —
only apply the order the user gives you. Rewrite the `rank` fields directly
with the Edit tool, then validate by running `render.py --no-scan` (exit 0
means the edit is structurally valid). Then do the render + republish
ritual (this counts as the render step — no need to run render.py twice).

### `promote <idea>`
Ask which lane (`job` or `side`) and for a `next_action`. With the Edit
tool: set the matching idea's `status` to `promoted`, and append a new
project entry to that lane at the next free `rank` (max existing rank in
that lane + 1). Validate with `render.py --no-scan`, then do the render +
republish ritual.

### `stage <name> <stage>`
Fuzzy-match `<name>` like `update` does. Run `set-stage "<name>" "<stage>"`.
The dashboard auto-detects spec/plan docs (in the project's DEV folder under
`docs/specs`, `docs/plans`, or the `docs/superpowers/...` variants) and
renders plan-checkbox progress — the stage is your curated claim; drift
between the two shows on the card. Then do the render + republish ritual.

**Shipped → harvest handoff:** when the stage being set is `shipped`, after
the ritual offer once: "Want me to run /harvest on <name> to distill it into
your SecondBrain and log the shipped artifact?" On yes, invoke the `harvest`
skill for that project.

### bare `/project`
Do the render + republish ritual, then show the contents of `pulse.md` in
chat.

## Render + republish ritual (run after every mutation)

1. Run `render.py --no-scan` (fast path — the mutation verbs above already
   changed the registry; a full DEV/ scan isn't needed unless the user
   explicitly asks for a fresh scan).
2. Read `meta.artifact_url` from `portfolio.json`.
   - If non-empty: publish `dashboard.html` via the Artifact tool passing
     `url: <meta.artifact_url>`, `favicon: "🔥"`, `title: "Portfolio — Front
     Burner"`.
   - If empty: publish `dashboard.html` via the Artifact tool with
     `favicon: "🔥"`, `title: "Portfolio — Front Burner"` (no `url`). Take
     the returned URL, write it into `meta.artifact_url` with the Edit tool,
     then re-run `render.py --no-scan` and republish once more (now with
     `url` set) so the rendered page displays its own share URL.

## Rules

- Never reorder project ranks yourself — only apply the order the user
  gives you during `rank`.
- Never delete a project or idea without explicit confirmation.
- On any `[error] ...` output from the CLI: stop immediately, show the
  error verbatim, and do not proceed to render/publish.
- `portfolio.json` is the single source of truth. Never edit
  `dashboard.html` directly — it is fully regenerated by `render.py`.
