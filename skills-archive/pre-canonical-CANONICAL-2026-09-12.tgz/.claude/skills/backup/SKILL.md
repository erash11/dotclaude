---
name: backup
description: Run the KeystoneOS daily backup on demand (git-push the memory repos, rsync state to Google Drive and the CRASHBOX SSD, reindex memsearch), then report what was saved and what was skipped. Use when the user says "/backup", "run the backup", "back up now", "back my stuff up", "did the backup run", "the backup failed", "I left the laptop off — catch up the backup", or when a session-start HOOK FAILURE names daily-backup. The scheduled launchd job only fires if the Mac is awake at 09:00, so this is the manual catch-up path. NOT FOR whole-stack health checks (use claude-stack-doctor).
---

# Backup

Runs `~/.claude/scripts/daily-backup.ps1` right now. Same script the `com.keystone.dailybackup`
launchd agent runs at 09:00 daily — this is the on-demand path for when the Mac was shut at 09:00.

## Run it

Do not pre-check anything. Run first, report after.

```bash
/opt/homebrew/bin/pwsh -NoProfile -File ~/.claude/scripts/daily-backup.ps1 2>&1 | tail -40
```

Use a Bash `timeout` of at least `600000` (10 min). The memsearch INDEX step is ~75s of a ~85s
healthy run; the default 2-min timeout can survive it, but a grown corpus will not.

## Read the verdict from state, not from the tail

```bash
cat ~/.claude/scripts/logs/backup-state.json
```

`status` is `OK` or `ERROR`; `errors` lists the failed job codes. That file is the authority.
The tail is for diagnosing, not for deciding.

**`status: OK` is not "everything was saved" — read `okCount` too.** A run that skipped the
SSD still ends `OK` with 0 errors. See the SSD gotcha below for what the count means.

## Then clear the stale hook error, if any

A failed run appends a line to `~/.claude/global-memory/transcripts/.errors.log`, which is surfaced
as a HOOK FAILURE at every session start. A later successful run does **not** clear it. If `status`
is now `OK` and the file contains only `daily-backup:` lines, archive and empty it:

```bash
cp ~/.claude/global-memory/transcripts/.errors.log ~/.claude/global-memory/transcripts/.errors.log.archived-$(date +%Y-%m-%d)
cp /dev/null ~/.claude/global-memory/transcripts/.errors.log
```

If any non-`daily-backup` line is present, leave the file alone and tell the user what else is in it.
Shell truncation (`: > file`) under `$HOME` is blocked by dcg rule
`core.filesystem:redirect-truncate-root-home`, and there is no `truncate` binary here — use `cp /dev/null`.

## Report

Three lines, plain: did it work, what was skipped, what to do next. Never report "backup complete"
without naming a skipped target — a silent partial backup is the failure this skill exists to prevent.

## Gotchas

**Safe to ignore — expected on a healthy run:**
- `SNAP skip (missing): ~/.codex/memories` — that path has never existed.
- `TARGET baylor deprecated in manifest - snapshots to it SKIPPED` — deliberate.

**Real gaps — always surface these to the user:**
- `TARGET SSD /Volumes/CRASHBOX/AssistantBackup NOT MOUNTED - orphan and working-tree capture SKIPPED`
  — the run still reports `OK` with 0 errors, but **untracked, gitignored, and uncommitted-modified
  files were not saved anywhere.** GitHub and Google Drive cover only committed and pushed work.
  Tell the user to plug in CRASHBOX and run again. This is the most likely way to lose real work.

  **Cross-check with `okCount`, because the error count cannot see this.** `okCount` in
  `backup-state.json` is the number of jobs that ran, and two whole job classes — `CAPTURE`
  (per-project working-tree files) and `STATE-SSD` — exist only when the SSD is mounted. So:
  - **~31 jobs** = SSD captured. **~9-10 jobs** = SSD was absent; only the 4 `REPO` pushes and
    6 Drive `SNAP`s ran (verified against runs on 2026-09-04 and 2026-09-05).
  - A single-digit `okCount` with `status: OK` is the silent partial backup. Say so out loud.
  - Do not derive this from the error count or the exit code — both read `OK` either way.
- `TARGET ... NOT MOUNTED - is Google Drive for Desktop running?` — the Drive app is not running.
  Start it, then re-run.
- `PUSH ERR ... Could not resolve host: github.com` — a network blip, not a repo problem. Confirm
  with `ping -c1 github.com`, then just re-run; the commits are already made locally and will push.
  (Seen 2026-09-04 09:05: both `global-memory` and `skills` failed this way and a re-run fixed both.)
- `repo-diverged:<name>` — automation will never merge. Reconcile that repo by hand.

**Other:**
- Every log line appears **twice** for launchd runs and once for manual runs. The script both writes
  to the log file and prints to stdout, and the plist captures stdout to the same file. Not a bug —
  do not "fix" it, and do not read doubled lines as two attempts.
- The script is PowerShell only because `pwsh` runs it natively. It manages launchd, not Task
  Scheduler; the Windows original is parked at `daily-backup.ps1.win-orig`.
- `-DryRun` is the only parameter. Use it to preview without writing.

## Examples

**Example 1: routine catch-up**
```
User: "run the backup"
→ Runs the script, reads backup-state.json (status OK, 0 errors)
→ "Backup done, no errors. Everything pushed and copied to Drive.
   CRASHBOX SSD wasn't plugged in, so uncommitted files were not saved.
   Plug it in and run /backup again if you have unsaved work."
```

**Example 2: session start shows a hook failure**
```
User: "the backup failed this morning — fix it"
→ Greps daily-backup.log for the error codes → DNS failure on both pushes
→ Confirms github.com reachable, re-runs the script → status OK
→ Archives and empties .errors.log so the warning stops appearing
```
