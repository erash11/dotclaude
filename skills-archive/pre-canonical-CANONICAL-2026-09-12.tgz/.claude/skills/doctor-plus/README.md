![doctor-plus banner](assets/banner.png)

# doctor-plus

An extended health check for Claude Code. Runs the built-in `/doctor`, then audits your workspace against the 6 then & now context-engineering shifts Anthropic shipped with the Claude 5 models.

> Anthropic cut ~80% of the Claude Code system prompt for their newest models. Most workspaces are still written for the old ones. This skill finds where yours is.

## Quick start

```bash
git clone https://github.com/robonuggets/doctor-plus
```

Copy the skill folder into your project (or your user-level skills):

```bash
cp -r doctor-plus/.claude/skills/doctor-plus <your-project>/.claude/skills/doctor-plus
```

Then in Claude Code:

```
/doctor-plus
```

## What it does

**Part 1 - the standard checkup.** Runs the built-in `claude doctor`: install health, dead weight, CLAUDE.md trimming, slow hooks.

**Part 2 - the 6 then & now shifts.** Audits your CLAUDE.md, skills, rules, and memory against the principles Anthropic now prompts by:

| # | Then | Now |
|---|---|---|
| 1 | Give Claude rules | Let Claude use judgement |
| 2 | Give Claude examples | Design interfaces |
| 3 | Put it all upfront | Use progressive disclosure |
| 4 | Repeat yourself | Simple tool descriptions |
| 5 | Memory in CLAUDE.md | Auto-memory |
| 6 | Simple specs | Rich references |

It audits the principles, not keyword patterns - and it knows safety rules (approvals, backups, destructive actions, money) are hard on purpose and never suggests softening them.

**Part 3 - report first.** One findings table with the file and passage behind every flag. Nothing changes until you approve.

![What doctor-plus checks](assets/infographic.png)

## What's included

```
doctor-plus/
├── .claude/skills/doctor-plus/SKILL.md   # the skill (the entry point)
├── assets/                               # banner + infographic
├── README.md
└── LICENSE                               # CC BY 4.0
```

## Usage examples

- `/doctor-plus`
- "run a then and now audit on this workspace"
- "context checkup - report only, don't fix anything"

## Credits

The 6 shifts come from [The new rules of context engineering for Claude 5 models](https://x.com/trq212/status/2080710971228918066) by Thariq (@trq212) at Anthropic.

Created by Jay from RoboLabs. Learn more at [RoboNuggets](https://robonuggets.com).

## License

CC BY 4.0 - free to use with attribution.
