---
name: harvest
description: Distill a finished project into evergreen Knowledge/ articles in the SecondBrain vault and log the shipped artifact in the output ledger. Use when the user says "/harvest <project>", "harvest this project", "distill what we learned from X", declares a project finished/shipped/done, or when a session ends with a clearly shipped deliverable worth recording.
argument-hint: "[project]"
---

# Harvest

Turn a **finished** project into (1) an entry in the shipped-work ledger and
(2) zero or more evergreen lesson articles in `Knowledge/`.

**Vault:** `/Users/kristinarash/SecondBrain/` (conventions: vault `CLAUDE.md`)
**Ledger:** `output/_ledger.md`
**Paths:** canonical vault locations live in `/Users/kristinarash/.claude/skills/_shared/config.json` — load it if unsure; if a literal path here ever disagrees, the config wins.

Core rule: lesson articles are written ONLY from shipped work. If the project
hasn't shipped, stop — offer to note it in `Projects/` instead.

## Process

### 1. Confirm the ship

Establish: what shipped, when, and the evidence (deliverable handed off, talk
given, pipeline live, commit/PR, decision locked). If Eric declared it shipped,
that's sufficient — record his framing. If ambiguous ("mostly done"), ask one
question; a harvest of unfinished work poisons the ledger.

### 2. Gather the project's story

Pull from whichever exist, cheapest first:

- The project folder (DEV repo, vault `Projects/` folder) — plans, READMEs, retro notes
- `memsearch search "<project> lessons decisions" --top-k 5` — session history
- The current conversation, if the project just finished here

You're looking for: what was tried and abandoned, what surprised, what the
final approach was and *why*, what broke and how it was diagnosed.

### 3. Append the ledger entry (always)

Add a row to `output/_ledger.md`, newest first:
`| YYYY-MM-DD | artifact | one-line description | [[harvest-article-slug]] or empty |`

This step always happens. Steps 4–5 only happen if lessons clear the bar.

### 4. Distill lessons (0–3 articles, only when earned)

The bar: **a lesson qualifies only if it would change how a future, unrelated
project is done.** "We built X with Y" is ledger material, not a lesson.
"Schedulers fail silently unless the task itself writes a heartbeat" is a lesson.
Zero qualifying lessons is a legitimate outcome — say so and stop after the ledger.

Each article: one idea, kebab-case filename, into `Knowledge/` (subfolder by
kind if one fits, e.g. `Knowledge/frameworks/`):

```markdown
---
type: harvest
created: YYYY-MM-DD
source: <project name + repo/folder path>
shipped: YYYY-MM-DD
domain: [one, two]
tags: [three, four]
status: evergreen
---

# <The lesson as a claim, not a topic>

> **Harvested from:** <project> (shipped <date>)
> **In one sentence:** <the lesson>

<3–10 sentences: the context that produced it, why the obvious approach
failed or the chosen one worked, and where else this applies. Write it so
it makes sense to someone who never saw the project.>
```

### 5. Cross-link

- Wikilink first mentions of concepts/people/projects that have existing notes
  (scan filenames across `Notes/`, `Knowledge/`, `Projects/`).
- Add a `## Related` section (2–5 genuinely related links).
- Backfill the ledger row's harvest column with `[[article-slug]]`.

### 6. Close out

- If the project has a vault `Projects/` file, mark its status shipped/harvested.
- Commit the vault changes (ledger + articles) with message `harvest: <project>`.
- Report in one short paragraph: ledger entry, articles written (or "no lessons
  cleared the bar"), links added.

## Rules

- **Never overwrite** an existing note; slug collision → `-2` or ask to merge.
- Never harvest unfinished work. Never write a lesson article outside a harvest
  (that's the vault's harvest rule, see vault `CLAUDE.md`).
- Lessons are what was *learned*; the ledger records what was *done*. Don't mix.
- Prefer 1 sharp article over 3 mushy ones. Zero is fine.
