---
name: library-review
description: Review a book-library domain for gaps, contested entries, and missing coverage, and propose new entries. Manual loop — proposes, you approve. Use when the user says "review my library", "/library-review <domain>", "what's missing from my <domain> advisor", or after a batch of ingestion.
argument-hint: "[domain]"
---

# Library Review

Audit one domain of the book library and propose improvements. You PROPOSE; the user
APPROVES. Never add entries silently.

**Library root:** `/Users/kristinarash/SecondBrain/Knowledge/library`
**Paths:** canonical vault locations live in `/Users/kristinarash/.claude/skills/_shared/config.json` (`vault_library`) — load it if unsure; if a literal path here ever disagrees, the config wins.

## Procedure

1. **Pick the domain** from the request (default: ask if ambiguous). Read `<domain>/_domain.md`.

2. **Scan distribution** (run in the sandbox to keep raw notes out of context). Report:
   - entry count by `kind`, by `confidence`, by `book`;
   - entries with `confidence: contested` (need a second source);
   - entries missing a "When NOT to apply" section (quality debt);
   - the "## Miss-log" — questions the advisor couldn't ground.

3. **Identify gaps** from the miss-log and from obviously thin categories.

4. **Propose 2–3 additions.** For each: the topic, which existing book chapter could
   supply it (or that a new source is needed), and the draft `kind`/`category`.
   Cite only reputable sources if proposing material beyond the ingested books, and
   mark such proposals `confidence: untested` until verified.

5. **On approval**, either: enrich existing notes (add the missing section / second
   source / convergence link), or hand the user an `ingest-book` plan for a new source.
   Re-run `memsearch index "…\library"` after any writes. Commit the vault.

## Rules
- Propose, don't auto-write. The user is the editor.
- A "gap" is something the advisor was actually asked (miss-log) or a category with
  near-zero coverage — not speculative completeness.
- Keep it cheap: this is the manual alternative to a paid scheduled agent.
