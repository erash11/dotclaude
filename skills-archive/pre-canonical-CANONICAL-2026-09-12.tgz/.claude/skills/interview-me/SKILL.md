---
name: interview-me
description: End-of-workday structured interview in two parts — a 90-second supervisor log of operational facts (equipment, people, blockers) that feeds the biweekly status report, then four reflection questions that distill the day into atomic permanent notes for the SecondBrain Obsidian vault. NOT a journaling app — produces a fact log and curated synthesis notes, not stream-of-consciousness. Use when the user types `/interview-me`, says "interview me", "let's debrief", "end of day interview", "process my day", "wrap up today", "log my day", or otherwise asks to capture their workday for their second brain or for their supervisor update. NOT FOR building the biweekly report itself (use status-report).
---

# Interview Me

End-of-workday synthesis ritual. The user is a sport-science / performance analyst who writes essays connecting sport science, product strategy, and decision-making. The interview's job is to extract publishable insights, not to record what happened.

## Vault location

`/Users/kristinarash/SecondBrain/`

**Paths:** canonical vault locations live in `/Users/kristinarash/.claude/skills/_shared/config.json` — load it if unsure; if a literal path here ever disagrees, the config wins.

- `Inbox/` — full transcripts (one per day)
- `Notes/` — atomic permanent notes (one idea per file)
- `Drafts/` — essays in progress
- `Archive/` — published
- `Templates/interview-note.md`, `Templates/permanent-note.md`
- `Inbox/status-log/` — daily supervisor fact logs (Part 0). Path key: `vault_status_log`.

---

## Part 0 — Supervisor log (90 seconds, ask first)

**Three questions, asked before the reflection questions.** Facts are easier to recall
than insight when the user is tired, and a hard 90-second opener is what makes the ritual
survivable nightly. Reflection quality does not suffer from coming second; it suffers
from the user never starting.

This part exists because `status-report` — the biweekly email to the user's supervisors —
has a sourcing gap: roughly two thirds of what belongs in that email (equipment arriving,
installs, who onboarded onto what, hallway conversations, follow-ups awaiting a reply)
appears in **no** automated source. Without a nightly log, the report has to reconstruct
two weeks from memory. With one, it mostly writes itself.

Ask all three at once. Accept short answers. Do not probe.

> Quick log first, 90 seconds. Then the usual four.
> 1. Anything arrive, get installed, or change hands today? Who's onboarding onto it?
> 2. Who did you talk to that Kenny or Chris would want to know about? Names and sport.
> 3. Waiting on anyone, or anything about to go sideways?

**Honest zero rule.** If all three are genuinely "nothing", write **no file**. A day with
no operational facts is a real day. Padding this log is worse than skipping it, because
`status-report` trusts these entries verbatim.

### Output — `{vault_status_log}/YYYY-MM-DD.md`

```markdown
---
date: YYYY-MM-DD
sports: [Football, Tennis]      # programs named in the answers; [] if none
---

## Equipment & installs
- Perch cameras installed at Foster. Football onboarding this week.

## People & conversations
- Javi (Tennis) — FirstBeat onboarding, wants a one-pager for his staff.

## Waiting on / risks
- Micah, no reply since 8/17.
```

Use the user's own words. Do not editorialize, rank, or add commentary — `status-report`
does the judgement pass later, and it needs raw facts to judge.

**Append, never overwrite.** If today's file exists (a second debrief, or a correction),
add to the existing sections rather than replacing the file.

**This log never becomes a permanent note.** It is a fact record for one downstream
consumer. Insight goes in `Notes/` via Part 1, which is why the skill's "NOT a journaling
app" rule still holds.

---

## Part 1 — The interview

**Time budget:** 10–15 minutes total including Part 0. If the user wants to keep talking, schedule a follow-up session — don't blow the budget.

**Opening line (verbatim is fine):**
> Now the four. Then I write up anything that earned its place.

### Question 1 — Orientation (filter)
> What did you spend time on today?

Listen for themes. Don't try to capture everything. Look for: a hard decision, a piece of work that consumed a lot of time, anything that felt different from yesterday.

### Question 2 — Signal (insight detection)
> What surprised you, frustrated you, or changed your mind?

This is the gold question. Genuine surprise, frustration, or updated belief = the moments worth writing down. If the answer is "nothing," probe once: *"Nothing at all? Even small recalibrations count."* If still nothing, accept and move on — not every day produces signal.

### Question 3 — Pattern (synthesis)
> Does anything from today connect to what you were thinking about earlier this week or recently?

**Optional aid:** quietly Glob `Notes/*.md` modified in the last 7 days; if you find 2–3 candidates that match today's themes, name them and ask if today's experience updates them.

### Question 4 — Essay seed (publishable insight)
> If you told a peer one thing about today's work, what would it be?

This question converts experience into transferable insight. If the user gives a great one-liner — capture it verbatim as the seed for a permanent note.

## Optional source pull-ins

Offer when the user references them. Don't pull unprompted.

- **Meeting referenced** ("today's call with X", "this morning's standup"):
  → **First, check `Inbox/meetings/` for a local summary** — Glob for files matching the date or participant. If found, read and quote from the local file (free, fast, no API call).
  → If not found locally, ask: *"Want me to pull from Fireflies?"* → invoke the `meeting-sync` skill to sync the latest meetings, then read the local file.
  → Fall back to direct `pp-fireflies` only if `meeting-sync` reports nothing matching.
- **Paper / article referenced:**
  → "Want me to pull the source from Zotero?" → use `pp-zotero-research-library` skill.
- **GPS / Catapult data referenced:**
  → "Want me to pull the underlying metric?" → use `pp-catapult-openfield-connect` skill.

Quote sources in the note's frontmatter `source:` field or the **Evidence / origin** section.

## Output protocol

### Write the supervisor log (unless all three answers were nothing)

`Inbox/status-log/YYYY-MM-DD.md` — see Part 0 for the shape. Write this **first**, before
the transcript, so a session that gets cut short still leaves the report its facts.

### Always write the transcript

`Inbox/YYYY-MM-DD-interview.md` — full Q&A, lightly cleaned. Use the `Templates/interview-note.md` skeleton. Fill in `themes`, `notes_produced`, `pulled_sources` in frontmatter.

### Write 0–3 permanent notes

**Bias toward fewer notes.** A vault full of mediocre notes is worse than one with three great ones. If nothing crossed the bar today, write zero — say so to the user. They will respect this.

A note earns its place if it meets at least one of:
- States a transferable claim (works beyond today's context)
- Updates a previously held view (in which case, also update / link the old note)
- Names a pattern across two or more recent days
- Is a clean essay seed the user could draft from later

Each note goes to `Notes/<concept-title-kebab-case>.md` with the `Templates/permanent-note.md` skeleton filled in:
- `created`: today's date
- `source`: `[[YYYY-MM-DD-interview]]`
- `domain`: pick from `sport-science`, `product`, `decision-making`, `leadership`, `methodology`, `personal`
- `tags`: free-form, but reuse existing tags from other Notes when possible
- Body: claim in 1–2 sentences, why it matters, evidence/origin, connections (use `[[wikilink]]` to related Notes), open questions

### Memory bridge (when warranted)

If the interview surfaces a **durable** fact about the user, their projects, or working style that should persist across Claude sessions:
- Also write a Tier A memory file via the `memory-write` skill (it derives the correct project slug from the current working directory) or update USER.md / project_*.md as appropriate.
- Tell the user explicitly: "Also saved this to memory as <name>."
- Do NOT bridge ephemeral notes. Most permanent notes stay in the vault only.

## What NOT to do

- **Don't pad notes with model commentary.** The user's own words and insights are the value. You are a scribe with editorial judgment, not a co-author.
- **Don't ask follow-up questions beyond the four** unless an answer was genuinely ambiguous and one clarification unlocks a much better note.
- **Don't produce a note "just to have one."** Zero notes is an honest output.
- **Don't break the 10–15 min budget.** Offer a follow-up session if needed.
- **Don't write to `Drafts/` from a daily interview.** Drafts come out of weekly synthesis, not daily capture.
- **Don't pad the supervisor log to make the day look productive.** `status-report` copies these entries into an email to the user's supervisors with light editing. An invented install or an inflated conversation becomes a false claim in front of Chris Ruf and Kenny Boyd. No file is the correct output for a quiet day.
- **Don't turn a Part 0 answer into a permanent note** unless it independently clears the Part 1 bar. Operational facts are not insight.

## Gotchas

- **Part 0 goes first, and that ordering is the whole design.** The ritual lapsed for 49 days in 2026 because reflection is expensive when tired. Three factual questions is a low enough floor to clear on a bad day, and a partial run that captures only the log still has value downstream. Moving Part 0 after the four questions quietly reverts the fix.
- **`status-report` reads this directory verbatim.** It counts logged days against the period ("N of 14 days logged") and surfaces the gap to the user. That visible gap is the intended nudge — do not backfill missing days with guesses to make the count look better.
- **Never hardcode the log path.** It is `vault_status_log` in `~/.claude/skills/_shared/config.json`. The vault has already moved once (off the iCloud-synced Desktop, 2026-08-14) and every hardcoded path broke.
- **Sports named in the answers must go in the `sports:` frontmatter array.** The status report's sport coverage panel — the reason that report exists, since it documents involvement beyond football and basketball — is assembled from this field. A conversation logged without its sport is credit the user does not get.
- **Append to today's file, never overwrite it.** A second debrief on the same day is common and overwriting silently deletes the first pass.

## Weekly synthesis

Weekly synthesis is NOT this skill's job. If the user says "weekly synthesis", "weekly review", or asks to look across the week, invoke the `weekly-review` skill — it owns the Friday ritual (themes, project status, decisions, stale action items, essay angles). This skill is strictly the daily debrief.

## End-of-session sign-off

Always end with a brief summary:
- Supervisor log: saved to `Inbox/status-log/YYYY-MM-DD.md`, or "nothing to log today"
- Transcript saved: `Inbox/YYYY-MM-DD-interview.md`
- Notes created: list with paths and one-line summaries
- Memory bridge: yes/no, what
- Any open thread to revisit tomorrow

Keep it tight — three to five lines.
