#!/usr/bin/env python3
"""meeting-sync deterministic pipeline (steps 1-5 of SKILL.md).

Pipeline: doctor auth check -> fireflies-pp-cli sync -> transcripts find
-> state-file diff -> export loop (directory-diff file detection)
-> state-file update.

stdout: a JSON array. Full run: absolute paths of newly exported .md files.
--list-only: pending (not-yet-exported) transcripts as
{"id", "title", "date"} objects, no export performed.
All diagnostics go to stderr.

Exit codes: 0 ok, 1 unexpected, 2 usage/config, 3 sync/find failure,
4 auth not configured.

Paths come from the shared config at ../../_shared/config.json
(vault_inbox_meetings, meeting_sync_state_file, meeting_lookback_days).
"""

import argparse
import json
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

CONFIG_PATH = Path(__file__).resolve().parents[2] / "_shared" / "config.json"


def log(msg: str) -> None:
    print(msg, file=sys.stderr, flush=True)


def die(code: int, msg: str) -> "None":
    log(f"ERROR: {msg}")
    sys.exit(code)


def load_config() -> dict:
    try:
        with open(CONFIG_PATH, encoding="utf-8") as f:
            cfg = json.load(f)
    except (OSError, json.JSONDecodeError) as e:
        die(2, f"cannot read shared config {CONFIG_PATH}: {e}")
    for key in ("vault_inbox_meetings", "meeting_sync_state_file"):
        if key not in cfg:
            die(2, f"shared config missing required key: {key}")
    return cfg


def resolve_cli() -> str:
    exe = shutil.which("fireflies-pp-cli")
    if not exe:
        die(2, "fireflies-pp-cli not found on PATH")
    return exe


def run_cli(exe: str, args: list, timeout: int = 300) -> subprocess.CompletedProcess:
    return subprocess.run(
        [exe] + args, capture_output=True, text=True, timeout=timeout
    )


def check_auth(exe: str) -> None:
    """Step 1: doctor. Requires JSON field "auth": "configured"
    (key comes from the FIREFLIES_API_KEY environment variable)."""
    proc = run_cli(exe, ["doctor", "--agent"])
    try:
        doc = json.loads(proc.stdout)
    except json.JSONDecodeError:
        die(4, f"doctor output was not JSON (exit {proc.returncode}): "
               f"{proc.stdout[:200]} {proc.stderr[:200]}")
    if doc.get("auth") != "configured":
        die(4, "Fireflies auth not configured. Set FIREFLIES_API_KEY in the "
               "environment (doctor reported auth="
               f"{doc.get('auth')!r}, source={doc.get('auth_source')!r}).")


def refresh_db(exe: str) -> None:
    """Step 2: pull any newly processed transcripts into the local DB."""
    proc = run_cli(exe, ["sync", "--agent"], timeout=600)
    if proc.returncode != 0:
        die(3, f"fireflies-pp-cli sync failed (exit {proc.returncode}): "
               f"{proc.stderr.strip() or proc.stdout.strip()}")


def find_transcripts(exe: str, days_back: int) -> list:
    """Step 3: list processed transcripts in the lookback window."""
    proc = run_cli(exe, [
        "transcripts", "find", "--from", str(days_back),
        "--processed-only", "--json", "--agent",
        # CLI defaults to --limit 100, which silently truncates large
        # backfills (e.g. the 235-meeting ingest); override it.
        "--limit", "100000",
    ])
    if proc.returncode != 0:
        die(3, f"transcripts find failed (exit {proc.returncode}): "
               f"{proc.stderr.strip() or proc.stdout.strip()}")
    try:
        data = json.loads(proc.stdout)
    except json.JSONDecodeError:
        die(3, f"transcripts find output was not JSON: {proc.stdout[:200]}")
    if isinstance(data, dict):
        for key in ("transcripts", "results", "items", "data"):
            if isinstance(data.get(key), list):
                data = data[key]
                break
        else:
            die(3, f"unrecognized find JSON shape: keys={list(data)[:10]}")
    if not isinstance(data, list):
        die(3, "transcripts find JSON is neither a list nor a known wrapper")
    return [t for t in data if isinstance(t, dict) and t.get("id")]


def load_state(state_path: Path) -> dict:
    """Step 4 support: load {"exports": {...}}; back up and recreate if corrupt."""
    if not state_path.exists():
        return {"exports": {}}
    try:
        with open(state_path, encoding="utf-8") as f:
            state = json.load(f)
        if not isinstance(state, dict) or not isinstance(state.get("exports"), dict):
            raise ValueError("missing exports map")
        return state
    except (OSError, ValueError, json.JSONDecodeError) as e:
        bak = state_path.with_suffix(state_path.suffix + ".bak")
        shutil.copy2(state_path, bak)
        log(f"WARNING: state file corrupted ({e}); backed up to {bak.name}, "
            "starting fresh. This run may re-export (filenames are "
            "deterministic, so the filesystem stays idempotent).")
        return {"exports": {}}


def save_state(state_path: Path, state: dict) -> None:
    tmp = state_path.with_suffix(state_path.suffix + ".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(state, f, indent=2)
    tmp.replace(state_path)


def transcript_date(t: dict) -> str:
    return str(t.get("dateString") or t.get("date") or "")


def export_new(exe: str, pending: list, vault: Path,
               state_path: Path, state: dict) -> list:
    """Step 5: export each pending transcript, detecting the written file by
    diffing the vault directory listing before/after each export (never
    "newest .md" — a no-op export must not claim an unrelated file)."""
    exported_paths = []
    for t in pending:
        tid = t["id"]
        before = {p.name for p in vault.glob("*.md")}
        proc = run_cli(exe, [
            "transcripts", "export", tid,
            "--vault", str(vault), "--agent",
        ], timeout=600)
        if proc.returncode != 0:
            log(f"WARNING: export failed for {tid} "
                f"(exit {proc.returncode}): "
                f"{proc.stderr.strip() or proc.stdout.strip()} — continuing.")
            continue
        new_files = [p for p in vault.glob("*.md") if p.name not in before]
        if not new_files:
            log(f"WARNING: export for {tid} reported success but no new file "
                "appeared in the vault; skipping state update to avoid "
                "tagging the wrong file.")
            continue
        if len(new_files) > 1:
            log(f"NOTE: export for {tid} produced {len(new_files)} new files; "
                "using the most recently written one.")
        exported = max(new_files, key=lambda p: p.stat().st_mtime)
        state["exports"][tid] = {
            "filename": exported.name,
            "exported_at": datetime.now(timezone.utc).isoformat(),
        }
        save_state(state_path, state)  # persist per-export: crash-safe
        exported_paths.append(str(exported))
        log(f"exported {tid} -> {exported.name}")
    return exported_paths


def main() -> int:
    parser = argparse.ArgumentParser(description="meeting-sync pipeline")
    parser.add_argument("--days-back", type=int, default=None,
                        help="lookback window in days (default: "
                             "meeting_lookback_days from shared config)")
    parser.add_argument("--list-only", action="store_true",
                        help="print pending (not-yet-exported) transcripts as "
                             "JSON [{id,title,date}] and exit without exporting")
    parser.add_argument("--no-sync", action="store_true",
                        help="skip the fireflies-pp-cli sync refresh (use when "
                             "a sync already ran moments ago, e.g. after "
                             "--list-only)")
    args = parser.parse_args()

    cfg = load_config()
    days_back = args.days_back or int(cfg.get("meeting_lookback_days", 14))
    vault = Path(cfg["vault_inbox_meetings"])
    state_path = Path(cfg["meeting_sync_state_file"])
    vault.mkdir(parents=True, exist_ok=True)

    exe = resolve_cli()
    check_auth(exe)
    if not args.no_sync:
        refresh_db(exe)
    transcripts = find_transcripts(exe, days_back)
    state = load_state(state_path)
    pending = [t for t in transcripts if t["id"] not in state["exports"]]
    log(f"{len(transcripts)} transcripts in last {days_back} days; "
        f"{len(pending)} not yet exported.")

    if args.list_only:
        print(json.dumps(
            [{"id": t["id"], "title": t.get("title", ""),
              "date": transcript_date(t)} for t in pending],
            indent=2))
        return 0

    exported = export_new(exe, pending, vault, state_path, state)
    print(json.dumps(exported, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
