#!/usr/bin/env python3
"""Ground-truth filename drift audit for the meeting-sync vault.

For every entry in the sync-state ledger, ask the export CLI to generate the
filename it WOULD produce today (into a throwaway scratch dir) and compare it
to the filename actually recorded. The slug algorithm is never reimplemented
here -- the CLI is the authority. That is the whole point of this script:
pattern-matching filenames for "generic-looking" names misses real drift and
invents fake drift.

Each mismatch is classified:

  cosmetic    same words, different separators/case (RTP_UpperExtremity vs
              RTP___Upper_Extremity). Churn to "fix" -- ignore.
  semantic    the Fireflies title genuinely differs in meaning. Usually two
              generations of AI naming, not rot. Needs a human call.
  regression  the vault name is GOOD and Fireflies has reverted to an
              auto-generated stamp (Jan_19_0445_PM, Untitled, Audio_Message).
              Re-exporting these DESTROYS the good name. Fix upstream instead.

Also reports filename collisions (two meetings -> one filename) and counts
inbound wikilinks to every rename candidate, because renaming a vault file
breaks links from weekly-review notes and GRAPH_REPORT.md.

stdout: a JSON object (counts + classified entries). Diagnostics to stderr.
Exit codes: 0 ok, 2 usage/config, 3 CLI/ledger failure, 4 auth not configured.
Drift is NOT an error -- check the counts in the JSON.

Paths come from the shared config at ../../_shared/config.json.
"""

import argparse
import json
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

CONFIG_PATH = Path(__file__).resolve().parents[2] / "_shared" / "config.json"

# An auto-generated Fireflies title, i.e. the thing a good curated name
# must never be replaced by. Matched against the filename minus date prefix.
GENERIC_RX = re.compile(
    r"^(?:(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)_\d{1,2}_\d{3,4}_(?:AM|PM)"
    r"|Untitled|Audio_Message|\w+gmailcom|\w+@)",
    re.IGNORECASE,
)
DATE_PREFIX_RX = re.compile(r"^\d{4}-\d{2}-\d{2}_")


def log(msg: str) -> None:
    print(msg, file=sys.stderr, flush=True)


def die(code: int, msg: str) -> None:
    log(f"ERROR: {msg}")
    sys.exit(code)


def load_config() -> dict:
    try:
        with open(CONFIG_PATH, encoding="utf-8") as f:
            cfg = json.load(f)
    except (OSError, json.JSONDecodeError) as e:
        die(2, f"cannot read shared config {CONFIG_PATH}: {e}")
    for key in ("vault_root", "vault_inbox_meetings", "meeting_sync_state_file"):
        if key not in cfg:
            die(2, f"shared config missing required key: {key}")
    return cfg


def resolve_cli() -> str:
    exe = shutil.which("fireflies-pp-cli")
    if not exe:
        die(2, "fireflies-pp-cli not found on PATH")
    return exe


def check_auth(exe: str) -> None:
    proc = subprocess.run([exe, "doctor", "--agent"], capture_output=True,
                          text=True, timeout=120)
    try:
        doc = json.loads(proc.stdout)
    except json.JSONDecodeError:
        die(4, f"doctor output was not JSON (exit {proc.returncode})")
    if doc.get("auth") != "configured":
        die(4, "Fireflies auth not configured. Set FIREFLIES_API_KEY.")


def normalize(name: str) -> str:
    """Collapse a filename to comparable letters+digits, sans date prefix."""
    stem = re.sub(r"\.md$", "", name)
    stem = DATE_PREFIX_RX.sub("", stem)
    return re.sub(r"[^a-z0-9]", "", stem.lower())


def expected_filename(exe: str, tid: str, scratch: Path) -> tuple:
    """Return (filename, error). Uses the CLI's own generator via --vault."""
    d = scratch / tid
    d.mkdir(parents=True, exist_ok=True)
    proc = subprocess.run(
        [exe, "transcripts", "export", tid, "--vault", str(d),
         "--data-source", "local", "--agent"],
        capture_output=True, text=True, timeout=120,
    )
    produced = sorted(p.name for p in d.glob("*.md"))
    if not produced:
        err = (proc.stderr or proc.stdout or "no file produced").strip()
        return None, " ".join(err.split())[:200]
    return produced[0], None


def count_inbound_links(vault_root: Path, meetings_dir: Path, stems: list) -> dict:
    """How many notes outside Inbox/meetings mention each candidate stem."""
    hits = {s: [] for s in stems}
    if not stems:
        return hits
    for md in vault_root.rglob("*.md"):
        if md.parent == meetings_dir:
            continue
        try:
            text = md.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        for s in stems:
            if s in text:
                hits[s].append(md.name)
    return hits


def main() -> int:
    ap = argparse.ArgumentParser(description="Ground-truth meeting filename drift audit.")
    ap.add_argument("--since", metavar="YYYY-MM-DD",
                    help="only audit entries whose filename date is on/after this")
    ap.add_argument("--skip-linkcheck", action="store_true",
                    help="skip the inbound-wikilink scan (faster)")
    ap.add_argument("--report", metavar="PATH",
                    help="also write a human-readable markdown report here")
    args = ap.parse_args()

    cfg = load_config()
    exe = resolve_cli()
    check_auth(exe)

    state_path = Path(cfg["meeting_sync_state_file"])
    meetings_dir = Path(cfg["vault_inbox_meetings"])
    vault_root = Path(cfg["vault_root"])

    try:
        with open(state_path, encoding="utf-8") as f:
            exports = json.load(f).get("exports", {})
    except (OSError, json.JSONDecodeError) as e:
        die(3, f"cannot read ledger {state_path}: {e}")

    items = sorted(exports.items())
    if args.since:
        items = [(i, v) for i, v in items
                 if (v.get("filename") or "")[:10] >= args.since]

    log(f"auditing {len(items)} ledger entries (ground truth via export CLI)...")

    match, cosmetic, semantic, regression, failed = 0, [], [], [], []
    produced_names = {}

    with tempfile.TemporaryDirectory(prefix="fnaudit-") as tmp:
        scratch = Path(tmp)
        for n, (tid, meta) in enumerate(items, 1):
            recorded = meta.get("filename") or ""
            got, err = expected_filename(exe, tid, scratch)
            if err:
                failed.append({"id": tid, "recorded": recorded, "error": err})
                continue
            produced_names.setdefault(got, []).append(tid)
            if got == recorded:
                match += 1
                continue
            row = {"id": tid, "recorded": recorded, "expected": got}
            if GENERIC_RX.match(DATE_PREFIX_RX.sub("", got.replace(".md", ""))):
                regression.append(row)
            elif normalize(recorded) == normalize(got):
                cosmetic.append(row)
            else:
                semantic.append(row)
            if n % 50 == 0:
                log(f"  ...{n}/{len(items)}")

    collisions = {k: v for k, v in produced_names.items() if len(v) > 1}

    candidates = [r["recorded"] for r in (cosmetic + semantic + regression)]
    stems = [re.sub(r"\.md$", "", c) for c in candidates]
    links = ({} if args.skip_linkcheck
             else count_inbound_links(vault_root, meetings_dir, stems))
    linked = {k: v for k, v in links.items() if v}

    result = {
        "audited": len(items),
        "match": match,
        "cosmetic_count": len(cosmetic),
        "semantic_count": len(semantic),
        "regression_count": len(regression),
        "failed_count": len(failed),
        "collision_count": len(collisions),
        "linked_candidate_count": len(linked),
        "regression": regression,
        "semantic": semantic,
        "cosmetic": cosmetic,
        "failed": failed,
        "collisions": collisions,
        "inbound_links": linked,
    }

    log(f"match={match} cosmetic={len(cosmetic)} semantic={len(semantic)} "
        f"regression={len(regression)} failed={len(failed)} "
        f"collisions={len(collisions)}")
    if regression:
        log("REGRESSION: vault name is better than Fireflies -- do NOT re-export "
            "these; fix the title upstream in Fireflies instead.")

    if args.report:
        lines = ["# Meeting filename audit", "",
                 "Ground truth: each filename was generated by "
                 "`fireflies-pp-cli transcripts export --vault` into a scratch "
                 "dir and compared to `.sync-state.json`. The slug algorithm is "
                 "not reimplemented.", "",
                 f"- audited: {len(items)}", f"- exact match: {match}",
                 f"- cosmetic only: {len(cosmetic)}",
                 f"- semantic drift: {len(semantic)}",
                 f"- REGRESSION: {len(regression)}",
                 f"- failed: {len(failed)}", f"- collisions: {len(collisions)}",
                 f"- candidates with inbound wikilinks: {len(linked)}", ""]
        for title, rows in (("REGRESSION - vault name is better, fix upstream", regression),
                            ("Semantic drift - needs a human call", semantic),
                            ("Cosmetic only - ignore", cosmetic)):
            lines += [f"## {title}", ""]
            for r in rows:
                lines.append(f"- `{r['recorded']}`  ->  `{r['expected']}`  ({r['id']})")
            lines.append("")
        if linked:
            lines += ["## Inbound wikilinks (renaming these breaks links)", ""]
            for k, v in sorted(linked.items()):
                lines.append(f"- `{k}` <- {', '.join(sorted(set(v)))}")
            lines.append("")
        Path(args.report).write_text("\n".join(lines), encoding="utf-8")
        log(f"report written: {args.report}")

    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
