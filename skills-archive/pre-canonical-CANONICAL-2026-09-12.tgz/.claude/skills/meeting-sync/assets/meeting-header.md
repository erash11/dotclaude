## Project tags
> Tag this meeting against active projects. Add freely. Used by weekly-review to surface drift.

- project/
- person/

## Key topics

## Decisions

## Action items
> Pulled from Fireflies. Mark complete by replacing `[ ]` with `[x]`.

## Open questions
