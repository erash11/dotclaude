---
name: meeting-sync
description: Sync new Fireflies transcripts into the SecondBrain vault; audit vault filenames for drift against Fireflies titles. Idempotent. Use when the user says "sync meetings", "pull latest meetings", "/meeting-sync", "update meeting notes", "any new meetings?", or when invoked by weekly-review. Also for filename drift — "are any meeting files misnamed?", "did a meeting get renamed after export?", "why is this meeting titled differently in Fireflies than in the vault?", "audit the meeting filenames".
argument-hint: "[days-back]"
---

# Meeting Sync

Pull new Fireflies transcripts into the SecondBrain vault. Each meeting becomes one markdown file at `Inbox/meetings/YYYY-MM-DD_<title>.md`.

## Paths — shared config

Vault and state-file paths live in `~/.claude/skills/_shared/config.json` (single source of truth):
- `vault_inbox_meetings` — export target (`/Users/kristinarash/SecondBrain/Inbox/meetings`)
- `meeting_sync_state_file` — idempotency ledger (`.sync-state.json` in that folder)
- `meeting_lookback_days` — default window (14)

`scripts/sync.py` reads these itself; don't hardcode paths elsewhere. If the vault ever moves, edit the config only.

sync.py passes `--limit 100000` to `transcripts find` — the CLI's default is 100, which silently truncates large backfills. Don't remove that flag.

## Prerequisite — one-time auth

Auth is the `FIREFLIES_API_KEY` environment variable (see the `pp-fireflies` skill's Auth Setup). Verify with `fireflies-pp-cli doctor --agent` — the JSON must show `"auth": "configured"`. `scripts/sync.py` runs this check itself and exits with code 4 if auth is missing. In that case, stop and tell the user:

> Fireflies isn't authenticated yet. Set `FIREFLIES_API_KEY` in your environment (System Properties → Environment Variables on Windows), then restart your terminal. After that, `/meeting-sync` will work.

Do not try to fix auth yourself (no `auth set-token` — the env var is the canonical mechanism). Then exit.

## Sync flow

### 1. Run the pipeline script

The deterministic pipeline (doctor check → CLI sync → find → state diff → export → state update) is fully implemented in `scripts/sync.py`. Two-phase invocation:

**Phase A — list pending, check titles:**
```bash
python scripts/sync.py --list-only [--days-back N]
```
Prints a JSON array of not-yet-exported transcripts: `[{"id", "title", "date"}]`. Diagnostics go to stderr.

**Phase B — export:**
```bash
python scripts/sync.py --no-sync [--days-back N]
```
Prints a JSON array of newly exported absolute file paths (`--no-sync` skips the redundant DB refresh Phase A just did). Exports are detected by diffing the vault directory listing before/after each export — never "most recent .md" — so a no-op export can't claim an unrelated file.

`[days-back]` argument from the user maps to `--days-back N`; otherwise the config default applies.

### 2. Between phases: generic-title judgment (model's job)

The user does not name their Fireflies meetings consistently. Generic titles produce useless filenames in the vault. Check each pending `title` from Phase A against the generic patterns documented in the `name-meetings` skill (empty, `Zoom Meeting`, `Recording`, `Meeting`, date-only, etc.).

- **0 generics:** run Phase B immediately, silently.
- **1–3 generics:** use `AskUserQuestion` once — question: "N of the new meetings have generic titles. Name them before exporting?" with options **[Propose names first / Export as-is]**. If "Propose names first", invoke the `name-meetings` skill scoped to just these IDs, then re-run Phase A to pick up renamed titles before Phase B.
- **4+ generics:** report the count and suggest: *"Several new meetings have generic titles. Run `/name-meetings` to clean them up — I'll proceed with the export either way."* Then run Phase B without blocking.

This keeps the rename loop tight at sync-time without blocking the pipeline.

### 3. Augment each exported file (model's job)

For each path in Phase B's JSON output, the file is raw Fireflies markdown. Insert the fixed 5-section header from `assets/meeting-header.md` (this skill's folder) at the top — after frontmatter, before any existing content. Read the asset and prepend it verbatim.

Leave the Fireflies-generated transcript and summary below this block intact. This gives the user **5 fixed sections to fill in or curate** during interview-me / weekly-review, on top of the raw Fireflies content.

## Drift audit (periodic, not every sync)

A vault filename is a snapshot of the Fireflies title at export time. Titles get renamed afterwards, so the two drift apart. `scripts/audit_filenames.py` detects this by asking the export CLI to regenerate every filename into a scratch dir and diffing against the ledger — **the slug algorithm is never reimplemented**, the CLI is the authority.

```bash
python scripts/audit_filenames.py [--since YYYY-MM-DD] [--skip-linkcheck] [--report PATH]
```

Run it from `weekly-review`, or on demand — **not** on every sync (it spawns one CLI call per ledger entry, ~2-4 min for a full vault). Same exit codes as sync.py; drift itself is not an error, read the counts in the JSON.

It classifies every mismatch, and the classes need different responses:

- **`regression`** — the vault name is good and Fireflies has reverted to an auto-generated stamp (`Jan_19_0445_PM`, `Untitled`, `Audio_Message`). **Never re-export these — it destroys the good name.** Fix the title upstream in Fireflies instead. Note the API refuses title updates on some older meetings; if so, say so and leave the vault alone (the ledger already protects it).
- **`semantic`** — the title genuinely differs in meaning. Usually two generations of AI naming rather than rot, so it needs a human call, not an automatic rename. Surface it, don't act.
- **`cosmetic`** — same words, different separators (`RTP_UpperExtremity` vs `RTP___Upper_Extremity`). Ignore; re-exporting is pure churn.

Before proposing any rename, check `inbound_links` in the output. Renaming a vault file breaks `[[wikilinks]]` from weekly-review notes and `GRAPH_REPORT.md`. Rewrite those links in the same pass or leave the file alone.

## Output to user

When done, report:
- N transcripts found in the window (stderr line from sync.py)
- M new exports written
- Path: `Inbox/meetings/`
- If 0 new: just say "No new meetings since last sync."

Keep it to 3 lines.

## Error handling

sync.py exit codes: 0 ok, 2 usage/config, 3 sync/find failure, 4 auth not configured.

- **Exit 4 (auth):** deliver the auth message from Prerequisite above, stop.
- **Exit 3 (sync/find):** report the stderr error verbatim, do not try to recover. The user may need to refresh their API key.
- **Export fails for one transcript:** sync.py logs a warning to stderr and continues with the rest; relay which one failed.
- **State file corrupted:** sync.py backs it up to `.sync-state.json.bak` and recreates fresh automatically (re-export is idempotent on the filesystem because filenames are deterministic per CLI); flag this in the report if the warning appears.

## What NOT to do

- **Don't re-implement steps the script owns** — doctor, CLI sync, find, state diff, export, state update all live in `scripts/sync.py`.
- **Don't identify exports by "newest .md file"** — that's the exact bug the directory-diff in sync.py fixes.
- **Don't detect filename drift by pattern-matching for "generic-looking" names** — that both misses real drift and invents fake drift. Use `audit_filenames.py`, which compares against what the export CLI actually produces.
- **Don't bulk re-export to "clean up" filenames.** Most mismatches are cosmetic or a second valid naming generation, and the `regression` class gets actively worse. Re-export only what a human approved.
- **Don't modify the Fireflies-generated content** of the exported file — only PREPEND the header from `assets/meeting-header.md`. The transcript and AI summary stay untouched.
- **Don't sync every interaction.** Run sync only when explicitly invoked OR when called by weekly-review / fireflies-intake.
