# Name Meetings — Reference

Detail split out of `SKILL.md`. Read the section you need; don't load the whole file.

## Resume mode — full loop

Pending-renames file: `pending_renames_file` in `~/.claude/skills/_shared/config.json`
(`/Users/kristinarash/SecondBrain/Inbox/meetings/.pending-renames.json`).

Two arrays:
- `pending[]` — approved renames awaiting apply (rate-limit leftovers, safe to auto-apply)
- `review[]` — proposed but never approved (written by Unattended mode); these must go through the approval flow, never auto-apply

If `pending[]` has entries:
1. Tell the user: *"Found N pending renames from a prior run that hit the rate limit. Resuming."*
2. Run `python3 ~/.claude/skills/name-meetings/scripts/rename.py --pending`. It applies every entry, verifies each by read-back, prunes the ones that verified, and re-writes the file itself.
3. Spacing is handled inside the script — do not fan these out yourself.
4. Entries that verified are already removed from `pending[]`; anything printed `FAIL` stays queued for the next run.
5. On rate-limit error: keep remaining entries, report status, exit.
6. When `pending[]` is empty: if `review[]` has entries, present them through the normal approval flow first. When both are empty — delete the file, run the step-6 re-sync, and tell the user the resume is complete.

## Generic-title patterns

A title is generic if it matches any of these (case-insensitive):

- Empty or whitespace-only
- Exactly: `Meeting`, `Call`, `Recording`, `Zoom Meeting`, `Microsoft Teams Meeting`, `Google Meet`, `Teams Meeting`, `Untitled`
- A date or timestamp and **nothing else**: `2026-05-20`, `MM/DD/YYYY`, `Meeting YYYY-MM-DD`, `Jul 29, 10:49 AM`, `Mar 02, 03:32 PM`
- The user's own email plus a timestamp: `eric.rash11@gmail.com - Tue, 28 Jul 2026 10:16:54 CDT - Untitled`
- Just a participant count: `2 people`, `3 attendees`
- Generic prefix with nothing distinctive after: `Zoom Meeting`, `Teams Meeting`, `Google Meet`, `Meeting on`, `Call with`
- Length under 5 characters

Anything else is curated. Leave it alone.

### Not generic — do not touch

**A date *prefix* followed by content is the user's own naming convention**, matching the `YYYY-MM-DD_` filenames in the vault. These are curated:

`2026-01-30_BAIR_Steering_Approval` · `2025-01-30_Marc_Lewis_Texans` · `2026-05-14_Applied_Planning` · `2025-12-19_KB_1v1` · `2026-01-09_SprintAI_Meeting`

A naive `^\d{4}-\d{2}-\d{2}` match flags all of them. On 2026-07-30 that over-matched 19 curated titles out of 23 flagged — renaming them would have violated *curated titles are sacred*. The test is whether **anything survives removing the date**: `2026-01-09_SprintAI_Meeting` → `SprintAI_Meeting` is a real title, so it's curated. `Jul 29, 10:49 AM` → nothing, so it's generic. Note the word `Meeting` inside an otherwise descriptive title does not make it generic.

## Title construction rules

Format: `<context-or-participants> — <topic>`

- Under **60 characters total**, and count it — a shared prefix eats the budget fast (`Baylor Performance Clinic — ` is 28 characters on its own)
- Em dash (`—`) between context and topic, not a hyphen
- **Context priority:**
  1. 1-on-1 (2 participants incl. user) → other person's first name (`Sarah`, or `1on1 with Sarah` if recurring)
  2. Small group (3–5) → first names joined with `&` (`Eric & John & Sarah`)
  3. Large group (6+) → a context label inferred from the topic: `Internal`, `Client — <name>`, `Team Sync`, `Standup`
- **Topic:** distill the gist to 3–6 words. Nouns and concrete action; drop filler.
- **Forbidden words:** `meeting`, `call`, `discussion`, `sync`, `conversation`, `chat`. Exception: `1on1`, `Standup`, `Team Sync` as context labels.
- **No date** — filenames already carry the `YYYY-MM-DD_` prefix.
- **Fireflies strips some punctuation.** A `/` is dropped silently: `Book — Coach/Practitioner Collaboration` came back as `Book — Coach Practitioner Collaboration`. Prefer `&` or a plain space, and report the change if it happens.

**Good:** `Sarah — Q2 Career Path` · `Eric & John — ForcePlate v2 Scope` · `Catapult Support — JWT Auth Issue` · `Client — Baylor Spring Football Reporting`

**Bad:** `Meeting with Sarah about career stuff` (drop the verb and the filler) · `2026-05-20 Sync` (date is in the filename) · `Important discussion` (no specifics → propose `[skip — gist too vague]`)

### Grouping a multi-session event

When several recordings come from one event (a clinic, a conference, a webinar series), offer a shared prefix so they sort together: `<Event> — <topic>`. Ask the user what the event was rather than guessing. Budget the prefix against the 60-char cap and trim topics — dropping speaker names is usually the right trade, since they survive in the file body and action items.

## CLI gotchas

### `sync` must be `--full` for title edits

`fireflies-pp-cli sync --agent` advances an incremental cursor and only fetches transcripts it hasn't seen. A **title edit on an already-synced transcript is invisible to it** — it exits 0 and reports `{"event":"sync_complete","resource":"transcripts","total":0}`, which reads like success.

Confirmed live 2026-07-30: nine renames applied cleanly to Fireflies; plain sync reported `total: 0` twice; `transcripts find` still returned all nine *old* titles until `sync --full --resources transcripts` pulled 187 transcripts and the new titles appeared.

A `total: 0` on transcripts is the tell that the cursor short-circuited. Always verify by re-running `transcripts find`, never by reading the exit code.

### A stale DB hides candidates

The same cursor makes step 1's `find` under-report. On 2026-07-30 the incremental DB returned 15 transcripts; a full sync returned 17, surfacing two generic-titled meetings that were never in the candidate list. This is why step 1 also uses `--full`.

### `find` truncates at 100

`transcripts find` defaults to `--limit 100`. Pass `--limit 100000` for any backfill. (`meeting-sync`'s `sync.py` already does this — don't remove that flag there either.)

### Deleted transcripts linger in the local DB

**`sync --full` does not prune transcripts deleted from the Fireflies cloud.** The local SQLite DB keeps them, so `transcripts find` lists meetings that no longer exist — ghosts. Renaming one fails with `GraphQL error: Transcript not found`, which is *literally accurate*: it really is gone.

Observed 2026-07-30. Four meetings surfaced by an all-time `find` all failed to rename; the user confirmed they had been deleted from the platform and are not on the web anymore. A `sync --full` immediately afterward pulled 187 transcripts and the four ghosts were still in `find` output.

**Reads cannot be trusted to confirm existence.** `transcripts get` returned complete data for all four under **both** `--data-source live` and `--data-source local`. A genuinely unknown ID returns `[]` under `live`, so the live path does execute — but for an ID with a local row, the read still produced data. Whether that's a silent local fallback or the API serving soft-deleted records is **unresolved**. Either way: a successful read does not prove a transcript still exists.

**The only reliable existence signal is the write itself.** `Transcript not found` from `rename.py` means gone. Treat it as permanent and report it — no UI workaround exists, because there's nothing left to rename.

**Do not infer an age rule.** The first read of this evidence was that Fireflies closes a title-edit window on old meetings (~30 days), since the four failures were 44–192 days old and 13 same-day successes were ≤20 days. That was **wrong** — age correlated only because the deleted meetings happened to be the old ones. Don't skip renames based on age.

### `transcripts update` GraphQL bug — regressed, and the old fallback is unsafe

Patched locally 2026-07-22 (upstream PR mvanhorn/printing-press-library#1571, **never merged**). The binary was rebuilt 2026-08-05, which wiped the local patch, and the bug was live again by 2026-08-29. Expect this to recur on every reinstall until the PR merges.

⚠️ **The fallback this section used to recommend — the Fireflies MCP tool — is not safe.** It returns `success: true` without reliably writing, and delayed writes can land much later and clobber a good title. See [Why renames bypass the CLI and MCP](#why-renames-bypass-the-cli-and-mcp).

Use `scripts/rename.py` instead. It does not depend on the CLI build at all, so a reinstall cannot regress it.

### Harness blocks foreground sleeps

Claude Code refuses foreground `sleep` / `Start-Sleep`. If the 30s inter-batch pause is blocked, do **not** chain shorter sleeps to work around it — apply the remaining batches sequentially, say so in the report, and rely on the 429 handling. Nine renames in one run stayed well inside the quota on 2026-07-30.

## Why renames bypass the CLI and MCP

Diagnosed 2026-08-29, after a 45-minute misdiagnosis. Both obvious paths are broken, and one of them lies about it.

**`fireflies-pp-cli transcripts update` always fails.** It passes the id as a bare field argument; the schema takes one input object:

```
CLI sends: updateMeetingTitle(id: ..., title: ...)
API wants: updateMeetingTitle(input: {id: ..., title: ...})
```

Every call returns `HTTP 400 ... Unknown argument "id" on field "Mutation.updateMeetingTitle"`. The field name really is `id` — a direct call using `meetingId` is rejected with `Field "UpdateMeetingTitleInput.id" of required type "String!" was not provided`. The *shape* is wrong, not the field name; do not "fix" it by renaming the field. There is no Fireflies manuscript on this machine (`~/printing-press/manuscripts` holds only catapult and zotero), so the CLI cannot currently be regenerated.

**The MCP tool `fireflies_update_meeting_title` returns `success: true` without reliably writing.** Its success flag carries no information. Observed in one run: 2 of 7 renames landed promptly, 5 had not landed after 8 minutes of polling, and one diagnostic write surfaced ~20–30 minutes later. **Writes are erratically delayed, not dropped** — so a rename you believe failed can still land an hour later and clobber a good title.

Two rules follow:
- Never send a throwaway "test" title through MCP. Late arrival makes the probe destructive.
- Never treat a mutation's own response as proof. Only a read-back proves a write.

**Use `scripts/rename.py`.** It calls the API directly and verifies every write by reading the title back, so it cannot report a silent failure as success. `--check <id>` reads a live title without writing.

## Rate limits and the retry ledger

Fireflies documents a hard daily rate limit — but **do not reach for it as an explanation first.** The 2026-08-29 incident looked exactly like rate limiting (writes accepted, nothing persisting) and was entirely the broken MCP path above. A real rate limit surfaces as an explicit `429` / `MCP error -32429`, not as silence.

- Apply in batches of 5–7 in parallel, 30s between batches
- On a rate-limit error (CLI GraphQL 429, or `MCP error -32429: Rate limit exceeded`) stop immediately and persist the remaining items to `pending[]` in the pending-renames file

### Transient vs permanent — classify before queuing

`pending[]` is auto-applied by Resume mode without asking. That makes it **only** safe for failures that could plausibly succeed later. Putting a permanent failure there creates a loop: every future run retries it, fails, and re-queues it.

| Class | Examples | Action |
|---|---|---|
| **Transient** | timeout, blocked call, connection reset, 5xx, `MCP error -32429` | Retry once → `pending[]` |
| **Permanent** | `Transcript not found` — the transcript was deleted from Fireflies; or a title under 5 / over 256 chars | **Never queue.** Report as gone, with the reason |
| **Transient** | `read-back mismatch` from `rename.py` — the write did not land | Retry once → `pending[]` |

Never leave a *transient* failure with only an inline mention — a "20/22 renamed" run must end with the 2 failures persisted so Resume mode retries them. But a permanent failure belongs in the report, not the ledger. On 2026-07-30 four `Transcript not found` failures were deliberately left unqueued for exactly this reason.

## Unattended mode

Only for orchestrating skills that explicitly declare unattended operation (`fireflies-intake` does). The interactive approval flow is replaced by a confidence gate:

- **Apply without approval only HIGH-confidence renames.** HIGH-confidence means all of: gist retrieved and specific, participants known, title follows the construction rules with no guessing.
- **Everything else** — vague gist, missing summary, ambiguous context, anything you'd hesitate to defend — goes to `review[]` as `{meetingId, current_title, proposed_title, reason}` for later interactive review via Resume mode. Do not apply it.
- Report both buckets: "K applied (high confidence), R queued for review in .pending-renames.json".
- Rate-limit strategy and `pending[]` persistence apply unchanged.

This is the only sanctioned exception to the approval rule.
