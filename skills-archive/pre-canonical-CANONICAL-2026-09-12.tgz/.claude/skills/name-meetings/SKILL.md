---
name: name-meetings
description: Detects Fireflies meetings with generic titles (empty, "Zoom Meeting", "Recording", date-only, etc.), proposes structured names based on AI summary + participants, and applies approved renames via the Fireflies API. Use when user says "/name-meetings", "name my meetings", "rename untitled meetings", "fix meeting titles", "my meetings have no names", or when invoked by meeting-sync.
argument-hint: "[days-back]"
---

# Name Meetings

The user does not name their Fireflies meetings. Without names, exported filenames are useless for retrieval (`2026-05-20_meeting.md`). This skill proposes structured titles from existing AI summaries and applies them via `scripts/rename.py`, which writes back to Fireflies as source-of-truth and verifies each write by read-back.

Detail lives in [REFERENCE.md](REFERENCE.md) — load the section you need, not the whole file.

## Prerequisite

Auth is the `FIREFLIES_API_KEY` env var (see `pp-fireflies` → Auth Setup; do not use `auth set-token`). Verify:

```bash
fireflies-pp-cli doctor --agent
```

If the JSON does not show `"auth": "configured"`, halt and tell the user:
> Fireflies isn't authenticated. Set `FIREFLIES_API_KEY` in your environment (System Properties → Environment Variables on Windows), then restart your terminal.

## Resume mode — check this FIRST

Before anything else, check the pending-renames file (`pending_renames_file` in `~/.claude/skills/_shared/config.json`). If `pending[]` has entries, tell the user you're resuming and apply them; if only `review[]` has entries, run them through the approval flow. Full loop: [REFERENCE.md → Resume mode](REFERENCE.md#resume-mode--full-loop).

Only proceed to the flow below if the file is absent or both arrays are empty.

## Flow

### 1. Refresh and list candidates

```bash
fireflies-pp-cli sync --full --resources transcripts --agent
fireflies-pp-cli transcripts find --from 30 --processed-only --limit 100000 --json --agent
```

`--full` is required: an incremental sync leaves the DB stale and `find` then under-reports candidates. `--limit 100000` overrides the CLI default of 100. See [REFERENCE.md → CLI gotchas](REFERENCE.md#cli-gotchas).

Default lookback is 30 days. Adjust `--from` if the user says "last 60 days" / "all meetings" (omitting it means all-time — warn that high-volume rename is slow).

### 2. Detect generics, then check they're editable

Match each title against the patterns in [REFERENCE.md → Generic-title patterns](REFERENCE.md#generic-title-patterns). Skip everything else — **don't rename what the user has already curated.** A date *prefix* followed by content (`2026-01-30_BAIR_Steering_Approval`) is curated; only date-and-time-*only* titles are generic.

**Expect ghosts.** `sync --full` doesn't prune transcripts deleted from the Fireflies cloud, so `find` can list meetings that no longer exist. They fail at step 5 with `Transcript not found` — literally true, and permanent. Reads don't detect them (`transcripts get` returns full data for a deleted transcript on both `live` and `local`), so you can't pre-filter; the write is the only reliable signal. Don't skip candidates by age — see [REFERENCE.md → Deleted transcripts](REFERENCE.md#deleted-transcripts-linger-in-the-local-db).

### 3. Propose titles

For each candidate, pull the content before proposing anything:

```bash
fireflies-pp-cli summary <id> --format gist --json --agent
```

The gist, keywords, overview, and the speaker names in `action_items` are enough to build a title. Follow [REFERENCE.md → Title construction rules](REFERENCE.md#title-construction-rules). If the gist is too vague, propose `[skip — gist too vague]` and tell the user it needs manual naming in the Fireflies UI.

If several candidates come from one event, offer a shared prefix so they group — ask what the event was rather than guessing.

### 4. Present batch for approval

Display a markdown table with columns `# | Date | Current | Proposed | Action` (`✓` to apply, `—` to skip). Then `AskUserQuestion`: "How should I apply these renames?" with **[Approve all / Edit rows / Apply subset / Cancel]**:

- **Approve all** → apply all non-skipped rows
- **Edit rows** → ask which rows and what titles, confirm the revised table, then apply
- **Apply subset** → ask which rows ("1,3,5" / "rows 1-2" / "skip 2,4"), apply only those
- **Cancel** → exit without applying

### 5. Apply approved renames

```bash
python3 ~/.claude/skills/name-meetings/scripts/rename.py <id> "<new title>"
```

**Never use `fireflies-pp-cli transcripts update`, and never use the Fireflies MCP tool `fireflies_update_meeting_title`.** Both are broken, and the MCP one lies — it returns `success: true` without reliably writing. `scripts/rename.py` calls the API directly and **verifies every write by reading the title back**, so it cannot report a silent failure as a success. Full diagnosis: [REFERENCE.md → Why renames bypass the CLI and MCP](REFERENCE.md#why-renames-bypass-the-cli-and-mcp).

The script spaces its own writes and verifies each one. Run it once per meeting, or `python3 ~/.claude/skills/name-meetings/scripts/rename.py --pending` to apply a whole approved batch and prune the ledger as each one verifies. Trust its `OK` / `FAIL` lines — never a bare success flag. On a 429, stop and persist the rest to `pending[]`.

**Classify every other failure before queuing it — the ledger is for transient errors only.**
- *Transient* (timeout, blocked call, 5xx, connection reset) → retry once, then append to `pending[]`
- *Permanent* (`Transcript not found`, or a title under 5 / over 256 characters) → **do not queue.** Resume mode auto-applies `pending[]`, so a permanent failure there retries forever and can never succeed. Report it as unrenamable, with the reason.
- A `read-back mismatch` from `rename.py` is **transient** — the write did not land. Retry once, then queue it.

Report each result inline. Mechanics and fallbacks: [REFERENCE.md → Rate limits and the retry ledger](REFERENCE.md#rate-limits-and-the-retry-ledger).

### 6. Re-sync — must be `--full`

```bash
fireflies-pp-cli sync --full --resources transcripts --agent
```

**Plain `sync --agent` fails silently here** — it skips already-seen transcripts, so title edits never land, and it still exits 0 reporting `total: 0`. **Verify by re-running the step-1 `find` and confirming the new titles**, not by reading the exit code.

If the verification `find` surfaces generics you never proposed, the earlier DB was stale — say so and offer to name them rather than ending the run silently.

**Fireflies' list endpoint lags its single-transcript endpoint by minutes.** `sync` and `find` read the list; `rename.py` verifies against the single transcript. So immediately after a rename it is normal and expected for `find` to still show the old title while the rename is genuinely applied. Do **not** re-issue the rename — that is how a good title gets clobbered. Wait ~4 minutes, re-run `sync --full`, and check again. This matters most when `meeting-sync` runs next: it builds vault filenames from the synced title, so exporting too early bakes the stale title into the filename, and a later re-export creates a *second* file rather than fixing the first.

**If the sync fails**, retry once. If it fails again the renames are NOT lost — Fireflies is source-of-truth and they already succeeded there; only the local DB is stale. Report explicitly: *"Renames applied in Fireflies, but the local DB re-sync failed — titles will look stale to meeting-sync/weekly-review until you run `fireflies-pp-cli sync --full --resources transcripts --agent`."* Never end with a silent DB/Fireflies mismatch.

### 7. Report

3–5 lines: N scanned / M generic · K applied · F queued in `.pending-renames.json` (next run auto-resumes) · S skipped for manual naming · re-sync status (OK, or the stale-DB warning).

## When invoked by `meeting-sync`

- Detect generics only in the **new-since-last-sync** subset (the IDs meeting-sync passes), not the full 30-day window
- If 0 generics: return silently
- meeting-sync has already asked the user, so go straight to proposing, then the normal approval flow

## Unattended mode

Only when an orchestrating skill explicitly declares it (`fireflies-intake` does): apply HIGH-confidence renames without approval, queue everything else to `review[]`. Rules: [REFERENCE.md → Unattended mode](REFERENCE.md#unattended-mode). This is the only sanctioned exception to the approval rule.

## What NOT to do

- **Don't rename meetings the user already titled.** Curated titles are sacred.
- **Don't propose without seeing the gist.** Without content you'll guess wrong; if `summary` fails, mark as skip.
- **Don't auto-apply without approval** — except Unattended mode, and there only HIGH-confidence.
- **Don't trust a sync's exit code.** Verify with `find`.
- **Don't include the date in the title.** Filenames already prefix dates.
- **Don't pad titles to meet length.** Concise > complete.
- **Don't rename in bulk if Fireflies rate-limits** — back off and report applied vs pending.
