#!/usr/bin/env python3
"""Apply Fireflies meeting-title renames via the GraphQL API, with read-back verification.

Why this exists (2026-08-29): the two obvious paths are both broken.

  1. `fireflies-pp-cli transcripts update` builds the mutation with the id as a bare
     field argument -- `updateMeetingTitle(id: ..., title: ...)` -- but the schema takes
     a single input object. Every call fails with HTTP 400
     `Unknown argument "id" on field "Mutation.updateMeetingTitle"`.

  2. The Fireflies MCP tool `fireflies_update_meeting_title` returns
     `{"success": true}` and then does not reliably write. Observed: 2 of 7 renames
     landed promptly, 5 had not landed after 8 minutes of polling, and one landed
     ~20-30 minutes later. Its success flag carries no information, so never use it
     for renames and never send a throwaway "test" title through it -- a late arrival
     will clobber a good title.

This script talks to the API directly and verifies every write by reading the title
back, so a silent failure can never be reported as success.

Usage:
    rename.py <meetingId> "<new title>"     rename one meeting
    rename.py --pending                     apply every entry in pending[] of the
                                            pending-renames file, removing each one
                                            that verifies
    rename.py --check <meetingId>           print the current live title, no write

Exit codes: 0 all verified · 1 one or more failed to verify · 2 usage/config error
"""
import json
import subprocess
import sys
import time
import urllib.error
import urllib.request

ENDPOINT = "https://api.fireflies.ai/graphql"
CONFIG = "/Users/kristinarash/.claude/skills/_shared/config.json"

MUTATION = (
    "mutation($input: UpdateMeetingTitleInput!){"
    " updateMeetingTitle(input: $input){ title } }"
)
QUERY_TITLE = "query($id: String!){ transcript(id: $id){ id title } }"

# Seconds to wait after a write before reading the title back. The single-transcript
# endpoint is consistent almost immediately; the *list* endpoint (what `sync` and
# `transcripts find` read) lags by minutes, which is a separate problem -- see
# "after renaming" below.
READBACK_DELAY = 3
# Spacing between writes in a --pending batch.
WRITE_SPACING = 5


def api_key():
    """Read FIREFLIES_API_KEY from the macOS Keychain (never from ~/.zshrc)."""
    user = subprocess.run(["whoami"], capture_output=True, text=True).stdout.strip()
    r = subprocess.run(
        ["security", "find-generic-password", "-s", "FIREFLIES_API_KEY", "-a", user, "-w"],
        capture_output=True, text=True,
    )
    if r.returncode != 0 or not r.stdout.strip():
        sys.exit("FIREFLIES_API_KEY not found in Keychain. See pp-fireflies -> Auth Setup.")
    return r.stdout.strip()


def gql(key, query, variables):
    req = urllib.request.Request(
        ENDPOINT,
        data=json.dumps({"query": query, "variables": variables}).encode(),
        headers={"Content-Type": "application/json", "Authorization": "Bearer " + key},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            return json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        return {"errors": [{"message": "HTTP %s: %s" % (e.code, e.read().decode()[:300])}]}


def live_title(key, meeting_id):
    r = gql(key, QUERY_TITLE, {"id": meeting_id})
    try:
        return r["data"]["transcript"]["title"]
    except (KeyError, TypeError):
        return None


def rename(key, meeting_id, title):
    """Write the title, then verify by read-back. Returns (ok, detail)."""
    resp = gql(key, MUTATION, {"input": {"id": meeting_id, "title": title}})
    if "errors" in resp:
        return False, json.dumps(resp["errors"])[:300]
    time.sleep(READBACK_DELAY)
    got = live_title(key, meeting_id)
    if got == title:
        return True, got
    return False, "read-back mismatch: got %r" % (got,)


def load_config():
    return json.loads(open(CONFIG, encoding="utf-8").read())


def do_pending(key):
    path = load_config()["pending_renames_file"]
    try:
        data = json.loads(open(path, encoding="utf-8").read())
    except FileNotFoundError:
        print("No pending-renames file at %s - nothing to do." % path)
        return 0
    items = data.get("pending", [])
    if not items:
        print("pending[] is empty - nothing to do.")
        return 0

    print("Resuming %d pending rename(s)." % len(items))
    applied = []
    for i, item in enumerate(items):
        mid = item.get("id") or item.get("meetingId")
        title = item["title"]
        ok, detail = rename(key, mid, title)
        print(("OK   " if ok else "FAIL ") + mid + " -> " + repr(detail))
        if ok:
            applied.append(mid)
        if i < len(items) - 1:
            time.sleep(WRITE_SPACING)

    data["pending"] = [
        x for x in items if (x.get("id") or x.get("meetingId")) not in applied
    ]
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2, ensure_ascii=False)

    print("applied=%d remaining=%d" % (len(applied), len(data["pending"])))
    return 0 if not data["pending"] else 1


def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    key = api_key()

    if sys.argv[1] == "--pending":
        return do_pending(key)

    if sys.argv[1] == "--check":
        if len(sys.argv) < 3:
            sys.exit("usage: rename.py --check <meetingId>")
        print(repr(live_title(key, sys.argv[2])))
        return 0

    if len(sys.argv) < 3:
        sys.exit("usage: rename.py <meetingId> \"<new title>\"")
    ok, detail = rename(key, sys.argv[1], sys.argv[2])
    print(("OK   " if ok else "FAIL ") + sys.argv[1] + " -> " + repr(detail))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
