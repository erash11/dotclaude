# Batch model routing

Apply this policy automatically when the user asks to ingest, continue, or process a Zotero library batch. The
bridge remains model-agnostic; routing belongs to the harness that orchestrates CLI and MCP calls.

## Default roles

| Stage | Codex model | Reasoning | Allowed work |
|---|---|---|---|
| Operations | `gpt-5.6-terra` | `high` | Backlog inspection, batch creation, extraction, metadata audit, Reference Stubs, reconciliation, integrity checks, tests, lint, and documentation |
| Scientific review | `gpt-5.6-sol` | `high` | Full-text methods/results/limitations review, applicability judgment, evidence-locator selection, Paper Brief writing, and final scientific approval |

Use `gpt-5.6-luna` only when the harness exposes it as an ephemeral worker and the task is strictly deterministic,
read-only status or hash validation. Otherwise use Terra. Never use Luna for Reference Stub relevance wording,
Paper Brief review, synthesis, or promotion.

## How to route (verified 2026-08-15)

Route with the Codex CLI directly. Do not go through the `codex:rescue` subagent — it runs on
Sonnet and decides for itself whether to forward, so the switch is not guaranteed.

```bash
codex exec --model gpt-5.6-terra "<operations spec>"
codex exec --model gpt-5.6-sol   "<review spec>"
codex exec --model gpt-5.6-luna  "<deterministic check spec>"
```

Add `--skip-git-repo-check` outside a git repo. Reasoning effort comes from
`~/.codex/config.toml` (`model_reasoning_effort`, currently `high`); override per call with
`-c model_reasoning_effort="xhigh"`.

All three model IDs were confirmed reachable on this machine on 2026-08-15 via the ChatGPT
subscription login. Model switching IS available here — rule 10's fallback should almost never fire.

## Automatic orchestration

1. Do not ask the user to choose a model for each stage unless they explicitly override this policy.
2. If the current task runs on Sol, keep Sol as the orchestrator/reviewer and send the operational stage to one
   Terra worker.
3. If the current task runs on Terra, keep Terra for operations and send each substantive full-text review stage
   to a Sol worker.
4. Use ephemeral `codex exec` calls, not separate user-owned threads, solely for model routing.
5. Run model-routed stages sequentially. Never allow two workers to write the same batch ledger, Promotion Record,
   or SecondBrain artifact concurrently.
6. Give each worker explicit ownership, the frozen batch ID and item keys, allowed write surfaces, stopping
   conditions, and required verification output.
7. Terra may save a Reference Stub only after the bridge confirms that Usable Full Text is unavailable. Terra must
   not save a Paper Brief.
8. Sol must inspect page-aware evidence and satisfy the Paper Brief contract before calling `save_paper_brief`.
9. Return control to Terra for reconciliation and deterministic verification after Sol finishes promotion.
10. Report the effective model route in the final checkpoint. Before claiming the harness cannot select worker
    models, actually attempt a `codex exec --model <id>` call and report the error. Only fall back to completing
    the batch on the current model if that call genuinely fails.

## Quality boundary

- Do not lower the evidence, applicability, locator, or limitation standards to save model cost.
- Escalate ambiguous citations, conflicting metadata, unclear methods, unsupported claims, or difficult
  applicability judgments to Sol even if they first appear during an operational stage.
- Use `xhigh` only for a specific difficult review that fails at `high`; do not make it the batch default.
- Preserve the user's explicit model choice when they name one for a particular task.

For non-Codex harnesses, map the same roles to that harness's balanced worker tier and flagship reasoning tier only
when explicit model routing is available. Never invent provider model IDs or claim that a switch occurred when the
harness cannot verify it.
