---
name: sports-science-research-grounding
description: Use automatically for substantive questions about sport science, return to play or sport, rehabilitation, strength and conditioning, workload, recovery, testing, athlete health, injury, performance, research-backed answers, and Zotero full-library batch processing. Searches the user's Zotero library first, clearly labels external peer-reviewed fallback sources, and applies tier-aware model routing during bounded batch work.
---

# Sports Science Research Grounding

## Purpose

Ground normal domain conversations in the user's research library without requiring a paper title or special
command. This skill is harness-neutral: use the `zotero-research` MCP server when available, or the shared
`zotero-bridge` CLI as the operational fallback.

Do not use this skill for routine coding, scheduling, or administrative questions merely because the repository
contains sport-science material.

## Evidence workflow

1. Resolve material applicability context before retrieval: sport code, sex, age or competition level, and injury
   region or type. In this user's Baylor performance context, interpret unqualified `football` as `collegiate
   American football` unless the question says soccer, association football, Australian football, or another code.
   Pass that explicit context in the question sent to the evidence-pack tool.
2. Call `build_research_evidence_pack` with the contextualized question, `limit=5`, and `extract=false`.
3. Read `required_context`, `applicability_alignment`, `coverage`, `coverage_reason`, and every paper's
   `applicability_alignment`, matches, conflicts, evidence status, citation, DOI, snippet, and page hits.
4. Prefer `page-located` evidence. If a high-value local match is `pending-extraction` and its findings matter to
   the answer, call the evidence-pack tool again with `extract=true`, or use `search_paper_evidence` and
   `get_paper_pages` after preparation.
5. If coverage is `thin` or `none`, use the current harness's native research/search capability to locate primary
   peer-reviewed literature. Label each such citation `[External]`. Never imply an external paper is in Zotero.
6. If external research is unavailable, say that the local coverage is incomplete and identify the gap.

## Answer contract

- Lead with the practical answer, then show the research basis.
- Distinguish direct study findings, cross-paper synthesis, and practitioner interpretation.
- Include population, setting, study design, outcomes, and material limitations when they affect transfer.
- Cite local evidence as `[Zotero: ITEM_KEY, p. N]` when a page is available; include DOI or full citation.
- Cite external fallback as `[External]` and link the primary source.
- Treat systematic reviews and strong designs as higher-weight evidence, not automatic truth.
- Explain genuine disagreement, thin evidence, and uncertainty instead of averaging it away.
- Never use a Graphify-inferred or ambiguous edge as primary evidence. Verify graph-proposed links against the
  original paper evidence.

## Existing memory and SecondBrain

The Zotero index is retrieval memory, not a replacement for personal or project memory. Use the harness's normal
memory system for relevant user context and prior decisions, but do not cite memory as research evidence and do
not copy the paper corpus into memory. Reviewed Paper Briefs and multi-paper syntheses belong in SecondBrain.
Only write durable memory through the user's existing memory workflow or when explicitly asked.

## Full-library processing

When asked to ingest or continue the library:

1. Read [batch-model-routing.md](references/batch-model-routing.md) and apply its automatic routing policy.
2. Call `list_library_backlog`; the queue is the priority lane, not the boundary.
3. Work in a bounded batch. Skip `ingested`, review `update_available`, extract `pending_extraction`, and create
   claims-free Reference Stubs only for `reference_stub` records.
4. Use `prepare_paper_brief`, bounded evidence searches/pages, and the repository Paper Brief contract before
   calling `save_paper_brief` or `save_reference_stub`.
5. Do not overwrite locally edited notes, mutate Zotero, or silently commit SecondBrain changes.

## CLI fallback

From `/Users/kristinarash/DEV/ZoteroInjestion`:

```powershell
uv run zotero-bridge ground "<question>" --limit 5
uv run zotero-bridge backlog --limit 50 --offset 0
```
