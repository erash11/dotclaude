#!/usr/bin/env bash
# sync-to-codex.sh -- copy the skills listed below from ~/.claude/skills into the folders Codex reads.
# Run after pulling this repo on either machine:  bash ~/.claude/skills/sync-to-codex.sh
# Add a skill name to SHARED to publish it to Codex as well as Claude Code.
set -e
SHARED=(new-project startup dev-sync closeout session-handoff humanizer articulation-skill)
SRC="$HOME/.claude/skills"
for dst in "$HOME/.agents/skills" "$HOME/.codex/skills"; do
  mkdir -p "$dst"
  for s in "${SHARED[@]}"; do
    [ -d "$SRC/$s" ] || { echo "skip $s (not in $SRC)"; continue; }
    rm -rf "$dst/$s"; cp -R "$SRC/$s" "$dst/$s"
    echo "synced $s -> $dst"
  done
done
