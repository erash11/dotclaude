---
name: memory-write
description: >
  Writes, updates, removes, and recalls facts in the two-tier memory system at
  ~/.claude/global-memory/ and ~/.claude/projects/<slug>/memory/. Use for write
  requests such as "remember this", "note that", "update memory", "save this",
  and "forget about", and for recall requests such as "did we already…?",
  "what did we decide about X?", and "do you remember…?". For writes, selects
  the correct tier and enforces deduplication and character caps. For recall,
  checks the injected snapshot first, then follows the memsearch retrieval ladder.
---

# Memory Write

## Outcome
- Fact added to, updated in, or removed from the correct memory tier
- Tier-B caps enforced (2,500 chars for MEMORY.md, 1,375 for USER.md)
- Confirmation: "Saved — will be active from next session."

## Pick the tier first

Ask: "Will this fact still be true and useful in 3 months, across multiple projects?"

**Tier A — `~/.claude/projects/<slug>/memory/`** (one file per fact, indexed by MEMORY.md)
- Durable user facts → `user_*.md` (metadata.type: user)
- Stable project conventions / gotchas → `project_*.md` (metadata.type: project)
- Behavioral feedback rules → `feedback_*.md` (metadata.type: feedback)
- External-system pointers → `reference_*.md` (metadata.type: reference)

**Tier B — `~/.claude/global-memory/`** (single capped file)
- Active threads (in-progress work) → `MEMORY.md` `## Active Threads`
- Current env notes (URLs, tool versions, project structure in play) → `MEMORY.md` `## Environment Notes`
- Pending decisions → `MEMORY.md` `## Pending Decisions`
- Durable user profile updates → `USER.md`

## Steps

1. **Decide tier** using the rule above.
2. **Read** the target file in full.
3. **Dedup check** — substring scan; if the fact already exists, skip or update in place.
4. **Cap check** for Tier B — `wc -c < ~/.claude/global-memory/MEMORY.md` (or USER.md). If over cap, consolidate (merge similar entries, prune stale) before adding.
5. **Write** the change.
   - Tier A: create a new file with proper frontmatter (name, description, metadata.type) and add a one-line pointer to that slug's `MEMORY.md` index. `name:` follows the rule below.
   - Tier B: append under the correct `##` section.
6. **Confirm** in one line: `Saved — will be active from next session.`

## The `name:` field — bare kebab slug

**`name:` = the filename stem minus its leading type token, kebab-cased.** The type
already lives in `metadata.type` and the filename already carries the prefix; repeating
it in `name:` is the third copy.

| File | `name:` |
|---|---|
| `project_automation-cadence.md` | `automation-cadence` |
| `user_sports-teams.md` | `sports-teams` |
| `reference_baylor-house-style.md` | `baylor-house-style` |
| `feedback_project_idea_capture.md` | `project-idea-capture` |

Note the last row: strip only the **leading** token. `feedback_project_idea_capture.md`
is a feedback memory *about* project-idea capture — its name keeps the word `project`.

`[[links]]` target this bare name, never the filename and never a prefixed variant.

This rule exists because it was previously unwritten: an audit on 2026-09-02 found the
corpus split 59 bare / 58 prefixed, which broke 37 links. Both forms look right in
isolation, so without a stated rule the split regrows on every write.

## Actions

- **add** — append (default)
- **replace** — substring match + swap. Preferred over add when updating an existing fact.
- **remove** — confirm with the user before deleting.

## Retrieval — the tiered ladder

When the user asks about past context, decisions, or "did we already…?", climb in order and stop as soon as the question is answered. Do not run memsearch when the answer is already in the injected snapshot.

1. **Tier 0** — scan what is already in context (USER.md, MEMORY.md, today's compiled log). Zero cost.
2. **L1** — `memsearch search "query" --top-k 5`. Hybrid vector + keyword across all indexed paths: Tier A files (including the retired Windows slugs), daily logs, transcripts.
3. **L2** — `memsearch expand <chunk_hash>`. Full markdown section around a hit.
4. **L3** — `memsearch transcript <session_id>`. Raw dialogue. Last resort.
5. **Fallback** — say "I don't have a record of that."

## Daily compiled logs — read-only

`~/.claude/claude-memory-compiler/daily/{YYYY-MM-DD}.md` is produced by `claude-memory-compiler` through its own SessionEnd/PreCompact hooks, and injected by its own SessionStart hook.

- **Never hand-edit these files.** The compiler owns them.
- **Never read them eagerly.** Treat the injected snapshot as the source of truth.

## What is loaded at session start

`~/.claude/global-memory/USER.md` and `MEMORY.md` are read once at session start and are a **frozen snapshot**. Mid-session writes persist to disk but only take effect next session — this is deliberate, to preserve the prefix cache. Never load more than the startup set proactively.

## Rules

- Never exceed Tier B caps. Consolidate first.
- Always dedup before adding.
- For Tier A, the slug is the current cwd with `/` and `.` replaced by `-` (so `~` → `-Users-kristinarash`, `~/DEV` → `-Users-kristinarash-DEV`, `~/.claude/skills` → `-Users-kristinarash--claude-skills`). The harness injects the correct slug each session — use that, don't reconstruct it.
- **Never write to a `C--Users-eric-rash*` slug.** Those are pre-migration Windows keys from the box retired 2026-08-14. They are still indexed by memsearch, so old facts stay recallable, but nothing written there will ever be auto-injected again.
- Never announce the write mid-session beyond the one-line confirmation. The injected snapshot is frozen — the new fact appears next session, not this one.
