---
name: five-slides-generator
description: "Generate a '5 Slides in 5 Minutes' PowerPoint deck for Baylor Athletics Applied Performance — research, narrative, pptxgenjs, .pptx build, QA. Use whenever the user mentions '5 slides,' '5 slides in 5 minutes,' or gives a topic they want a Performance School deck on. Also trigger for a cross-functional staff presentation, a quick sport science deck, or any short educational deck in the established series format (CMJ, GPS, VBT are prior examples)."
argument-hint: "[topic]"
---

# 5 Slides in 5 Minutes Generator

Generates polished, on-brand PowerPoint decks for Baylor Athletics' Applied Performance "5 Slides in 5 Minutes" Performance School education series. Each deck is a 5-minute cross-functional staff presentation that surfaces one topic, delivers a key insight, and sparks deeper conversation.

**Read [`references/code-template.md`](references/code-template.md) before writing any pptxgenjs code.** It contains the full structural template, design system constants, and common pitfalls.

**Read [`references/topic-library.md`](references/topic-library.md)** to understand the 40-topic library context when a topic is named.

**Read [`references/talking-points.md`](references/talking-points.md)** when generating speaker notes or when the user asks for a presenter version. Covers per-slide timing budget (~4:45 total) and talking-point structure.

**Read [`references/marp-template.md`](references/marp-template.md)** when the user asks for a "Marp version", "markdown slides", ".md version of the deck", or any version-controllable / shareable format alongside the pptx. Generates a second `.md` output mirroring the pptx narrative.

---

## The 5-Slide Narrative Structure

Every deck follows this fixed 5-slide arc, always in this order:

| Slide | Name | Purpose | Background |
|-------|------|---------|------------|
| 1 | Hook | Grab attention, frame the question | DARK |
| 2 | Problem / Context | Show the gap, the stakes, or the misunderstanding | LIGHT |
| 3 | Insight | The core scientific or practical concept | DARK |
| 4 | Application | What this looks like in practice for this audience | LIGHT |
| 5 | Takeaway | One clear point + a discussion question | DARK |

Dark/light alternation is a visual signature of the series. Never break this pattern.

---

## Full Workflow

### Step 1: Confirm the Topic

If the user gave a topic, proceed. If ambiguous, ask one clarifying question: "What's the core question you want answered in 5 minutes?"

### Step 2: Research the Content

Use WebSearch (or the firecrawl-search skill for full-page content) to gather 4-6 factual data points, statistics, or key findings on the topic. Prioritize:
- Peer-reviewed research findings
- Clinical or applied sport science data
- Practical frameworks used by elite programs

Take note of actual numbers and sources. Every stat in the deck must come from research, not fabrication.

### Step 3: Plan the Narrative

Before writing any code, draft the 5-slide narrative outline in the chat:

```
Slide 1 Hook:    [Provocative question or surprising stat]
Slide 2 Context: [The gap, problem, or misconception]
Slide 3 Insight: [The mechanism or framework]
Slide 4 Apply:   [Concrete example for the H&W team]
Slide 5 Take:    [One clear takeaway + discussion question]
```

### Step 4: Select the Color Palette

Choose a topic-appropriate 3-color palette. Never default to generic blue.

| Domain | Palette Ideas |
|--------|--------------|
| Sport Science / Technology | Navy + Cyan, Charcoal + Electric Teal |
| S&C / Power / Speed | Dark Charcoal + Orange/Amber, Forest + Gold |
| Recovery / Sleep | Deep Indigo + Soft Lavender, Dark Teal + Warm Amber |
| Mental Health / Psych | Deep Plum + Sage, Slate + Warm Rose |
| Nutrition / Fueling | Dark Forest + Fresh Green, Rich Brown + Gold |
| Load / Injury Risk | Dark Slate + Signal colors (green/yellow/red) |
| Athletic Medicine | Navy + Clinical White + Teal accent |

If the topic clearly maps to one domain row, pick that palette and proceed. If the mapping isn't obvious (topic spans domains, or the content may be institutional), ask with the **AskUserQuestion tool**: one question ("Which palette for this deck?"), offering the 2-3 most plausible domain palettes plus "Baylor brand" as options, each labeled with its colors. Put your best guess first with "(Recommended)" appended. The user can always pick Other and describe their own palette.

**Baylor brand colors** may be used as the palette when content is explicitly institutional:
- Baylor Green: `154734`
- Baylor Gold: `FFB81C`

Define three constants at the top of every script:
```javascript
const PRIMARY = "1B2A4A";   // Dark slide backgrounds + header bands
const ACCENT  = "00B4D8";   // Accent bars, highlights, key stats
const MUTED   = "94A3B8";   // Secondary text, subtitles
const WHITE   = "FFFFFF";
const LIGHT_BG = "F8FAFC";  // Light slide backgrounds
```

### Step 5: Build the Deck

Read `references/code-template.md` for the full working code template.

Install and run in a scratch build folder:
```powershell
$build = "$env:TEMP\five-slides"
New-Item -ItemType Directory -Force $build | Out-Null
# write deck.js into $build, then:
Set-Location $build
npm install pptxgenjs 2>$null | Select-Object -Last 3
node deck.js    # writes deck.pptx into $build
```

**Required on every slide:**
- Series label: `"5 SLIDES · 5 MINUTES"` top-left, small tracked text, accent color
- Topic name: top-right, matching style
- Footer: `"Baylor Athletics · Applied Performance"` left, `"Slide N of 5"` right
- Left accent bar: 0.18" wide, full height, accent color (dark slides only)

### Step 6: QA

Export each slide to PNG via PowerPoint COM (PowerPoint is installed on this machine; close any open PowerPoint windows first):

```powershell
$build = "$env:TEMP\five-slides"
Remove-Item "$build\slide*.png" -ErrorAction SilentlyContinue
$pp = New-Object -ComObject PowerPoint.Application
$deck = $pp.Presentations.Open("$build\deck.pptx", $true, $false, $false)   # read-only, no window
foreach ($slide in $deck.Slides) { $slide.Export("$build\slide$($slide.SlideIndex).png", "PNG", 1500, 844) }
$deck.Close(); $pp.Quit()
Get-ChildItem "$build\slide*.png"
```

Read each slide PNG (the Read tool renders images). Check for: text overflow, overlapping elements, low-contrast text, missing content. Fix deck.js and re-verify once. If COM export fails (PowerPoint busy/locked), skip image QA and note that in the delivery message.

### Step 7: Deliver

Copy the finished deck out of the scratch folder and hand it to the user:
```powershell
Copy-Item "$env:TEMP\five-slides\deck.pptx" "$HOME\Desktop\[Topic]_5Slides5Minutes.pptx"
```

Send the file with the SendUserFile tool (or state the Desktop path plainly). Offer speaker notes as a follow-up if the user wants them.

### Step 8: Optional Marp markdown version

If the user asked for a "Marp version", "markdown slides", or ".md version of the deck", **also** generate a Marp-format markdown file using the pattern in `references/marp-template.md`. Reuse the exact same narrative, stats, and color palette — only the output format changes.

Write to `$HOME\Desktop\[Topic]_5Slides5Minutes.md`.

Tell the user: open the file in VS Code with the Marp extension, use the command palette → `Marp: Export slide deck` → pick HTML for a single shareable file viewable in any browser.

---

## Content Standards

- Every statistic is sourced from web search, never invented
- Cross-functional framing: each slide should give S&C, AT, Nutrition, Mental Health, and Sport Science a reason to care
- Tone: practitioner-to-practitioner — confident, direct, not academic
- "Surface level by design" — the deck opens a conversation, not closes one
- The discussion question on slide 5 is as important as the content
