# 5 Slides in 5 Minutes Topic Library

40 topics across 8 categories. When a user requests a topic from this list, use the description as a starting point for content research. When a user requests a topic NOT on this list, follow the same structure and quality standards.

## Contextual Engineering & Education Delivery
1. **Post-Practice Cognitive Deficit** - Why timing matters for education delivery. After intense physical exertion, working memory and processing speed decline significantly.
2. **The 8-Second Filter** - How Gen Z processes information and what it means for content design and delivery.
3. **Notification Fatigue** - When more communication becomes less effective. The finite resource of athlete attention.
4. **The Flipped Classroom Model** - Pre-work that makes meetings better. Distribute content before sessions for richer discussion.
5. **Environmental Learning** - The locker room as a silent teacher. Passive learning through facility design and visual cues.

## Recovery & Load Management
6. **Acute:Chronic Workload Ratio** - The basics everyone should know about training load and injury risk.
7. **The Placebo Effect in Recovery** - And why that's actually okay. The psychology of recovery tools.
8. **Sleep Debt** - What it is and why weekends don't fix it. Cumulative effects on performance.
9. **Active Recovery vs. Complete Rest** - When to move and when to stop. Evidence-based recovery decisions.
10. **Cold Exposure Timing** - Why ice baths after lifting might hurt gains. Context-dependent recovery strategies.

## Cross-Functional Integration
11. **The "Whole Person" Load Model** - Training + academics + life stress. Total load on the student-athlete.
12. **Shared Language Across Silos** - Why terminology matters for cross-functional collaboration.
13. **The Transition Buffer** - 60-90 minutes between practice and learning for cognitive reset.
14. **Coordination Over Control** - What strategic alignment actually looks like in practice.
15. **Core Themes That Cross Every Unit** - Sleep, stress, and time management as universal topics.

## Mental Health & Performance Psychology
16. **Reframing Anxiety as Excitement** - Same physiology, different story. A simple cognitive reframe.
17. **Centering Cues** - One reset tool every athlete should have for competition.
18. **Mental Health First Aid** - Recognizing signs without being a therapist.
19. **Athlete Identity & Life Balance** - The risk of single-identity investment.
20. **The Supportive Conversation** - What to say (and not say) when an athlete is struggling.

## Nutrition & Fueling
21. **Nutrient Timing Basics** - Pre, during, post in plain language for every practitioner.
22. **Hydration Beyond Water** - Electrolytes and what athletes actually need.
23. **Travel Nutrition** - Eating well on the road when options are limited.
24. **The Fueling Station** - Making good choices the easy choice through environmental design.
25. **Body Composition Conversations** - How to talk about it responsibly with athletes.

## Sport Science & Technology
26. **HRV in 5 Minutes** - What it tells us and what it doesn't. Practical interpretation.
27. **GPS Load Data** - What high-speed running actually means for training decisions.
28. **Sleep Tracking** - Useful tool or anxious obsession? When data helps vs. hurts.
29. **Force Plates** - What asymmetry data can (and can't) tell you about injury risk.
30. **Data to Decision** - From dashboard to intervention. Closing the analytics loop.

## Leadership & Culture
31. **Peer-Led Education** - Why the message lands differently from a teammate.
32. **Players-Only Meetings** - How to set them up for success (and avoid the pitfalls).
33. **The Ministry of Presence** - Showing up matters more than you think across all programs.
34. **Consultant vs. Speaker** - Getting more from external experts through structured engagement.
35. **Measuring Beyond Attendance** - Kirkpatrick in 5 slides. Evaluating educational effectiveness.

## Emerging / Wildcard Topics
36. **Chronotype and Training** - Are we ignoring when athletes perform best?
37. **Gut-Brain Axis** - The basics of how digestion affects mood and performance.
38. **Breathwork Techniques** - What the research actually supports vs. what's hype.
39. **Social Media and Athlete Mental Health** - What we know so far about the connection.
40. **AI in Sport Science** - Where it's useful and where it's hype for practitioners.
