# Code Template Reference

This file contains a complete, working code template for generating a "5 Slides in 5 Minutes" deck using pptxgenjs. Use this as the structural foundation when building any new topic deck. Replace the placeholder content, colors, and topic-specific elements.

## Required Packages

```bash
npm list -g pptxgenjs react react-dom react-icons sharp 2>/dev/null
# If missing:
# npm install -g pptxgenjs react react-dom react-icons sharp
```

## Template Script

```javascript
const pptxgen = require("pptxgenjs");
const React = require("react");
const ReactDOMServer = require("react-dom/server");
const sharp = require("sharp");

// Icon helper (use when icons are needed)
async function iconToBase64Png(IconComponent, color, size = 256) {
  const svg = ReactDOMServer.renderToStaticMarkup(
    React.createElement(IconComponent, { color, size: String(size) })
  );
  const pngBuffer = await sharp(Buffer.from(svg)).png().toBuffer();
  return "image/png;base64," + pngBuffer.toString("base64");
}

// SVG chart helper (use for custom data visualizations)
async function svgToBase64Png(svgString, width, height) {
  const pngBuffer = await sharp(Buffer.from(svgString))
    .resize(width, height)
    .png()
    .toBuffer();
  return "image/png;base64," + pngBuffer.toString("base64");
}

async function buildDeck() {
  const pres = new pptxgen();
  pres.layout = "LAYOUT_16x9";
  pres.author = "Baylor Applied Performance";
  pres.title = "[TOPIC TITLE] - 5 Slides in 5 Minutes";

  // ═══════════════════════════════════════════
  // COLOR PALETTE (customize per topic)
  // ═══════════════════════════════════════════
  const PRIMARY   = "0D1B2A";   // Deep dark background
  const ACCENT    = "00B4D8";   // Vibrant accent
  const ACCENT2   = "F4A261";   // Secondary accent (optional)
  const WHITE     = "FFFFFF";
  const LIGHT_BG  = "EEF4F7";   // Light slide background
  const GRAY_TEXT = "4A5568";    // Body text on light backgrounds
  const MUTED     = "A0B8C0";   // Muted/secondary text on dark backgrounds
  const CARD_BG   = "162A3E";   // Card background (slightly lighter than PRIMARY)

  // Shadow factory (NEVER reuse shadow objects directly)
  const cardShadow = () => ({
    type: "outer", blur: 8, offset: 3, angle: 135,
    color: "000000", opacity: 0.3
  });

  // ═══════════════════════════════════════════
  // SLIDE 1: THE HOOK
  // ═══════════════════════════════════════════
  {
    const s = pres.addSlide();
    s.background = { color: PRIMARY };

    // Left accent bar
    s.addShape(pres.shapes.RECTANGLE, {
      x: 0, y: 0, w: 0.18, h: 5.625,
      fill: { color: ACCENT }, line: { color: ACCENT }
    });

    // Series label top-left
    s.addText("5 SLIDES · 5 MINUTES", {
      x: 0.38, y: 0.28, w: 9, h: 0.35,
      fontSize: 10, color: ACCENT, bold: true,
      charSpacing: 4, align: "left", margin: 0
    });

    // Topic label top-right
    s.addText("[TOPIC NAME]", {
      x: 0.38, y: 0.28, w: 9.4, h: 0.35,
      fontSize: 10, color: ACCENT, bold: true,
      charSpacing: 4, align: "right", margin: 0
    });

    // Main headline (line 1)
    s.addText("[Hook Line 1]", {
      x: 0.38, y: 1.0, w: 6.5, h: 1.0,
      fontSize: 60, color: WHITE, bold: true,
      fontFace: "Arial Black", align: "left", margin: 0
    });

    // Main headline (line 2, accent color)
    s.addText("[Hook Line 2]", {
      x: 0.38, y: 1.9, w: 6.5, h: 1.0,
      fontSize: 60, color: ACCENT, bold: true,
      fontFace: "Arial Black", align: "left", margin: 0
    });

    // Subtitle
    s.addText("[Tagline or provocative subtitle]", {
      x: 0.38, y: 3.1, w: 6.5, h: 0.5,
      fontSize: 20, fontFace: "Calibri", color: MUTED,
      italic: true, align: "left", margin: 0
    });

    // Optional: decorative element on right side
    // (circles, shapes, or abstract graphic related to topic)

    // Bottom bar
    s.addShape(pres.shapes.RECTANGLE, {
      x: 0, y: 5.1, w: 10, h: 0.525,
      fill: { color: CARD_BG, transparency: 30 },
      line: { color: CARD_BG }
    });
    s.addText("Baylor Athletics · Applied Performance", {
      x: 0.38, y: 5.1, w: 9.4, h: 0.525,
      fontSize: 11, color: MUTED, italic: true,
      align: "left", valign: "middle", margin: 0
    });
    s.addText("Slide 1 of 5", {
      x: 0.38, y: 5.1, w: 9.4, h: 0.525,
      fontSize: 11, color: MUTED,
      align: "right", valign: "middle", margin: 0
    });
  }

  // ═══════════════════════════════════════════
  // SLIDE 2: THE PROBLEM / CONTEXT
  // ═══════════════════════════════════════════
  {
    const s = pres.addSlide();
    s.background = { color: LIGHT_BG };

    // Top header band
    s.addShape(pres.shapes.RECTANGLE, {
      x: 0, y: 0, w: 10, h: 1.0,
      fill: { color: PRIMARY }, line: { color: PRIMARY }
    });
    s.addText("[SLIDE 2 TITLE]", {
      x: 0.4, y: 0, w: 9, h: 1.0,
      fontSize: 28, fontFace: "Arial Black", color: WHITE, bold: true,
      align: "left", valign: "middle", margin: 0
    });
    s.addText("2 / 5", {
      x: 0.4, y: 0, w: 9.2, h: 1.0,
      fontSize: 13, color: ACCENT,
      align: "right", valign: "middle", margin: 0
    });

    // Subtitle / framing text
    s.addText("[Brief context-setting statement]", {
      x: 0.4, y: 1.15, w: 9.2, h: 0.42,
      fontSize: 13, fontFace: "Calibri", color: GRAY_TEXT,
      italic: true, margin: 0
    });

    // Content area: Use stat callouts, cards, or split layouts
    // Example: Three stat cards
    const stats = [
      { number: "XX%", label: "[Stat description]", color: ACCENT },
      { number: "X.Xx", label: "[Stat description]", color: ACCENT2 },
      { number: "XX", label: "[Stat description]", color: ACCENT }
    ];

    stats.forEach((st, i) => {
      const x = 0.4 + i * 3.1;
      s.addShape(pres.shapes.RECTANGLE, {
        x, y: 1.8, w: 2.9, h: 2.6,
        fill: { color: WHITE },
        line: { color: "E0E0E0", width: 0.75 },
        shadow: cardShadow()
      });
      // Top accent bar on card
      s.addShape(pres.shapes.RECTANGLE, {
        x, y: 1.8, w: 2.9, h: 0.06,
        fill: { color: st.color }, line: { color: st.color }
      });
      // Big number
      s.addText(st.number, {
        x: x + 0.15, y: 2.0, w: 2.6, h: 1.2,
        fontSize: 42, fontFace: "Arial Black", color: st.color, bold: true,
        align: "center", valign: "middle", margin: 0
      });
      // Label
      s.addText(st.label, {
        x: x + 0.15, y: 3.2, w: 2.6, h: 1.0,
        fontSize: 12, fontFace: "Calibri", color: GRAY_TEXT,
        align: "center", valign: "top", margin: 0
      });
    });

    // Bottom context note
    s.addText("[Source or contextualizing note]", {
      x: 0.4, y: 4.8, w: 9.2, h: 0.4,
      fontSize: 10, fontFace: "Calibri", color: "888888",
      italic: true, margin: 0
    });
  }

  // ═══════════════════════════════════════════
  // SLIDE 3: THE INSIGHT
  // ═══════════════════════════════════════════
  {
    const s = pres.addSlide();
    s.background = { color: PRIMARY };

    // Top header band in accent color
    s.addShape(pres.shapes.RECTANGLE, {
      x: 0, y: 0, w: 10, h: 0.9,
      fill: { color: ACCENT }, line: { color: ACCENT }
    });
    s.addText("[SLIDE 3 TITLE: THE BIG IDEA]", {
      x: 0.4, y: 0, w: 9, h: 0.9,
      fontSize: 28, fontFace: "Arial Black", color: WHITE, bold: true,
      align: "left", valign: "middle", margin: 0
    });
    s.addText("3 / 5", {
      x: 0.4, y: 0, w: 9.2, h: 0.9,
      fontSize: 13, color: PRIMARY,
      align: "right", valign: "middle", margin: 0
    });

    // Framing text
    s.addText("[One sentence that frames the core insight]", {
      x: 0.4, y: 0.98, w: 9.2, h: 0.42,
      fontSize: 13, fontFace: "Calibri", color: MUTED,
      italic: true, margin: 0
    });

    // Content: Cards, framework visualization, or comparison layout
    // This is the most visually complex slide. Use the topic to drive layout.
    // Options: 3-column cards, 2-column comparison, visual model/diagram

    // Example: Three concept cards with colored accents
    const concepts = [
      { title: "[Concept 1]", desc: "[Description]", color: ACCENT, bg: "162A3E" },
      { title: "[Concept 2]", desc: "[Description]", color: ACCENT2, bg: "2A1F0D" },
      { title: "[Concept 3]", desc: "[Description]", color: "2DC653", bg: "0D2A1A" }
    ];

    concepts.forEach((c, i) => {
      const x = 0.35 + i * 3.1;
      s.addShape(pres.shapes.RECTANGLE, {
        x, y: 1.55, w: 2.9, h: 3.8,
        fill: { color: c.bg }, line: { color: c.color, width: 1.5 }
      });
      // Top color accent strip
      s.addShape(pres.shapes.RECTANGLE, {
        x, y: 1.55, w: 2.9, h: 0.08,
        fill: { color: c.color }, line: { color: c.color }
      });
      s.addText(c.title, {
        x: x + 0.15, y: 1.72, w: 2.6, h: 0.55,
        fontSize: 16, fontFace: "Calibri", color: c.color, bold: true,
        margin: 0
      });
      // Divider
      s.addShape(pres.shapes.LINE, {
        x: x + 0.15, y: 2.4, w: 2.6, h: 0,
        line: { color: c.color, width: 0.75, transparency: 50 }
      });
      s.addText(c.desc, {
        x: x + 0.15, y: 2.5, w: 2.65, h: 2.5,
        fontSize: 11.5, fontFace: "Calibri", color: MUTED, margin: 0
      });
    });
  }

  // ═══════════════════════════════════════════
  // SLIDE 4: THE APPLICATION
  // ═══════════════════════════════════════════
  {
    const s = pres.addSlide();
    s.background = { color: LIGHT_BG };

    // Top header band
    s.addShape(pres.shapes.RECTANGLE, {
      x: 0, y: 0, w: 10, h: 1.0,
      fill: { color: PRIMARY }, line: { color: PRIMARY }
    });
    s.addText("[SLIDE 4 TITLE: PRACTICAL APPLICATION]", {
      x: 0.4, y: 0, w: 9, h: 1.0,
      fontSize: 28, fontFace: "Arial Black", color: WHITE, bold: true,
      align: "left", valign: "middle", margin: 0
    });
    s.addText("4 / 5", {
      x: 0.4, y: 0, w: 9.2, h: 1.0,
      fontSize: 13, color: ACCENT,
      align: "right", valign: "middle", margin: 0
    });

    // Content: Scenario-based, practical examples
    // Options: Two-column before/after, workflow steps, decision matrix

    // Example: Two scenario cards side by side
    s.addText("[Framing: How this shows up in your day-to-day work]", {
      x: 0.4, y: 1.15, w: 9.2, h: 0.42,
      fontSize: 13, fontFace: "Calibri", color: GRAY_TEXT,
      italic: true, margin: 0
    });

    // Left card
    s.addShape(pres.shapes.RECTANGLE, {
      x: 0.4, y: 1.75, w: 4.3, h: 3.2,
      fill: { color: WHITE },
      line: { color: "E0E0E0", width: 0.75 },
      shadow: cardShadow()
    });
    s.addShape(pres.shapes.RECTANGLE, {
      x: 0.4, y: 1.75, w: 0.06, h: 3.2,
      fill: { color: ACCENT }, line: { color: ACCENT }
    });
    s.addText("[Scenario 1 Title]", {
      x: 0.65, y: 1.85, w: 3.9, h: 0.45,
      fontSize: 16, fontFace: "Calibri", color: ACCENT, bold: true,
      margin: 0
    });
    s.addText("[Scenario 1 description and practical example]", {
      x: 0.65, y: 2.35, w: 3.9, h: 2.4,
      fontSize: 12, fontFace: "Calibri", color: GRAY_TEXT, margin: 0
    });

    // Right card
    s.addShape(pres.shapes.RECTANGLE, {
      x: 5.3, y: 1.75, w: 4.3, h: 3.2,
      fill: { color: WHITE },
      line: { color: "E0E0E0", width: 0.75 },
      shadow: cardShadow()
    });
    s.addShape(pres.shapes.RECTANGLE, {
      x: 5.3, y: 1.75, w: 0.06, h: 3.2,
      fill: { color: ACCENT2 }, line: { color: ACCENT2 }
    });
    s.addText("[Scenario 2 Title]", {
      x: 5.55, y: 1.85, w: 3.9, h: 0.45,
      fontSize: 16, fontFace: "Calibri", color: ACCENT2, bold: true,
      margin: 0
    });
    s.addText("[Scenario 2 description and practical example]", {
      x: 5.55, y: 2.35, w: 3.9, h: 2.4,
      fontSize: 12, fontFace: "Calibri", color: GRAY_TEXT, margin: 0
    });
  }

  // ═══════════════════════════════════════════
  // SLIDE 5: THE TAKEAWAY
  // ═══════════════════════════════════════════
  {
    const s = pres.addSlide();
    s.background = { color: PRIMARY };

    // Top header band in accent
    s.addShape(pres.shapes.RECTANGLE, {
      x: 0, y: 0, w: 10, h: 0.9,
      fill: { color: ACCENT }, line: { color: ACCENT }
    });
    s.addText("[SLIDE 5 TITLE: THE TAKEAWAY]", {
      x: 0.4, y: 0, w: 9, h: 0.9,
      fontSize: 28, fontFace: "Arial Black", color: WHITE, bold: true,
      align: "left", valign: "middle", margin: 0
    });
    s.addText("5 / 5", {
      x: 0.4, y: 0, w: 9.2, h: 0.9,
      fontSize: 13, color: PRIMARY,
      align: "right", valign: "middle", margin: 0
    });

    // Main takeaway (prominent)
    s.addText("[ONE CLEAR ACTIONABLE TAKEAWAY]", {
      x: 0.5, y: 1.2, w: 9, h: 1.2,
      fontSize: 24, fontFace: "Calibri", color: WHITE, bold: true,
      align: "center", valign: "middle", margin: 0
    });

    // Supporting context
    s.addText("[Brief supporting statement or context for the takeaway]", {
      x: 1.0, y: 2.5, w: 8, h: 0.8,
      fontSize: 14, fontFace: "Calibri", color: MUTED,
      align: "center", margin: 0
    });

    // Discussion prompt
    s.addShape(pres.shapes.RECTANGLE, {
      x: 1.5, y: 3.6, w: 7, h: 0.9,
      fill: { color: ACCENT, transparency: 80 },
      line: { color: ACCENT, width: 1 }
    });
    s.addText("[Discussion question that invites deeper conversation]", {
      x: 1.7, y: 3.65, w: 6.6, h: 0.8,
      fontSize: 14, fontFace: "Calibri", color: WHITE, italic: true,
      align: "center", valign: "middle", margin: 0
    });

    // Closing quote
    s.addText("[Memorable closing line or quote]", {
      x: 1.0, y: 4.6, w: 8, h: 0.5,
      fontSize: 16, fontFace: "Calibri", color: ACCENT, bold: true,
      align: "center", margin: 0
    });
  }

  // Write file
  await pres.writeFile({ fileName: "deck.pptx" });  // lands in the scratch build folder (cwd); renamed to [Topic]_5Slides5Minutes.pptx at delivery
  console.log("Deck created successfully");
}

buildDeck().catch(console.error);
```

## Notes on Customization

**Varying slide layouts:** The template above shows the default pattern. For each new topic, you should vary the content layouts on slides 2-4 based on what the content demands:

- **Stat-heavy topics:** Use large number callouts with supporting context
- **Framework/model topics:** Use visual diagrams, flow charts, or hierarchical cards
- **Comparison topics:** Use side-by-side columns or before/after layouts
- **Process topics:** Use numbered steps or timeline layouts
- **Category topics:** Use color-coded cards or grouped elements

**Icons:** Import from react-icons when a visual icon would strengthen the slide:
```javascript
const { FaBrain, FaHeartbeat } = require("react-icons/fa");
const iconData = await iconToBase64Png(FaBrain, "#00B4D8", 256);
slide.addImage({ data: iconData, x: 1, y: 1, w: 0.5, h: 0.5 });
```

**SVG Charts:** For data visualizations, generate SVG strings and convert:
```javascript
const chartSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 400">
  <!-- chart elements -->
</svg>`;
const chartImg = await svgToBase64Png(chartSvg, 800, 400);
slide.addImage({ data: chartImg, x: 1, y: 1, w: 8, h: 4 });
```
