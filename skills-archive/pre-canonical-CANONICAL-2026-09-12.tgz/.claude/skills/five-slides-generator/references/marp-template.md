# Marp Template

Optional second output format alongside the `.pptx`. Marp turns markdown into slides — viewable live in VS Code Marp extension, exportable to HTML / PDF / PPTX from the command palette.

## When to generate this

The user asked for a "Marp version", "markdown slides", ".md version of the deck", or wants something they can version-control / share via GitHub. Always generate alongside the `.pptx`, never instead of it.

## File pattern

Write to `$HOME\Desktop\[Topic]_5Slides5Minutes.md` using the structure below. Reuse the **exact same** narrative, stats, and color palette chosen for the pptx — only the output format changes.

## Template

```markdown
---
marp: true
theme: default
paginate: true
size: 16:9
style: |
  section {
    font-family: 'Inter', 'Segoe UI', sans-serif;
    padding: 60px 80px;
  }
  section.dark {
    background: #1B2A4A;
    color: white;
    border-left: 12px solid #00B4D8;
  }
  section.light {
    background: #F8FAFC;
    color: #1B2A4A;
  }
  section header {
    font-size: 14px;
    letter-spacing: 3px;
    color: #00B4D8;
    text-transform: uppercase;
  }
  section footer {
    font-size: 12px;
    color: #94A3B8;
  }
  h1 { font-size: 56px; margin-bottom: 24px; }
  h2 { font-size: 36px; color: #00B4D8; }
  .stat { font-size: 72px; font-weight: 700; color: #00B4D8; }
  .question { font-size: 32px; font-style: italic; opacity: 0.85; }
header: '5 SLIDES · 5 MINUTES   |   [TOPIC NAME]'
footer: 'Baylor Athletics · Applied Performance'
---

<!-- _class: dark -->
<!-- _paginate: false -->

# [Hook headline]

<p class="question">[Provocative question or surprising stat]</p>

---

<!-- _class: light -->

## The Problem

[Show the gap, the stakes, or the misunderstanding. 2-4 bullet points or a single bold paragraph.]

- [Pain point 1]
- [Pain point 2]
- [Pain point 3]

---

<!-- _class: dark -->

## The Insight

[The core scientific or practical concept. One idea, clearly explained.]

<p class="stat">[Key number]</p>

[Supporting context for the number — what it means, where it came from.]

---

<!-- _class: light -->

## Application

[What this looks like in practice for the H&W team.]

| Specialty | What it means |
|-----------|---------------|
| S&C | [...] |
| AT | [...] |
| Nutrition | [...] |
| Mental Health | [...] |
| Sport Science | [...] |

---

<!-- _class: dark -->

## Takeaway

**[One clear sentence — the action item.]**

<p class="question">[Discussion question for the room]</p>
```

## Color palette substitution

Swap `#1B2A4A` (PRIMARY), `#00B4D8` (ACCENT), and `#94A3B8` (MUTED) in the `style:` block for whatever palette you chose for the pptx version. The constants in `code-template.md` map 1:1 to the CSS variables here.

## Topic / palette consistency

The `header:` line at the top should contain the exact topic name shown in the pptx. The CSS palette should match the pptx palette exactly so the two deliverables feel like the same deck.

## How the user views it

Tell them:
- **VS Code preview**: open the `.md` file → live preview in side panel via the Marp extension
- **Export to HTML**: command palette → `Marp: Export slide deck` → pick HTML → produces a single self-contained `.html` file viewable in any browser, shareable via email or hosting
- **Export to PDF/PPTX**: same menu, different format. The exported PPTX is lower-fidelity than the pptxgenjs version — use pptxgenjs as the canonical deliverable.

## Rules

- Always generate alongside the pptx, never as a replacement
- Same narrative, same stats, same colors — only the format changes
- Don't add Marp-specific bells and whistles (transitions, fragments) — keep the markdown plain so it stays readable as a `.md` file even outside Marp
- One H1 per deck (slide 1); H2 for the other four slides — keeps the outline view clean in VS Code
