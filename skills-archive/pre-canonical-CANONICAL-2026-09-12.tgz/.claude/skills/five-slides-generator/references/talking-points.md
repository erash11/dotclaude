# Talking Points & Timing Reference

Use alongside `code-template.md` (visual structure) and `topic-library.md` (topic context). This file covers what gets *said* on each slide and how long it takes.

## Timing Budget

Total: ~4:45 of spoken delivery. The slides are surface-level by design — the timing forces it.

| Slide | Beat | Spoken time |
|-------|------|-------------|
| 1 | Hook | ~45 sec |
| 2 | Problem / Context | ~60 sec |
| 3 | Insight | ~75 sec |
| 4 | Application | ~60 sec |
| 5 | Takeaway | ~45 sec |

If the user asks for speaker notes, target these durations — not word counts.

## Talking-Point Structure (per slide)

Each slide has two parts:

- **Slide content** — what's printed on screen (already covered by visual template)
- **Talking points** — what the presenter says over it

The talking points are *not* a script. They're bullet-form anchors the presenter expands on. 2-4 bullets per slide is the sweet spot.

### Slide 1 — Hook
- Opening framing
- "Why does this matter to everyone in the room?" — cross-functional framing from the first sentence

### Slide 2 — Problem / Context
- Name the gap or misconception
- Make it relatable across specialties (S&C, AT, Nutrition, Mental Health, Sport Science all hear something)

### Slide 3 — Insight
- The big idea — one concept, clearly explained
- "This is the slide they remember." Don't dilute it with a second concept.

### Slide 4 — Application
- Connect to daily practice — "what this looks like on Monday"
- Touch each specialty: how does S&C use this? How does AT? Nutrition? etc.

### Slide 5 — Takeaway
- One action item
- One discussion prompt — the conversation continues after the deck closes

## Follow-Up Hook

Every deck should end with a one-line "Follow-Up Potential" the presenter can mention:
> "Could this become a full Performance School session?"

This positions the 5-minute deck as the trailhead, not the destination.

## Generation rule

When the user asks for speaker notes or a presenter version of a deck, default to this structure. When they ask for just the deck, omit talking points — they're a separate deliverable.
