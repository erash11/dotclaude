# sync-to-codex.ps1 -- Windows twin of sync-to-codex.sh. Copies shared skills from ~/.claude/skills into the folders Codex reads.
# Run after pulling this repo:  powershell -ExecutionPolicy Bypass -File $HOME\.claude\skills\sync-to-codex.ps1
$shared = @('new-project','startup','dev-sync','closeout','session-handoff','humanizer','articulation-skill')
$src = "$env:USERPROFILE\.claude\skills"
foreach ($dst in @("$env:USERPROFILE\.agents\skills", "$env:USERPROFILE\.codex\skills")) {
  New-Item -ItemType Directory -Force $dst | Out-Null
  foreach ($s in $shared) {
    if (-not (Test-Path "$src\$s")) { "skip $s (not in $src)"; continue }
    if (Test-Path "$dst\$s") { Remove-Item "$dst\$s" -Recurse -Force }
    Copy-Item "$src\$s" "$dst\$s" -Recurse
    "synced $s -> $dst"
  }
}
