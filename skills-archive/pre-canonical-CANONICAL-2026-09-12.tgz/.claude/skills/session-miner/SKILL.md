---
name: session-miner
description: Mine recent Claude Code sessions for learnings that never got captured — repeated corrections, decisions with rationale, gotchas, and workflows worth turning into skills — and route each to memory, the vault, or a skill edit. Use when the user says "/session-miner", "what did we miss", "review recent sessions", "mine my history", or "anything from this week worth keeping?".
---

# Session Miner

Pull uncaptured learnings out of recent session history. Data-gathering skill: it reads history and proposes destinations; the user picks.

## Step 0 — read the pending ledger first

`~/.claude/claude-memory-compiler/reports/proposals-pending.md`

Do this **before** mining. Apply anything marked `approved` (then mark it `applied`), and
re-list every `open` item alongside this run's findings. Append new findings as `open`,
deduplicating against what is already listed. Without it, a proposal made in a session
that ends is lost and the next run pays to rediscover it.

## Sources, in order

1. `~/.claude/global-memory/transcripts/*.md` (last 7 days)
2. `~/.claude/claude-memory-compiler/daily/*.md` (last 7 days)
3. **Raw session records** — `~/.claude/projects/<slug>/*.jsonl`. See below.
4. `memsearch search "<topic>" --top-k 5` for targeted digs

Sources 1 and 2 are already-filtered summaries: a flush decided what mattered before
you ever saw it. Anything the filter dropped is only in source 3. Reach for it when a
run of sources 1–2 comes back thin, or when the user asks about something older than
the 7-day window.

For anything beyond a quick scan, spawn a subagent to do the trawling and return only findings — raw transcript text should not fill the main conversation.

## Mining the raw `.jsonl` records

Several hundred files and a few hundred MB sit in `~/.claude/projects/` (424 files,
337 MB on 2026-09-02, and growing). Feeding that to an LLM is how the compiler's
9.5M-token incident happened, so this source is **capped, not open-ended**.

**Do not write a new parser.** Two extractors already exist:
- `memsearch transcript <path>` — renders one session's turns; auto-detects the format.
- `extract_conversation_context()` in
  `~/.claude/claude-memory-compiler/hooks/session-end.py` — keeps only `user` and
  `assistant` roles, which is what drops the tool-result bulk.

**Caps for one run** — state which you used in the report:
- window: 14 days unless the user names a wider one
- at most 20 sessions, newest first
- at most ~200 KB of extracted text per session; truncate the middle, keep both ends
- strip `tool_result` blocks before any of it reaches a model

Always trawl in a subagent and return findings only.

**Handling care.** Raw records can quote `PERFORMANCE.md` → `DexaProject/` identifiable
health data. Reading it locally in a subagent is fine; nothing carrying it may be written
out to the vault, a memory file, or this skill's report. Cite the session id and date as
evidence instead of quoting the passage.

## What to hunt for

- **Repeated corrections** → feedback memory or a skill fix
- **Decisions with rationale** → permanent vault note
- **Discovered gotchas** → project memory
- **Workflows that worked** → skill candidate

## Output

Present findings as a checklist: each item = the learning + where it should live (memory tier, vault note, skill edit, new skill). User picks; route each approved item to its destination — use memory-write conventions for memories, capture-insight format for vault notes, write-a-skill for skill changes.

## Rules

- Report before you mutate. Nothing is written until the user approves the checklist items.
- Cite evidence (date, file) for each finding so the user can judge it.
- An empty result is legitimate — don't manufacture learnings to look thorough.
