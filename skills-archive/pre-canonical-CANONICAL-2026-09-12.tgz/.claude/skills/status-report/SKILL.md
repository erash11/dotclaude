---
name: status-report
description: Build the every-two-weeks Applied Performance status report for Kenny Boyd and Chris Ruf — paste-ready email, one-page PDF, internal record. Use when the user says "/status-report", "build my status report", "time for the Chris report", "biweekly update", "status update for Chris and Kenny", "what do I send Chris this week", or when a scheduled report date arrives.
---

# Status Report

Produce the recurring Applied Performance status report — an email to **Kenny Boyd and
Chris Ruf**, both addressed directly ("Kenny, Coach Ruf,"), every two weeks, ~270 words.

Governed by **KR 4.1** in `Applied-Performance-OKRs-2026-27.md` (v3). Read that KR as a
**content checklist** — shipped work, work in flight, decisions needed, anything at risk,
what's next — not as a layout. Eric's real reports run as flat prose with no section
headers. See **Voice** below; match it.

**Primary job: alignment.** Chris and Kenny finish the email knowing what moved, what
needs them, and what's at risk. **Secondary job: credit** — visible involvement across
sports beyond football and basketball. That secondary job is why the report was asked
for; do not let it slip out of the output.

**Design target: under 5 minutes of the user's time.** The machine does the recall. The
interview spends the user's attention only on what no system can know.

## Paths

Read `~/.claude/skills/_shared/config.json` for all paths — never hardcode. Keys used
here: `vault_root`, `vault_inbox_meetings`, `vault_output_ledger`,
`vault_status_reports`, `vault_status_log`, `portfolio_json`, `okr_doc`, `okr_scoreboard`,
`okr_tracker_dir`, `utilization_brief`, `canonical_projects`, `fireflies_cli`.

Template: `{vault_root}/Templates/status-report.md`
Output dir: `{vault_status_reports}`

> The config held Windows paths from the pre-migration machine until 2026-08-11. If any
> value starts with `C:\`, stop and fix the config first — every skill that trusts it is
> broken until you do.

## Relationship to other skills

- **`weekly-review` is not a prerequisite.** Never require it to have run. If review
  files exist in `Inbox/weekly-review/` for the period, read them as a bonus input; if
  they don't, proceed without comment. The report builds from primary sources so it
  cannot inherit another ritual's failure rate.
- **`meeting-sync`** may be invoked to freshen the meeting corpus, but a sync failure is
  **not** a hard stop here — fall back to `fireflies-pp-cli digest` live, and note in the
  internal record that the vault copy was stale.
- **`html-to-pdf`** renders the one-pager.

---

## Step 1 — Establish the period

Read the newest file in `{vault_status_reports}`. Period start = the previous report's
`period_end`; period end = today. If no prior report exists, period start = 14 days ago.

**Count sends.** KR 4.1's target is "≥3 **sent** by Aug 31," and writing a file is not
sending it. Count files in `{vault_status_reports}` with `sent: true` in frontmatter —
that is the real number. Report progress toward ≥3 in Step 8. If files exist with
`sent: false` older than a week, ask whether they actually went out; an uncounted send
is as bad for the KR as a missed one.

A missed send widens the period rather than skipping it. Never leave a gap in the
archive — the archive's continuity is what makes it usable as a time record.

**Cadence is settled: every two weeks.** Eric committed to it in writing in the first
report — "Starting these updates every two weeks." Report 1 went out **2026-08-24**, so
sends land on even fortnights from there (2026-09-07, 09-21, 10-05, …). The earlier
"twice monthly, 1st and 3rd Friday" plan was an assistant assumption and is retired.

## Step 2 — Pull (no user involvement)

### Step 2a — Preflight the meeting source

Run `{fireflies_cli} transcripts list --agent --data-source live 2>&1 | head -5` first.

**Fixed 2026-08-11** — the key is in `~/.zshrc` and the local mirror was rebuilt with
`fireflies-pp-cli sync`; as of 2026-08-13 the key is visible to the Bash tool directly.
The DB lives at `~/.local/share/fireflies-pp-cli/data.db`, not `~/.fireflies-pp-cli/`.

If it fails again, `unable to open database file: out of memory (14)` means the mirror is
**missing, not corrupt** — run `sync` before anything else. Then:

- **Do not hard-stop.** `meeting-sync` hard-stops on auth failure; this skill must not,
  or it inherits the outage that already lapsed `weekly-review`.
- **Fall back** to reading `{vault_inbox_meetings}/*.md` filtered to the period by the
  `YYYY-MM-DD_` filename prefix. These files have **no YAML frontmatter** — parse the
  prepended header block (`## Key topics`, `## Decisions`, `## Action items`) and the
  Fireflies export sections (`## Summary`, `### Overview`, `### Action Items`).
- **Check staleness and say so.** Compare the newest meeting file's date to today. If
  the gap is >2 days, tell the user plainly in Step 8: *"Meeting data is stale through
  {DATE}; anything after that came only from the interview."* A silently incomplete
  report is worse than a flagged one — the user is about to send it to a supervisor.
- Record the degraded source in the internal record's frontmatter.

### Step 2b — Pull

Run these in parallel. Never ask the user for anything obtainable here.

1. **Meetings** — `{fireflies_cli} digest --since <N>d --processed-only --agent`
   (flags verified valid; `--since` accepts `7d`/`24h` form). Gives titles, gists,
   topics, and action items in one call. Cross-check against `{vault_inbox_meetings}`.
   On failure, use the 2a fallback.
1b. **Supervisor logs — read these before anything else.** Every file in
   `{vault_status_log}` whose `YYYY-MM-DD.md` filename falls inside the period. These are
   written nightly by `interview-me` Part 0 and they are the **highest-value source in
   this step**: they cover equipment, installs, hallway conversations, and follow-ups
   awaiting a reply — the operational two thirds that appears in no other source. Merge
   the three sections (`## Equipment & installs`, `## People & conversations`,
   `## Waiting on / risks`) across the period and union every `sports:` array for the
   coverage panel.

   Treat the wording as the user's own and preserve it. **Count the logged days** —
   `logged / days-in-period` gets reported in Step 8. A thin count is not a reason to
   pad; it is the number that tells the user the nightly ritual lapsed.

   Zero logs is normal for now and is **never** a hard stop — the ritual started
   2026-09-07 and the report predates it. Fall back to a full Step 4 interview.

2. **Commitments** — `{fireflies_cli} action-items list --from <N> --agent`
   (`--from` takes an integer number of days). Flag anything open >14 days; those are
   risk-section candidates. On failure, parse `## Action items` blocks from the vault
   meeting files instead.

   **Known broken as of 2026-09-07:** this command exits 0 and returns an array of empty
   `{}` objects — a serialization bug, not an empty result. Do not read it as "no open
   commitments." The digest in item 1 carries action items inline; use those and record
   the degraded source in the internal record.
3. **Shipped artifacts** — read `{vault_output_ledger}`, newest first, entries within
   the period. **This is the only source for the "Shipped" section.**

   Format is a markdown table, newest first, data rows starting at line 22:
   `| Shipped | Artifact | What it is | Harvest |` where *Shipped* is `YYYY-MM-DD`,
   *Artifact* is the short name, *What it is* is a dense paragraph, and *Harvest* holds
   `[[wikilinks]]` or is empty. Match rows with `^\| 2\d{3}-\d{2}-\d{2}` and filter by
   date. Compress *What it is* to one clause for the email — those paragraphs run long
   and will blow the 300-word ceiling if pasted whole.
4. **Project movement** — read `{portfolio_json}`, filter `lane == "job"`. Use `stage`,
   `next_action`, and `updates[]` for the *In Progress* section only.
5. **KR state** — read `{okr_doc}` (v3, 14 KRs). This is the **only** trustworthy KR
   source. Two others will lie to you:

   - **Never read the cadence doc's KR table** — superseded v2 set of 9.
   - **Do not trust `{okr_scoreboard}` for confidence values.** It was generated
     2026-06-12 against the retired *quarterly, 3-objective* set and scores KRs that no
     longer exist; v3's fourth objective (Leadership & Visibility) isn't in it at all.
     Its `Conf` decimals are real numbers attached to dead targets. If it still predates
     the v3 restructure (2026-07-17), tell the user it needs regenerating — `okrs.yaml`
     is the source of truth, `okr.py` regenerates `SCOREBOARD.md` and `okrs.json` — and
     report KR status from `{okr_doc}` alone in the meantime.

6. **Sport roster** — the 17-program list for the coverage panel comes from
   `{utilization_brief}` §"Recommendations by program" (15 rows; the two XC / Track &
   Field rows each bundle two programs). Never re-derive this list from memory. Note it
   is *prescriptive* — what each program could use — not a record of current activity,
   which is exactly why the coverage panel is worth publishing.
7. **Canonical spine** — read `Applied-Performance-Active-Projects.md` for the confirmed
   active list, each project's sport and KR mapping.
8. **Optional** — `Inbox/weekly-review/*.md` within the period, if any exist.

### Hard rule: "Shipped" comes from the ledger, never from portfolio stage

`portfolio.json` marks projects `stage: shipped` that still have stakeholder sign-off
outstanding — Sport_Tech_Vetting is currently `shipped` while KR 1.2 shows Chris's
sign-off pending. Reporting that as shipped tells the user's supervisor that a thing he
never approved is done. **Only `_ledger.md` entries qualify as Shipped.** Portfolio
stage feeds *In Progress*.

## Voice — match the real thing, not the spec

**Read `{vault_status_reports}/2026-08-24-email-sent.txt` before drafting.** That is the
first report Eric actually sent. It is the reference for how he writes; this skill's
earlier draft was never sent and should not be imitated.

What his email actually does:

- **No section headers.** Flat short paragraphs, one topic each, no Shipped / In Progress
  / Decisions Needed labels. Do not impose the KR 4.1 headers on his prose — they are the
  *content checklist*, not the layout. Make sure each of the five things is covered
  somewhere; do not label them.
- **One framing line up top**, then straight into it. No preamble.
- **"We" for department work, "I" for his own actions.** He writes as the unit.
- **Concrete and operational.** Equipment, buildings, people, dates: Perch cameras at
  Fudge, FirstBeat monitors replacing Polar, survey cutoff August 28th. Names people
  freely — Linda, Noah, AJ, Javi, Micah.
- **Asks come last and land soft:** "One ask I wanted to run past you both is whether…"
  Do **not** convert these into "need Chris by Aug 31." That register is more forceful
  than he writes and it will read as someone else's words.
- **Stalled things get passed along, not escalated:** "still haven't heard back. Passing
  that along in case a nudge is warranted."
- **About 270 words. No attachment.** The memo PDF exists for when something needs to be
  handed across a table; the ordinary cycle is email only.

### The sourcing gap this exposed — important

Almost nothing in his real report appears in `portfolio.json` or `_ledger.md`: survey
response rates, camera installs at three buildings, heart-rate monitors arriving for
tennis, staff meeting cadence, a stalled email to Micah. Those sources track his
**building** work. He reports his **departmental operations**.

So the auto-pull covers maybe a third of what belongs in the report. **Weight the
interview accordingly** — ask about equipment, deliveries, installs, staffing, meetings
held, and follow-ups awaiting a reply, not just what moved in the registry. Treat a draft
built only from automated sources as roughly one-third finished.

## Step 3 — Draft before asking

Write a complete draft of all five sections from the pull. Cut to **5–6 projects with
real motion** — never a 14-line roster. Projects that didn't move go to the internal
record and, if relevant, the sport coverage panel.

Tag every Shipped and In Progress line with a sport: *(Volleyball)*, *(Football)*,
*(Soccer)*, *(Dept-wide)*, *(Cross-sport)*.

Then identify the gaps — that is what the interview is for.

## Step 4 — Interview the gaps only

Ask in **one batch**, not serially. Keep it to what the pull genuinely couldn't answer.
Lead with targeted gap questions, then the four standing ones.

**Targeted** (generated from the pull, examples):
- "Three meetings Tuesday–Thursday have no notes. Anything from them that Chris needs?"
- "Ledger shows nothing shipped this period — is that right, or did something go out
  that never got logged?"
- "Kinexon_Volleyball hasn't moved in the registry since July. Stalled, or just not
  logged?"

**Skip every standing question the supervisor logs already answered.** If
`{vault_status_log}` covered the period, questions 1–4 below are largely pre-filled —
read the merged log back to the user as a list and ask only *"anything missing?"* plus
questions 5–8. Re-asking what the user already typed at 9pm is how the nightly ritual
gets abandoned; the payoff for logging has to be a visibly shorter interview.

**Standing** (every time). The first three carry most of the report — they cover the
operational half no automated source sees:

1. **Equipment, installs, deliveries.** What arrived, what got installed where, what's
   being phased out, who's onboarding onto it. Eric's real reports lead with this
   (Perch cameras at Fudge, FirstBeat monitors replacing Polar for tennis).
2. **Meetings held and staffing.** Who he met with, what came out of it, changes to
   cadence or who attends. Names matter — Linda, Noah, AJ, Javi.
3. **Conversations no transcript caught** — hallway, text, sideline, phone. Invisible to
   every automated source, and among the highest-value things this interview captures.
4. **Anything waiting on someone else.** Unanswered emails, pending approvals, stalled
   follow-ups. These become the soft "passing that along" lines at the end.
5. **Anything about to go sideways** that Chris and Kenny should hear from him first.
   *(Push here. An always-empty risk line means it isn't being used honestly.)*
6. **Any ask** — time at a meeting, a decision, a nudge. Phrased softly, at the end.
7. **Ideas generated** — worth parking, pitching, or building?
8. **What's next** for the coming two weeks.

Also ask, if the pull shows thin coverage: *"Any sport you touched this period that
isn't showing up in my sources?"* Non-revenue involvement is the whole point and it is
the most likely thing to be undercounted.

## Step 5 — Assemble and check

Fill the template at `{vault_root}/Templates/status-report.md`.

Run every check before showing the user anything:

- [ ] **Email body is under 300 words.** Count it. State the count. Over the ceiling,
      cut — do not negotiate with yourself.
- [ ] **Every Shipped line traces to a `_ledger.md` entry.** No exceptions.
- [ ] **No endorsement claimed that doesn't exist.** If sign-off is pending, "our
      standard intake process," never "the approved process."
- [ ] **Every Shipped and In Progress line carries a sport tag.**
- [ ] **Every Decisions Needed item names a person and a date.** No owner or no date
      means it isn't a decision request — rewrite or cut it.
- [ ] **Jargon table enforced.** No CMJ, ACWR, asymmetry index, unexplained B.A.I.R.
- [ ] **Never "one unified dashboard."** The line is "standardized underneath, bespoke
      on top."
- [ ] **Research presented as research** — no readiness or deployment claims.
- [ ] **Risks section is non-empty** unless the user explicitly confirmed there's
      nothing. Ask once more before letting it go empty.
- [ ] **Repeat check:** any Decisions Needed item carried over from the previous report
      gets flagged to the user — two unanswered asks means the email has failed at it
      and it needs raising in person.
- [ ] **Email and PDF agree.** The two are filled separately, so verify it: every
      Shipped, In Progress, Decisions Needed, and Risks item in the email appears in the
      PDF. The PDF may carry *more* detail — it must never carry different facts, a
      different sport tag, or a different date. Sending a supervisor two versions of the
      same report is the failure this check exists to prevent.
- [ ] **Sport coverage panel is not padded.** Untouched sports stay marked untouched. A
      thin panel is real information; a padded one destroys the evidentiary value of
      every honest panel before and after it.

## Step 6 — Emit

Produce three things:

1. **`{vault_status_reports}/YYYY-MM-DD-status.md`** — the internal record, full Layer 3
   structure from the template: email as sent, meetings held, conversations, ideas, full
   roster, KR ledger, and the "Not for the report" candid section.
2. **`{vault_status_reports}/YYYY-MM-DD-onepager.pdf`** — render
   `assets/one-pager.html` with the period's content. One page, always.

   **It is a printed memorandum, not a dashboard.** Single column, one serif family,
   letterspaced small-cap section heads, one green hairline. Never reintroduce status
   dots, badge or pill rows, bolded stat lines, progress bars, or a two-column grid —
   that vocabulary is what made the first version read as generated.

   **Measure before shipping**, don't eyeball it. Budget is **950px of content at 666px
   width**:

   ```bash
   python3 -c "s=open('<file>.html').read(); open('/tmp/probe.html','w').write(
     s.replace('</body>','<script>window.addEventListener(\"load\",()=>{document.title=
     \"H:\"+Math.round(document.body.getBoundingClientRect().height)})</script></body>'))"
   "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" --headless --disable-gpu \
     --virtual-time-budget=3000 --window-size=666,1200 --dump-dom file:///tmp/probe.html \
     | grep -o '<title>H:[0-9]*'
   ```

   Then render: `--headless --disable-gpu --no-pdf-header-footer --print-to-pdf=<out>`.
   Over 950px, **cut prose** — never drop below 9.6pt. This gets printed and read by
   people who will not squint for you.
3. **`{vault_status_reports}/YYYY-MM-DD-email.txt`** — the email body as **plain text**,
   the file the user actually touches each cycle. Strip all markdown: no `**bold**`, no
   `-` bullets rendered as syntax. Use `•` or plain indentation, and spell section
   headers in caps (`SHIPPED`, `IN PROGRESS`). Outlook's compose window pastes markdown
   asterisks literally, and a supervisor email full of `**` reads as carelessness.
   Select-all-copy from this file should produce something sendable with zero cleanup.
4. **Also print the email text in the response** so the user can read it without opening
   a file — but the `.txt` is the artifact of record for sending.

### Do not send

The connected Gmail account is the user's **personal** address
(`eric.rash11@gmail.com`), not Baylor. Do not create Gmail drafts — they would land in
the wrong mailbox. The user sends from Outlook on the work account.

Never send a report to a supervisor without the user reading it first, under any
circumstance.

## Step 7 — Log

- Append shipped artifacts to `{vault_output_ledger}` if the interview surfaced any that
  weren't logged.
- Update `Applied-Performance-Active-Projects.md` with confirmed status, sport, and KR
  mapping — this keeps the canonical spine current as a byproduct rather than a chore.
- Add an `updates[]` entry to `{portfolio_json}` for each project reported as moved, via
  the `project` skill, so the registry stops being empty.
- Set `sent: false` in the internal record. The user flips it after sending.

## Step 8 — Report to the user

State: word count, report number, next send date, which sports appeared, anything the
checks flagged, and where the three files landed.

Also state **`N of D` days logged** in `{vault_status_log}` for the period. Say it
plainly and without nagging — the number is the nudge. When the count is low, say what it
cost: *"6 of 14 days logged, so the interview had to cover the other 8 from memory."*

---

## Failure modes to design against

**Padding.** A thin period is a legitimate output. "Nothing shipped this period" is an
honest line that protects the word "shipped" everywhere else. Inflating a quiet period
is the fastest way to make the report worthless — and to make the time documentation
inadmissible when it matters.

**Roster creep.** The email is not a project list. 14 status lines reads as 14 things
half-done. Five moving projects reads as focus.

**The credit goal quietly disappearing.** The report exists so non-football,
non-basketball involvement becomes visible. If a period's coverage panel is thin, that
is real information and it should be shown, not hidden — a padded panel destroys the
evidentiary value of every honest one.

**Depending on another ritual.** `weekly-review` lapsed for seven weeks earlier this
year. This report must never require it.
